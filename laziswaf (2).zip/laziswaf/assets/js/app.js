(function () {
  // =========================
  // THEME TOGGLE (dark/light)
  // =========================
  const THEME_KEY = "laziswaf_theme";

  function getSavedTheme() {
    return localStorage.getItem(THEME_KEY) || "dark";
  }

  function applyTheme(theme) {
    document.documentElement.setAttribute("data-theme", theme);
    localStorage.setItem(THEME_KEY, theme);

    const btn = document.getElementById("btnTheme");
    if (btn) {
      const isLight = theme === "light";
      btn.setAttribute("aria-pressed", isLight ? "true" : "false");
      btn.setAttribute("title", isLight ? "Mode Terang" : "Mode Gelap");

      // ICON ONLY (tanpa teks)
      btn.innerHTML = isLight
        ? '<i class="bi bi-moon-stars"></i>'   // kalau sedang light, klik jadi gelap
        : '<i class="bi bi-sun"></i>';         // kalau sedang dark, klik jadi terang
    }
  }

  // apply theme saat load
  applyTheme(getSavedTheme());

  // click handler
  const btnTheme = document.getElementById("btnTheme");
  if (btnTheme) {
    btnTheme.addEventListener("click", function () {
      const current = document.documentElement.getAttribute("data-theme") || "dark";
      applyTheme(current === "dark" ? "light" : "dark");
    });
  }

  // =========================
  // SIDEBAR TOGGLE (dashboard)
  // =========================
  const shell = document.getElementById("appShell");
  const btn = document.getElementById("btnSidebar");
  const backdrop = document.getElementById("sidebarBackdrop");

  if (btn && shell) {
    btn.addEventListener("click", function () {
      const isMobile = window.matchMedia("(max-width: 991.98px)").matches;
      if (isMobile) {
        shell.classList.toggle("sidebar-open");
        document.body.classList.toggle("no-scroll", shell.classList.contains("sidebar-open"));
      }
      else shell.classList.toggle("sidebar-collapsed");
    });
  }

  // Click backdrop to close sidebar (mobile)
  if (backdrop && shell) {
    backdrop.addEventListener("click", function () {
      shell.classList.remove("sidebar-open");
      document.body.classList.remove("no-scroll");
    });
  }

  // Submenu toggle
  document.querySelectorAll("[data-submenu]").forEach((b) => {
    b.addEventListener("click", () => {
      b.classList.toggle("open");
      const submenu = b.parentElement.querySelector(".submenu");
      if (submenu) submenu.classList.toggle("open");
    });
  });

  // Close sidebar on mobile when click outside
  document.addEventListener("click", (e) => {
    if (!shell) return;
    const isMobile = window.matchMedia("(max-width: 991.98px)").matches;
    if (!isMobile) return;

    const sidebar = document.getElementById("appSidebar");
    const toggleBtn = document.getElementById("btnSidebar");
    if (!shell.classList.contains("sidebar-open")) return;

    const clickInsideSidebar = sidebar && sidebar.contains(e.target);
    const clickOnToggle = toggleBtn && toggleBtn.contains(e.target);

    if (!clickInsideSidebar && !clickOnToggle) {
      shell.classList.remove("sidebar-open");
      document.body.classList.remove("no-scroll");
    }
  });

  // Ensure body scroll state is correct on resize
  window.addEventListener("resize", () => {
    if (!shell) return;
    const isMobile = window.matchMedia("(max-width: 991.98px)").matches;
    if (!isMobile) {
      document.body.classList.remove("no-scroll");
      shell.classList.remove("sidebar-open");
    }
  });
})();
