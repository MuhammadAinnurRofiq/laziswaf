<?php
defined('BASEPATH') OR exit('No direct script access allowed');

$route['default_controller'] = 'Landing';
$route['404_override'] = '';
$route['translate_uri_dashes'] = FALSE;

$route['login']    = 'Auth/login';
$route['register'] = 'Auth/register';
$route['logout']   = 'Auth/logout';

$route['dashboard'] = 'dashboard/index';

/* =========================
 * PUBLIC (tanpa login)
 * Route spesifik di atas wildcard
 * ========================= */

// PUBLIC
$route['public'] = 'PublicDashboard/index';

// Kalkulator (Publik)
$route['public/calculator'] = 'PublicCalculator/index';
$route['public/calculator/fitrah'] = 'PublicCalculator/fitrah';
$route['public/calculator/mal'] = 'PublicCalculator/mal';
$route['public/calculator/fidyah'] = 'PublicCalculator/fidyah';


// Track (cek status)
$route['public/track'] = 'PublicTrack/index';
$route['public/track/check'] = 'PublicTrack/check';

// Receipt (kuitansi publik)
$route['public/receipt'] = 'PublicReceipt/index';
$route['public/receipt/(:any)'] = 'PublicReceipt/view/$1';

// Submission (pastikan store di atas wildcard)
$route['public/submission/store'] = 'PublicSubmission/store';
$route['public/submission/success/(:any)'] = 'PublicSubmission/success/$1';
$route['public/submission/(:any)'] = 'PublicSubmission/create/$1';

/* =========================
 * BRANCH AREA (login)
 * ========================= */

$route['branch'] = 'branch/Dashboard/index';

// Cabang - input pengajuan untuk membantu donatur (branch_id otomatis ke cabang yang login)
$route['branch/submissions/create/(:any)'] = 'branch/Submissions/create/$1';
$route['branch/submissions/store'] = 'branch/Submissions/store';
$route['branch/submissions/success/(:any)'] = 'branch/Submissions/success/$1';

$route['branch/submissions/inbox'] = 'branch/Submissions/inbox';
$route['branch/submissions/history'] = 'branch/Submissions/history';
$route['branch/submissions/(:num)'] = 'branch/Submissions/show/$1';

$route['branch/submissions/approve/(:num)'] = 'branch/Submissions/approve/$1';
$route['branch/submissions/reject/(:num)'] = 'branch/Submissions/reject/$1';
$route['branch/submissions/needfix/(:num)'] = 'branch/Submissions/needfix/$1';

$route['branch/receipts'] = 'branch/Receipts/index';
$route['branch/receipts/(:num)'] = 'branch/Receipts/show/$1';

// DASHBOARD PUSAT (ADMIN/BENDAHARA)
$route['dashboard/submissions'] = 'CenterSubmissions/index';
$route['dashboard/submissions/(:num)'] = 'CenterSubmissions/show/$1';
$route['dashboard/submissions/delete/(:num)'] = 'CenterSubmissions/delete/$1';

// DASHBOARD PUSAT - KUITANSI
$route['dashboard/receipts'] = 'CenterReceipts/index';
$route['dashboard/receipts/export/csv'] = 'CenterReceipts/export_csv';

// CABANG - LAPORAN
$route['branch/reports'] = 'BranchReports/index';
$route['branch/reports/create'] = 'BranchReports/create';
$route['branch/reports/(:num)'] = 'BranchReports/show/$1';
$route['branch/reports/send/(:num)'] = 'BranchReports/send/$1';

// PUSAT - REVIEW LAPORAN
$route['dashboard/reports'] = 'CenterReports/index';
$route['dashboard/reports/(:num)'] = 'CenterReports/show/$1';
$route['dashboard/reports/approve/(:num)'] = 'CenterReports/approve/$1';
$route['dashboard/reports/reject/(:num)'] = 'CenterReports/reject/$1';

// KONSOLIDASI PUSAT (ringkas)
$route['dashboard/reports/consolidation'] = 'CenterReports/consolidation';

$route['branch/reports/export/pdf/(:num)'] = 'BranchReports/export_pdf/$1';
$route['dashboard/reports/consolidation/pdf'] = 'CenterReports/consolidation_pdf';

// Branch notifications
$route['branch/notifications'] = 'branch/notifications/index';
$route['branch/notifications/read/(:num)'] = 'branch/notifications/read/$1';
$route['branch/notifications/read_all'] = 'branch/notifications/read_all';

// Center notifications (admin/bendahara)
$route['dashboard/notifications'] = 'CenterNotifications/index';
$route['dashboard/notifications/read/(:num)'] = 'CenterNotifications/read/$1';
$route['dashboard/notifications/read_all'] = 'CenterNotifications/read_all';


$route['branch/submissions'] = 'branch/submissions/index';
$route['branch/submissions/(:any)'] = 'branch/submissions/$1';

// PUBLIC - scan QR cabang
$route['public/scan/(:any)'] = 'PublicScan/index/$1';

// PUSAT - master cabang & akun (ADMIN/BENDAHARA)
$route['dashboard/branches'] = 'CenterBranches/index';
$route['dashboard/branches/create'] = 'CenterBranches/create';
$route['dashboard/branches/edit/(:num)'] = 'CenterBranches/edit/$1';
$route['dashboard/branches/delete/(:num)'] = 'CenterBranches/delete/$1';
$route['dashboard/branches/card/(:num)'] = 'CenterBranches/card/$1';

// PUSAT - user cabang (multi user per cabang)
$route['dashboard/branches/users/(:num)'] = 'CenterBranches/users/$1';
$route['dashboard/branches/users/(:num)/create'] = 'CenterBranches/user_create/$1';
$route['dashboard/branches/users/(:num)/edit/(:num)'] = 'CenterBranches/user_edit/$1/$2';
$route['dashboard/branches/users/(:num)/toggle/(:num)'] = 'CenterBranches/user_toggle/$1/$2';


// MASTER TARIF (ADMIN/BENDAHARA)
// PUSAT - TARIF
$route['dashboard/rates'] = 'CenterRates/index';
$route['dashboard/rates/create'] = 'CenterRates/create';
$route['dashboard/rates/edit/(:num)'] = 'CenterRates/edit/$1';
$route['dashboard/rates/delete/(:num)'] = 'CenterRates/delete/$1';

$route['branch/reports/refresh/(:num)'] = 'BranchReports/refresh/$1';
$route['branch/barcode'] = 'branch/barcode/index';


// ADMIN - MANAGE ALL USERS (ADMIN only)
$route['dashboard/users'] = 'CenterUsers/index';
$route['dashboard/users/create'] = 'CenterUsers/create';
$route['dashboard/users/edit/(:num)'] = 'CenterUsers/edit/$1';
$route['dashboard/users/delete/(:num)'] = 'CenterUsers/delete/$1';

// ADMIN - MANAGE BENDAHARA USERS
$route['dashboard/users/bendahara'] = 'CenterUsers/bendahara_index';
$route['dashboard/users/bendahara/create'] = 'CenterUsers/bendahara_create';
$route['dashboard/users/bendahara/edit/(:num)'] = 'CenterUsers/bendahara_edit/$1';
$route['dashboard/users/bendahara/delete/(:num)'] = 'CenterUsers/bendahara_delete/$1';

$route['dashboard/reports/export/pdf/(:num)'] = 'CenterReports/export_pdf/$1';

$route['dashboard/reports/branches'] = 'CenterReports/branches';
$route['dashboard/reports/branches/pdf'] = 'CenterReports/branches_pdf';

// ADMIN - SETTINGS
$route['dashboard/settings'] = 'CenterSettings/landing';
$route['dashboard/settings/landing'] = 'CenterSettings/landing';
$route['dashboard/settings/landing/save'] = 'CenterSettings/landing_save';
$route['dashboard/settings/profile'] = 'CenterSettings/profile';
$route['dashboard/settings/profile/save'] = 'CenterSettings/profile_save';
$route['dashboard/settings/download-db'] = 'CenterSettings/download_db';



// public asset endpoint (logo dari DB)
$route['assets/app-logo'] = 'AppAssets/logo';
