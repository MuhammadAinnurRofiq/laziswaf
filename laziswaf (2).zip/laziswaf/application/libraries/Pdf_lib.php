<?php
defined('BASEPATH') OR exit('No direct script access allowed');

use Dompdf\Dompdf;
use Dompdf\Options;

/**
 * Pdf_lib
 * - Menambahkan header global (logo + nama aplikasi)
 * - Menambahkan nomor halaman di footer (1 / N)
 * Catatan: Template PDF individual (view) tetap boleh punya style sendiri.
 */
class Pdf_lib
{
  /**
   * Render dan stream PDF.
   */
  public function render($html, $filename = 'document.pdf', $paper='A4', $orientation='portrait', $attachment = true, $meta = array())
  {
    $CI =& get_instance();
    if (!isset($CI->db)) $CI->load->database();

    // Setting_model dipakai untuk app_name + logo (BLOB sys_assets)
    $CI->load->model('Setting_model');

    $appName = (string)$CI->Setting_model->get_text('app_name', 'LAZISWAF');

    // Meta dokumen (judul cetakan + tahun) - akan tampil di header
    $docTitle = '';
    $docYear  = '';
    $docSubtitle = '';
    if (is_array($meta)) {
      $docTitle = trim((string)($meta['title'] ?? ''));
      $docYear  = trim((string)($meta['year'] ?? ''));
      $docSubtitle = trim((string)($meta['subtitle'] ?? ''));
    }
    if ($docYear === '') $docYear = date('Y');

    // Ambil logo dari DB (sys_assets: app_logo) -> data URI
    // Catatan:
    // - Dompdf membutuhkan ekstensi GD untuk merender gambar raster (PNG/JPG).
    // - Di beberapa environment, pengecekan extension_loaded('gd') bisa tidak akurat.
    //   Karena itu kita akan coba render dengan logo dulu, lalu fallback tanpa logo jika Dompdf melempar exception.
    $logoDataUri = '';
    $asset = $CI->Setting_model->get_asset('app_logo');
    if (is_array($asset) && !empty($asset['data'])) {
      $mime = (string)($asset['mime_type'] ?? 'image/png');
      if ($mime === '') $mime = 'image/png';
      $b64  = base64_encode($asset['data']);
      $logoDataUri = 'data:' . $mime . ';base64,' . $b64;
    }

    // Simpan html asli untuk fallback (agar tidak double-inject)
    $rawHtml = $html;

    // Header HTML (rapi, minimal, aman untuk berbagai template)
    $headerHtml = $this->build_header_html($appName, $logoDataUri, $docTitle, $docYear, $docSubtitle);

    // CSS tambahan: reservasi ruang header + styling header
    $extraCss = $this->build_base_css();

    // Sisipkan header + css ke dokumen yang ada (baik yang berupa full HTML maupun fragment)
    $html = $this->inject_header_and_css($rawHtml, $headerHtml, $extraCss);

    $options = new Options();
    $options->set('isRemoteEnabled', true);
    $options->set('isHtml5ParserEnabled', true);

    try {
      $dompdf = new Dompdf($options);
      $dompdf->setPaper($paper, $orientation);
      $dompdf->loadHtml($html, 'UTF-8');
      $dompdf->render();

    } catch (Exception $e) {

      // Fallback: render ulang TANPA logo, agar tidak crash jika GD belum aktif / format gambar tidak didukung.
      $headerHtml2 = $this->build_header_html($appName, '', $docTitle, $docYear, $docSubtitle);
      $html2 = $this->inject_header_and_css($rawHtml, $headerHtml2, $extraCss);

      $dompdf = new Dompdf($options);
      $dompdf->setPaper($paper, $orientation);
      $dompdf->loadHtml($html2, 'UTF-8');
      $dompdf->render();
    }

    // Nomor halaman di footer: 1 / N, 2 / N, dst
    $this->add_page_numbers($dompdf);

    $dompdf->stream($filename, array("Attachment" => $attachment ? 1 : 0));
    exit;
  }

  private function build_header_html($appName, $logoDataUri = '', $docTitle = '', $docYear = '', $docSubtitle = '')
  {
    $appNameEsc = htmlspecialchars($appName, ENT_QUOTES, 'UTF-8');

    $docTitle = trim((string)$docTitle);
    $docYear  = trim((string)$docYear);
    $docSubtitle = trim((string)$docSubtitle);

    $docTitleEsc = htmlspecialchars($docTitle, ENT_QUOTES, 'UTF-8');
    $docYearEsc  = htmlspecialchars($docYear, ENT_QUOTES, 'UTF-8');
    $docSubtitleEsc = htmlspecialchars($docSubtitle, ENT_QUOTES, 'UTF-8');

    $logo = '';
    if ($logoDataUri !== '') {
      $logo = '<img class="__pdf_logo" src="' . $logoDataUri . '" alt="' . $appNameEsc . '">';
    } else {
      // fallback dot jika tidak ada logo
      $logo = '<span class="__pdf_logo_dot"></span>';
    }

    $metaHtml = '';
    if ($docTitle !== '' || $docYear !== '' || $docSubtitle !== '') {
      $metaHtml = '<div class="__pdf_meta">'
        . ($docTitle !== '' ? '<div class="__pdf_doc_title">' . $docTitleEsc . '</div>' : '')
        . ($docYear !== '' ? '<div class="__pdf_doc_year">' . $docYearEsc . '</div>' : '')
        . ($docSubtitle !== '' ? '<div class="__pdf_doc_subtitle">' . $docSubtitleEsc . '</div>' : '')
        . '</div>';
    }

    return '<div class="__pdf_header">'
      . '<div class="__pdf_header_inner">'
      . '<div class="__pdf_brand">'
      . $logo
      . '<div class="__pdf_appname">' . $appNameEsc . '</div>'
      . '</div>'
      . $metaHtml
      . '</div>'
      . '<div class="__pdf_divider"></div>'
      . '</div>';
  }

  private function build_base_css()
  {
    // Margin top dibuat cukup agar konten tidak menabrak header.
    // Margin bottom cukup untuk nomor halaman.
    return <<<CSS
@page { margin: 85px 40px 45px 40px; }

.__pdf_header{
  position: fixed;
  top: -70px;
  left: 0;
  right: 0;
  height: 70px;
}

.__pdf_header_inner{
  display: flex;
  align-items: flex-end;
  justify-content: space-between;
}

.__pdf_brand{
  display: flex;
  align-items: center;
  gap: 10px;
  padding: 6px 0 6px 0;
}

.__pdf_logo{
  width: 20px;
  height: 20px;
  object-fit: contain;
  border-radius: 6px;
  display: inline-block;
}

.__pdf_logo_dot{
  width: 12px;
  height: 12px;
  border-radius: 50%;
  display: inline-block;
  background: #4c8dff;
  box-shadow: 0 0 0 4px rgba(76,141,255,0.15);
}

.__pdf_appname{
  font-size: 12px;
  font-weight: 700;
  letter-spacing: .2px;
}

.__pdf_meta{
  text-align: right;
  padding: 6px 0 6px 0;
  line-height: 1.2;
}

.__pdf_doc_title{
  font-size: 12px;
  font-weight: 800;
}

.__pdf_doc_year{
  font-size: 11px;
  font-weight: 700;
  color: #111;
  opacity: .75;
}

.__pdf_doc_subtitle{
  font-size: 10px;
  color: #444;
  opacity: .75;
}

.__pdf_divider{
  border-bottom: 1px solid #e5e7eb;
}
CSS;
  }

  private function inject_header_and_css($html, $headerHtml, $css)
  {
    // Sisip CSS ke <head> jika ada, kalau tidak ada buat head minimal
    $styleTag = "<style>\n" . $css . "\n</style>\n";

    if (stripos($html, '</head>') !== false) {
      $html = preg_replace('~</head>~i', $styleTag . '</head>', $html, 1);
    } else {
      // Jika bukan full HTML, bungkus jadi dokumen minimal agar CSS + header konsisten
      if (stripos($html, '<html') === false) {
        $html = "<!doctype html><html><head><meta charset=\"utf-8\">" . $styleTag . "</head><body>" . $html . "</body></html>";
      } else {
        // ada <html> tapi tidak ada </head> -> prepend style
        $html = $styleTag . $html;
      }
    }

    // Sisip header setelah opening <body>
    if (stripos($html, '<body') !== false) {
      $html = preg_replace('~<body([^>]*)>~i', '<body$1>' . $headerHtml, $html, 1);
    } else {
      // fallback: prepend
      $html = $headerHtml . $html;
    }

    return $html;
  }

  private function add_page_numbers($dompdf)
  {
    try {
      $canvas = $dompdf->getCanvas();
      $fontMetrics = $dompdf->getFontMetrics();
      $font = $fontMetrics->get_font("Helvetica", "normal");
      $size = 9;

      $text = "{PAGE_NUM} / {PAGE_COUNT}";
      $w = $fontMetrics->getTextWidth($text, $font, $size);
      $x = ($canvas->get_width() - $w) / 2;
      $y = $canvas->get_height() - 28;

      $canvas->page_text($x, $y, $text, $font, $size, array(0,0,0));
    } catch (Exception $e) {
      // diamkan: jangan mematikan PDF jika gagal menambahkan nomor halaman
    }
  }
}