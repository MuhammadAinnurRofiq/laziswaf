<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Auth_lib
{
  protected $CI;

  public function __construct()
  {
    $this->CI =& get_instance();
  }

  public function login($user_row, $roles = array())
  {
    $this->CI->session->set_userdata('auth', array(
      'id' => (int)$user_row->id,
      'username' => $user_row->username,
      'full_name' => $user_row->full_name,
      'branch_id' => $user_row->branch_id,
      'roles' => $roles
    ));
  }

  public function logout()
  {
    $this->CI->session->unset_userdata('auth');
  }

  public function is_logged_in()
  {
    return (bool)$this->CI->session->userdata('auth');
  }

  public function user()
  {
    $auth = $this->CI->session->userdata('auth');
    return $auth ? (object)$auth : null;
  }

  public function roles()
  {
    $u = $this->user();
    return $u ? (array)$u->roles : array();
  }

  public function has_role($role_code)
  {
    return in_array($role_code, $this->roles(), true);
  }

  public function has_any_role($roles)
  {
    foreach ((array)$roles as $r) {
      if ($this->has_role($r)) return true;
    }
    return false;
  }

  public function primary_role()
  {
    $roles = $this->roles();
    if (in_array('ADMIN', $roles, true)) return 'ADMIN';
    if (in_array('BENDAHARA', $roles, true)) return 'BENDAHARA';
    if (in_array('CABANG', $roles, true)) return 'CABANG';
    return 'GUEST';
  }
}
