<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class User_model extends CI_Model
{
  public function find_by_username($username)
  {
    return $this->db->get_where('auth_users', array('username'=>$username), 1)->row();
  }

  public function username_exists($username)
  {
    return $this->db->where('username', $username)->count_all_results('auth_users') > 0;
  }

  public function create_user($data, $role_code = 'CABANG')
  {
    $this->db->insert('auth_users', $data);
    $user_id = (int)$this->db->insert_id();

    $role = $this->db->get_where('auth_roles', array('code'=>$role_code), 1)->row();
    if ($role) {
      $this->db->insert('auth_user_roles', array(
        'user_id' => $user_id,
        'role_id' => (int)$role->id
      ));
    }

    return $user_id;
  }

  public function get_user_roles($user_id)
  {
    $this->db->select('r.code');
    $this->db->from('auth_user_roles ur');
    $this->db->join('auth_roles r', 'r.id = ur.role_id');
    $this->db->where('ur.user_id', (int)$user_id);
    $rows = $this->db->get()->result();

    $roles = array();
    foreach ($rows as $r) $roles[] = $r->code;
    return $roles;
  }

  public function update_last_login($user_id)
  {
    $this->db->where('id', (int)$user_id)->update('auth_users', array(
      'last_login_at' => date('Y-m-d H:i:s')
    ));
  }

  public function branches_active()
  {
    return $this->db->where('is_active',1)->order_by('branch_name','ASC')->get('mst_branches')->result();
  }


  public function find_by_id($id)
{
  return $this->db->get_where('auth_users', array('id'=>(int)$id), 1)->row();
}

public function username_exists_other($username, $exclude_id)
{
  return $this->db->where('username', $username)
                  ->where('id !=', (int)$exclude_id)
                  ->count_all_results('auth_users') > 0;
}

public function list_users_by_role($role_code)
{
  $this->db->select('u.*, r.code AS role_code');
  $this->db->from('auth_users u');
  $this->db->join('auth_user_roles ur', 'ur.user_id = u.id');
  $this->db->join('auth_roles r', 'r.id = ur.role_id');
  $this->db->where('r.code', strtoupper((string)$role_code));
  $this->db->order_by('u.created_at', 'DESC');
  return $this->db->get()->result();
}

public function find_user_in_role($user_id, $role_code)
{
  $this->db->select('u.*, r.code AS role_code');
  $this->db->from('auth_users u');
  $this->db->join('auth_user_roles ur', 'ur.user_id = u.id');
  $this->db->join('auth_roles r', 'r.id = ur.role_id');
  $this->db->where('u.id', (int)$user_id);
  $this->db->where('r.code', strtoupper((string)$role_code));
  return $this->db->get()->row();
}

public function update_user($id, $data)
{
  $this->db->where('id', (int)$id)->update('auth_users', $data);
}

public function delete_user($id)
{
  $id = (int)$id;
  $this->db->trans_begin();

  $this->db->where('user_id', $id)->delete('auth_user_roles');
  $this->db->where('id', $id)->delete('auth_users');

  if ($this->db->trans_status() === false) {
    $this->db->trans_rollback();
    return false;
  }
  $this->db->trans_commit();
  return true;
}

  // ============================
  // ADMIN: utilities
  // ============================
  public function roles_list()
  {
    $rows = $this->db->order_by('id','ASC')->get('auth_roles')->result();
    $out = array();
    foreach ($rows as $r) $out[strtoupper((string)$r->code)] = $r->name;
    return $out;
  }

  public function list_all_users($filters = array())
  {
    $q = trim((string)($filters['q'] ?? ''));
    $role = strtoupper(trim((string)($filters['role'] ?? '')));

    $this->db->select("u.*, b.branch_name, r.code AS role_code, r.name AS role_name");
    $this->db->from('auth_users u');
    $this->db->join('mst_branches b', 'b.id = u.branch_id', 'left');
    $this->db->join('auth_user_roles ur', 'ur.user_id = u.id', 'left');
    $this->db->join('auth_roles r', 'r.id = ur.role_id', 'left');

    if ($q !== '') {
      $this->db->group_start();
      $this->db->like('u.username', $q);
      $this->db->or_like('u.full_name', $q);
      $this->db->or_like('u.phone', $q);
      $this->db->or_like('u.email', $q);
      $this->db->group_end();
    }
    if ($role !== '' && in_array($role, array('ADMIN','BENDAHARA','CABANG'), true)) {
      $this->db->where('r.code', $role);
    }

    $this->db->order_by('u.created_at','DESC');
    return $this->db->get()->result();
  }

  public function find_user($id)
  {
    $this->db->select("u.*, r.code AS role_code");
    $this->db->from('auth_users u');
    $this->db->join('auth_user_roles ur', 'ur.user_id = u.id', 'left');
    $this->db->join('auth_roles r', 'r.id = ur.role_id', 'left');
    $this->db->where('u.id', (int)$id);
    $this->db->limit(1);
    return $this->db->get()->row();
  }

  private function set_user_role($user_id, $role_code)
  {
    $role_code = strtoupper(trim((string)$role_code));
    $role = $this->db->get_where('auth_roles', array('code'=>$role_code), 1)->row();
    if (!$role) return false;

    $this->db->where('user_id', (int)$user_id)->delete('auth_user_roles');
    $this->db->insert('auth_user_roles', array(
      'user_id' => (int)$user_id,
      'role_id' => (int)$role->id
    ));
    return true;
  }

  public function admin_create_user($data, $role_code)
  {
    $this->db->trans_begin();

    $this->db->insert('auth_users', $data);
    $user_id = (int)$this->db->insert_id();

    $this->set_user_role($user_id, $role_code);

    if ($this->db->trans_status() === false) {
      $this->db->trans_rollback();
      return 0;
    }
    $this->db->trans_commit();
    return $user_id;
  }

  public function admin_update_user($id, $data, $role_code)
  {
    $id = (int)$id;
    $this->db->trans_begin();

    $this->db->where('id', $id)->update('auth_users', $data);
    $this->set_user_role($id, $role_code);

    if ($this->db->trans_status() === false) {
      $this->db->trans_rollback();
      return false;
    }
    $this->db->trans_commit();
    return true;
  }

  public function admin_delete_user($id)
  {
    $id = (int)$id;
    $this->db->trans_begin();

    $this->db->where('user_id', $id)->delete('auth_user_roles');
    $this->db->where('to_user_id', $id)->delete('notif_notifications');

    // FK lain diset ON DELETE SET NULL (lihat schema upgrade)
    $this->db->where('id', $id)->delete('auth_users');

    if ($this->db->trans_status() === false) {
      $this->db->trans_rollback();
      return false;
    }
    $this->db->trans_commit();
    return true;
  }


}
