<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Center_branch_model extends CI_Model
{
  public function branches_with_user($q = '')
  {
    // Catatan:
    // - Cabang bisa punya banyak user (role CABANG)
    // - Untuk listing, kita tampilkan username "utama" (user pertama) + jumlah user cabang
    // - Query dibuat kompatibel dengan ONLY_FULL_GROUP_BY (group_by semua kolom b.*)
    $role_exists = "EXISTS (SELECT 1 FROM auth_user_roles ur JOIN auth_roles r ON r.id = ur.role_id WHERE ur.user_id = u.id AND r.code = 'CABANG')";

    $this->db->select("
      b.id, b.branch_code, b.branch_name, b.address, b.contact_wa, b.public_token, b.is_active, b.created_at, b.updated_at,
      MIN(u.username) AS username,
      MIN(u.full_name) AS user_full_name,
      MIN(u.is_active) AS user_active,
      COUNT(u.id) AS user_count
    ", false);

    $this->db->from('mst_branches b');
    $this->db->join('auth_users u', "u.branch_id = b.id AND {$role_exists}", 'left', false);

    if ($q !== '') {
      $this->db->group_start()
        ->like('b.branch_code', $q)
        ->or_like('b.branch_name', $q)
        ->or_like('u.username', $q)
      ->group_end();
    }

    $this->db->group_by(array(
      'b.id','b.branch_code','b.branch_name','b.address','b.contact_wa','b.public_token','b.is_active','b.created_at','b.updated_at'
    ));
    $this->db->order_by('b.branch_code', 'asc');

    return $this->db->get()->result_array();
  }

  public function get_branch($id)
  {
    return $this->db->get_where('mst_branches', array('id' => (int)$id))->row_array();
  }

  public function get_branch_user($branch_id)
  {
    $this->db->from('auth_users');
    $this->db->where('branch_id', (int)$branch_id);
    $this->db->order_by('id', 'asc');
    return $this->db->get()->row_array();
  }

  public function branch_code_exists($code, $exclude_id = null)
  {
    $this->db->from('mst_branches');
    $this->db->where('branch_code', $code);
    if ($exclude_id) $this->db->where('id !=', (int)$exclude_id);
    return $this->db->count_all_results() > 0;
  }

  public function username_exists($username, $exclude_user_id = null)
  {
    $this->db->from('auth_users');
    $this->db->where('username', $username);
    if ($exclude_user_id) $this->db->where('id !=', (int)$exclude_user_id);
    return $this->db->count_all_results() > 0;
  }

  public function find_role_id($code)
  {
    $r = $this->db->get_where('auth_roles', array('code' => $code))->row_array();
    return $r ? (int)$r['id'] : 0;
  }

  private function new_token()
  {
    return bin2hex(random_bytes(16)); // 32 chars
  }

  public function create_branch_and_user($branch, $user, $role_code = 'CABANG')
  {
    $this->db->trans_start();

    if (empty($branch['public_token'])) $branch['public_token'] = $this->new_token();

    $this->db->insert('mst_branches', $branch);
    $branch_id = (int)$this->db->insert_id();

    $user['branch_id'] = $branch_id;
    $this->db->insert('auth_users', $user);
    $user_id = (int)$this->db->insert_id();

    $role_id = $this->find_role_id($role_code);
    if ($role_id > 0) {
      $this->db->insert('auth_user_roles', array('user_id' => $user_id, 'role_id' => $role_id));
    }

    $this->db->trans_complete();
    return array('ok' => $this->db->trans_status(), 'branch_id' => $branch_id, 'user_id' => $user_id);
  }

  public function update_branch_and_user($branch_id, $branch, $user_id, $user, $new_password_plain = '')
  {
    $this->db->trans_start();

    // branch
    $this->db->where('id', (int)$branch_id)->update('mst_branches', $branch);

    // user
    if ($new_password_plain !== '') {
      $user['password_hash'] = password_hash($new_password_plain, PASSWORD_BCRYPT);
    }
    $this->db->where('id', (int)$user_id)->update('auth_users', $user);

    $this->db->trans_complete();
    return array('ok' => $this->db->trans_status());
  }



  /* =========================
   * MULTI USER CABANG
   * ========================= */

  public function list_branch_users($branch_id, $q = '')
  {
    $branch_id = (int)$branch_id;

    $this->db->select('u.*');
    $this->db->from('auth_users u');
    $this->db->where('u.branch_id', $branch_id);
    $this->db->where("EXISTS (SELECT 1 FROM auth_user_roles ur JOIN auth_roles r ON r.id = ur.role_id WHERE ur.user_id = u.id AND r.code = 'CABANG')", null, false);

    if ($q !== '') {
      $this->db->group_start()
        ->like('u.username', $q)
        ->or_like('u.full_name', $q)
        ->or_like('u.phone', $q)
        ->or_like('u.email', $q)
      ->group_end();
    }

    $this->db->order_by('u.is_active', 'desc');
    $this->db->order_by('u.id', 'asc');
    return $this->db->get()->result_array();
  }

  public function get_branch_user_by_id($branch_id, $user_id)
  {
    $branch_id = (int)$branch_id;
    $user_id   = (int)$user_id;

    $this->db->from('auth_users u');
    $this->db->where('u.id', $user_id);
    $this->db->where('u.branch_id', $branch_id);
    $this->db->where("EXISTS (SELECT 1 FROM auth_user_roles ur JOIN auth_roles r ON r.id = ur.role_id WHERE ur.user_id = u.id AND r.code = 'CABANG')", null, false);
    return $this->db->get()->row_array();
  }

  public function count_active_branch_users($branch_id)
  {
    $branch_id = (int)$branch_id;

    $this->db->from('auth_users u');
    $this->db->where('u.branch_id', $branch_id);
    $this->db->where('u.is_active', 1);
    $this->db->where("EXISTS (SELECT 1 FROM auth_user_roles ur JOIN auth_roles r ON r.id = ur.role_id WHERE ur.user_id = u.id AND r.code = 'CABANG')", null, false);
    return (int)$this->db->count_all_results();
  }

  public function create_branch_user($branch_id, $user, $role_code = 'CABANG')
  {
    $branch_id = (int)$branch_id;

    $this->db->trans_start();

    $user['branch_id'] = $branch_id;
    $this->db->insert('auth_users', $user);
    $user_id = (int)$this->db->insert_id();

    $role_id = $this->find_role_id($role_code);
    if ($role_id > 0) {
      $this->db->insert('auth_user_roles', array('user_id' => $user_id, 'role_id' => $role_id));
    }

    $this->db->trans_complete();
    return array('ok' => $this->db->trans_status(), 'user_id' => $user_id);
  }

  public function update_branch_user($branch_id, $user_id, $user, $new_password_plain = '')
  {
    $branch_id = (int)$branch_id;
    $user_id   = (int)$user_id;

    $this->db->trans_start();

    if ($new_password_plain !== '') {
      $user['password_hash'] = password_hash($new_password_plain, PASSWORD_BCRYPT);
    }

    // hard-safety: jangan sampai pindah cabang via update
    $user['branch_id'] = $branch_id;

    $this->db->where('id', $user_id);
    $this->db->where('branch_id', $branch_id);
    $this->db->update('auth_users', $user);

    $this->db->trans_complete();
    return array('ok' => $this->db->trans_status());
  }

  public function set_branch_user_active($branch_id, $user_id, $is_active)
  {
    $branch_id = (int)$branch_id;
    $user_id   = (int)$user_id;

    $this->db->where('id', $user_id);
    $this->db->where('branch_id', $branch_id);
    $this->db->update('auth_users', array(
      'is_active'  => (int)$is_active ? 1 : 0,
      'updated_at' => date('Y-m-d H:i:s')
    ));

    return array('ok' => $this->db->affected_rows() >= 0);
  }

  // rekomendasi: soft delete (aman karena cabang bisa punya transaksi)
  public function deactivate_branch($branch_id)
  {
    $this->db->trans_start();

    $this->db->where('id', (int)$branch_id)->update('mst_branches', array('is_active' => 0, 'updated_at' => date('Y-m-d H:i:s')));
    $this->db->where('branch_id', (int)$branch_id)->update('auth_users', array('is_active' => 0, 'updated_at' => date('Y-m-d H:i:s')));

    $this->db->trans_complete();
    return array('ok' => $this->db->trans_status());
  }

  public function find_by_public_token($token)
  {
    return $this->db->get_where('mst_branches', array('public_token' => $token, 'is_active' => 1))->row_array();
  }
}
