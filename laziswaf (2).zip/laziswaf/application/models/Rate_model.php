<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Rate_model extends CI_Model
{
  /**
   * Ambil tarif aktif terbaru berdasarkan tanggal berlaku.
   * Return: OBJECT (stdClass)
   */
  public function get_current($zis_type_code, $date = null)
  {
    $date = $date ?: date('Y-m-d');

    $this->db->from('mst_rates');
    $this->db->where('zis_type_code', $zis_type_code);

    // Aman: hanya pakai is_active kalau kolomnya memang ada
    if ($this->db->field_exists('is_active', 'mst_rates')) {
      $this->db->where('is_active', 1);
    }

    $this->db->where('effective_from <=', $date);
    $this->db->order_by('effective_from', 'DESC');
    $this->db->order_by('id', 'DESC');
    $this->db->limit(1);

    return $this->db->get()->row(); // OBJECT
  }

  /**
   * List semua tarif (untuk dashboard/rates).
   * Return: ARRAY of ARRAY (result_array) sesuai view center/rates/index.php
   */
  public function list_all()
  {
    $this->db->from('mst_rates');
    $this->db->order_by('zis_type_code', 'ASC');
    $this->db->order_by('effective_from', 'DESC');
    $this->db->order_by('id', 'DESC');
    return $this->db->get()->result_array();
  }

  /** Ambil 1 tarif by id. Return: ARRAY (row_array) */
  public function get($id)
  {
    $this->db->from('mst_rates');
    $this->db->where('id', (int)$id);
    return $this->db->get()->row_array();
  }

  /** Insert tarif. Return: insert_id */
  public function create($data)
  {
    if (!is_array($data)) $data = (array)$data;

    // biarkan DB isi created_at default current_timestamp()
    if (array_key_exists('created_at', $data)) unset($data['created_at']);

    $this->db->insert('mst_rates', $data);
    return (int)$this->db->insert_id();
  }

  /** Update tarif. Return: affected_rows */
  public function update($id, $data)
  {
    if (!is_array($data)) $data = (array)$data;
    if (array_key_exists('created_at', $data)) unset($data['created_at']);

    $this->db->where('id', (int)$id);
    $this->db->update('mst_rates', $data);
    return (int)$this->db->affected_rows();
  }

  /** Delete tarif. Return: affected_rows */
  public function delete($id)
  {
    $this->db->where('id', (int)$id);
    $this->db->delete('mst_rates');
    return (int)$this->db->affected_rows();
  }

  /**
   * Data cabang untuk form publik.
   * View public/submission/form.php memakai OBJECT ($b->id, $b->branch_name)
   */
  public function get_branches_public()
  {
    // DB: mst_branches punya branch_name (bukan name)
    $this->db->select('id, branch_name');
    $this->db->from('mst_branches');

    if ($this->db->field_exists('is_active', 'mst_branches')) {
      $this->db->where('is_active', 1);
    }

    $this->db->order_by('branch_name', 'ASC');
    return $this->db->get()->result(); // OBJECT list
  }

  /**
   * Metode pembayaran untuk form publik.
   * View public/submission/form.php memakai OBJECT ($m->id, $m->name)
   */
  public function get_payment_methods()
  {
    $this->db->select('id, code, name');
    $this->db->from('mst_payment_methods');

    if ($this->db->field_exists('is_active', 'mst_payment_methods')) {
      $this->db->where('is_active', 1);
    }

    // sort_order tidak selalu ada di DB
    if ($this->db->field_exists('sort_order', 'mst_payment_methods')) {
      $this->db->order_by('sort_order', 'ASC');
    }

    $this->db->order_by('name', 'ASC');
    return $this->db->get()->result(); // OBJECT list
  }
}
