<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Notification_model extends CI_Model
{
  private $table = 'notif_notifications';

  public function unread_count($user_id)
  {
    return (int)$this->db
      ->where('to_user_id', (int)$user_id)
      ->where('is_read', 0)
      ->count_all_results($this->table);
  }

  public function list_for_user($user_id, $limit = 20, $offset = 0, $only_unread = false)
  {
    $this->db->from($this->table)
      ->where('to_user_id', (int)$user_id);

    if ($only_unread) $this->db->where('is_read', 0);

    $total = (int)$this->db->count_all_results('', false);

    $rows = $this->db
      ->order_by('created_at', 'DESC')
      ->limit((int)$limit, (int)$offset)
      ->get()
      ->result();

    return array('total' => $total, 'rows' => $rows);
  }

  public function create($to_user_id, $title, $body = null, $link_url = null)
  {
    $data = array(
      'to_user_id' => (int)$to_user_id,
      'title'      => (string)$title,
      'body'       => $body !== null ? (string)$body : null,
      'link_url'   => $link_url !== null ? (string)$link_url : null,
      'is_read'    => 0,
      'created_at' => date('Y-m-d H:i:s'),
    );
    $this->db->insert($this->table, $data);
    return $this->db->insert_id();
  }

  /**
   * Kirim notifikasi ke semua user yang punya role tertentu.
   * Jika $branch_id diisi, maka hanya user cabang itu saja.
   */
  public function notify_roles(array $role_codes, $title, $body = null, $link_url = null, $branch_id = null)
  {
    if (empty($role_codes)) return 0;

    $this->db->select('u.id')
      ->from('auth_users u')
      ->join('auth_user_roles ur', 'ur.user_id = u.id')
      ->join('auth_roles r', 'r.id = ur.role_id')
      ->where_in('r.code', $role_codes)
      ->where('u.is_active', 1);

    if ($branch_id !== null) {
      $this->db->where('u.branch_id', (int)$branch_id);
    }

    $users = $this->db->get()->result_array();

    $count = 0;
    foreach ($users as $u) {
      $this->create((int)$u['id'], $title, $body, $link_url);
      $count++;
    }
    return $count;
  }

  public function mark_read($notif_id, $user_id)
  {
    $this->db->where('id', (int)$notif_id)
      ->where('to_user_id', (int)$user_id)
      ->update($this->table, array(
        'is_read' => 1,
        'read_at' => date('Y-m-d H:i:s'),
      ));
    return $this->db->affected_rows() > 0;
  }

  public function mark_all_read($user_id)
  {
    $this->db->where('to_user_id', (int)$user_id)
      ->where('is_read', 0)
      ->update($this->table, array(
        'is_read' => 1,
        'read_at' => date('Y-m-d H:i:s'),
      ));
    return $this->db->affected_rows();
  }
}
