<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Public_receipt_model extends CI_Model
{
  public function find_by_token($token)
  {
    $token = trim($token);

    $this->db->select("
      r.*,
      u.full_name AS issued_by_full_name,
      s.submission_no, s.applicant_name, s.whatsapp, s.zis_type_code,
      s.submitted_at, s.amount_money, s.fitrah_total_money, s.fitrah_total_kg,
      b.branch_name,
      a.branch_share_money, a.branch_amil_money, a.branch_dist_money, a.center_share_money,
      a.branch_share_rice_kg, a.branch_amil_rice_kg, a.branch_dist_rice_kg, a.center_share_rice_kg
    ");
    $this->db->from('trx_receipts r');
    $this->db->join('auth_users u', 'u.id = r.issued_by_user_id', 'left');
    $this->db->join('trx_submissions s', 's.id = r.submission_id', 'left');
    // NOTE: jangan join alias yang sama 2x (akan memicu error 1066 "Not unique table/alias")
    $this->db->join('mst_branches b', 'b.id = s.branch_id', 'left');
    $this->db->join('trx_allocations a', 'a.submission_id = s.id', 'left');
    $this->db->where('r.public_token', $token);
    $this->db->limit(1);

    $row = $this->db->get()->row();
    if (!$row) return null;

    $people = $this->db->order_by('seq_no','ASC')
      ->get_where('trx_submission_people', array('submission_id'=>(int)$row->submission_id))
      ->result();

    return array('row'=>$row, 'people'=>$people);
  }

  // BARU: list kwitansi berdasarkan whatsapp (untuk pilihan tanpa token)
  public function list_by_whatsapp($whatsapp, $limit = 20)
  {
    $whatsapp = trim((string)$whatsapp);
    if ($whatsapp === '') return array();

    $this->db->select("
      r.public_token, r.receipt_no, r.created_at as receipt_at,
      s.submission_no, s.applicant_name, s.zis_type_code,
      s.amount_money, s.fitrah_total_money, s.fitrah_total_kg,
      b.branch_name
    ");
    $this->db->from('trx_receipts r');
    $this->db->join('trx_submissions s', 's.id = r.submission_id', 'inner');
    $this->db->where('r.is_void', 0);
    $this->db->join('mst_branches b', 'b.id = s.branch_id', 'left');
    $this->db->where('s.whatsapp', $whatsapp);
    $this->db->order_by('r.created_at', 'DESC');
    $this->db->limit((int)$limit);

    return $this->db->get()->result();
  }
}
