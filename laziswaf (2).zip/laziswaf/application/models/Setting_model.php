<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Setting_model extends CI_Model
{
  public function get($key)
  {
    return $this->db->get_where('sys_settings', array('setting_key'=>$key), 1)->row_array();
  }

  public function get_text($key, $default = null)
  {
    $row = $this->get($key);
    $val = $row ? ($row['value_text'] ?? null) : null;
    return ($val !== null && $val !== '') ? $val : $default;
  }

  public function get_json($key, $default = array())
  {
    $row = $this->get($key);
    $val = $row ? ($row['value_json'] ?? null) : null;
    if (!$val) return $default;
    $decoded = json_decode($val, true);
    return is_array($decoded) ? $decoded : $default;
  }

  public function upsert($key, $value_text = null, $value_json = null, $updated_by = null)
  {
    $exists = $this->db->get_where('sys_settings', array('setting_key'=>$key), 1)->row_array();
    $data = array(
      'setting_key' => $key,
      'value_text'  => $value_text,
      'value_json'  => $value_json,
      'updated_by'  => $updated_by
    );

    if ($exists) {
      $this->db->where('setting_key', $key)->update('sys_settings', $data);
    } else {
      $this->db->insert('sys_settings', $data);
    }
  }

  // ===== Assets (BLOB) =====
  public function get_asset($key)
  {
    return $this->db->get_where('sys_assets', array('asset_key'=>$key), 1)->row_array();
  }

  public function upsert_asset($key, $mime_type, $data, $updated_by = null)
  {
    $exists = $this->db->get_where('sys_assets', array('asset_key'=>$key), 1)->row_array();
    $row = array(
      'asset_key'  => $key,
      'mime_type'  => $mime_type,
      'data'       => $data,
      'updated_by' => $updated_by
    );

    if ($exists) {
      $this->db->where('asset_key', $key)->update('sys_assets', $row);
    } else {
      $this->db->insert('sys_assets', $row);
    }
    return true;
  }

}
