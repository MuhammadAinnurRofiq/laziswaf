<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Center_receipt_model extends CI_Model
{
  public function branches_active()
  {
    return $this->db->order_by('branch_name','ASC')
      ->get_where('mst_branches', array('is_active'=>1))
      ->result();
  }

  public function zis_types_active()
  {
    return $this->db->order_by('name','ASC')
      ->get_where('mst_zis_types', array('is_active'=>1))
      ->result();
  }

    public function search($filters, $limit = 20, $offset = 0)
  {
    // ===========================
    // Query #1: total rows
    // ===========================
    $this->db->from('trx_receipts r');
    $this->db->join('trx_submissions s', 's.id = r.submission_id');
    $this->db->join('mst_branches b', 'b.id = s.branch_id', 'left');

    // hanya kuitansi valid (bukan VOID) + submission bukan DELETED
    $this->db->where('r.is_void', 0);
    $this->db->where("COALESCE(s.status,'') <> 'DELETED'", null, false);

    $this->apply_filters($filters);

    $total = (int)$this->db->count_all_results(); // reset builder

    // ===========================
    // Query #2: data rows
    // ===========================
    $this->db->select("
      r.id AS receipt_id,
      r.submission_id,
      r.receipt_no,
      r.public_token,
      r.issued_at,
      r.issued_by_user_id,
      u.full_name AS issued_by_full_name,

      s.submission_no,
      s.branch_id,
      s.zis_type_code,
      s.applicant_name,
      s.whatsapp,
      s.submitted_at,
      s.status,

      b.branch_name,

      COALESCE(NULLIF(s.amount_money,0), NULLIF(s.fitrah_total_money,0)) AS money_amount,
      s.fitrah_total_kg AS rice_kg
    ", false);

    $this->db->from('trx_receipts r');
    $this->db->join('auth_users u', 'u.id = r.issued_by_user_id', 'left');
    $this->db->join('trx_submissions s', 's.id = r.submission_id');
    $this->db->join('mst_branches b', 'b.id = s.branch_id', 'left');

    $this->db->where('r.is_void', 0);
    $this->db->where("COALESCE(s.status,'') <> 'DELETED'", null, false);

    $this->apply_filters($filters);

    $this->db->order_by('r.issued_at', 'DESC');
    $this->db->limit((int)$limit, (int)$offset);

    $rows = $this->db->get()->result();

    return array('total'=>$total, 'rows'=>$rows);
  }


    public function export_rows($filters, $limit = 5000)
  {
    $this->db->select("
      r.receipt_no,
      r.issued_at,
      u.full_name AS issued_by_full_name,
      s.submission_no,
      s.zis_type_code,
      s.applicant_name,
      s.whatsapp,
      b.branch_name,
      s.status,
      COALESCE(NULLIF(s.amount_money,0), NULLIF(s.fitrah_total_money,0)) AS money_amount,
      s.fitrah_total_kg AS rice_kg,
      r.public_token
    ", false);

    $this->db->from('trx_receipts r');
    $this->db->join('auth_users u', 'u.id = r.issued_by_user_id', 'left');
    $this->db->join('trx_submissions s', 's.id = r.submission_id');
    $this->db->join('mst_branches b', 'b.id = s.branch_id', 'left');

    $this->db->where('r.is_void', 0);
    $this->db->where("COALESCE(s.status,'') <> 'DELETED'", null, false);

    $this->apply_filters($filters);

    $this->db->order_by('r.issued_at', 'DESC');
    $this->db->limit((int)$limit);

    return $this->db->get()->result_array();
  }


  private function apply_filters($f)
  {
    // scope: all | branch | center
    if (!empty($f['scope'])) {
      if ($f['scope'] === 'branch') {
        $this->db->where('s.branch_id IS NOT NULL', null, false);
      } elseif ($f['scope'] === 'center') {
        // jika pusat Anda simpan sebagai NULL atau 0, pakai kondisi ini:
        $this->db->group_start();
        $this->db->where('s.branch_id IS NULL', null, false);
        $this->db->or_where('s.branch_id', 0);
        $this->db->group_end();
      }
    }

    if (!empty($f['branch_id']) && ctype_digit((string)$f['branch_id'])) {
      $this->db->where('s.branch_id', (int)$f['branch_id']);
    }

    if (!empty($f['zis_type'])) {
      $this->db->where('s.zis_type_code', (string)$f['zis_type']);
    }

    if (!empty($f['status'])) {
      $this->db->where('s.status', (string)$f['status']);
    }

    // filter tanggal terbit kuitansi
    if (!empty($f['date_from'])) {
      $this->db->where('r.issued_at >=', $f['date_from'].' 00:00:00');
    }
    if (!empty($f['date_to'])) {
      $this->db->where('r.issued_at <=', $f['date_to'].' 23:59:59');
    }

    if (!empty($f['q'])) {
      $q = trim((string)$f['q']);
      $this->db->group_start();
      $this->db->like('r.receipt_no', $q);
      $this->db->or_like('s.submission_no', $q);
      $this->db->or_like('s.applicant_name', $q);
      $this->db->or_like('s.whatsapp', $q);
      $this->db->or_like('b.branch_name', $q);
      $this->db->group_end();
    }
  }
}
