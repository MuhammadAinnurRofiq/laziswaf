<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Receipt_model extends CI_Model
{
  public function create_receipt($submission_id, $issued_by_user_id, $receipt_no)
  {
    $token = $this->unique_token();

    $data = array(
      'submission_id' => (int)$submission_id,
      'receipt_no' => $receipt_no,
      'public_token' => $token,
      'issued_at' => date('Y-m-d H:i:s'),
      'issued_by_user_id' => (int)$issued_by_user_id,
      'template_version' => 'v1',
      'template_snapshot_json' => null,
      'privacy_flags_json' => null,
      'pdf_path' => null
    );

    $this->db->insert('trx_receipts', $data);
    return $this->db->insert_id() ? (object)$data : null;
  }

  private function unique_token()
  {
    for ($i=0; $i<5; $i++) {
      $token = bin2hex(random_bytes(16)); // 32 chars
      $exists = $this->db->get_where('trx_receipts', array('public_token'=>$token), 1)->row();
      if (!$exists) return $token;
    }
    // fallback
    return bin2hex(random_bytes(24));
  }

  public function find_by_id($id)
  {
    return $this->db->get_where('trx_receipts', array('id'=>(int)$id), 1)->row();
  }

  public function list_by_branch($branch_id)
  {
    $this->db->select('r.*, s.submission_no, s.applicant_name, s.zis_type_code, s.submitted_at, s.amount_money, s.fitrah_total_money, s.fitrah_total_kg');
    $this->db->from('trx_receipts r');
    $this->db->where('r.is_void', 0);
    $this->db->join('trx_submissions s', 's.id = r.submission_id');
    $this->db->where('s.branch_id', (int)$branch_id);
    $this->db->order_by('r.issued_at','DESC');
    return $this->db->get()->result();
  }
}
