<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Submission_model extends CI_Model
{
  public function insert_submission($data, $people_names = array())
  {
    $this->db->trans_begin();

    $this->db->insert('trx_submissions', $data);
    $submission_id = (int)$this->db->insert_id();

    if (!empty($people_names)) {
      $seq = 1;
      foreach ($people_names as $name) {
        $name = trim($name);
        if ($name === '') continue;

        $this->db->insert('trx_submission_people', array(
          'submission_id' => $submission_id,
          'seq_no' => $seq++,
          'person_name' => $name
        ));
      }
    }

    if ($this->db->trans_status() === FALSE) {
      $this->db->trans_rollback();
      return null;
    }

    $this->db->trans_commit();
    return $submission_id;
  }

  public function find_by_no_and_wa($submission_no, $whatsapp)
  {
    return $this->db->get_where('trx_submissions', array(
      'submission_no' => $submission_no,
      'whatsapp' => $whatsapp
    ), 1)->row();
  }

  public function find_receipt_by_submission($submission_id)
  {
    return $this->db->get_where('trx_receipts', array(
      'submission_id' => (int)$submission_id
    ), 1)->row();
  }
}
