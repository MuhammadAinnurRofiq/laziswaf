<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Center_report_model extends CI_Model
{
    public function search($filters, $limit=20, $offset=0)
  {
    $filters = is_array($filters) ? $filters : array();

    // helper kecil untuk apply filter agar konsisten
    $apply = function() use ($filters) {
      if (!empty($filters['branch_id']) && ctype_digit((string)$filters['branch_id'])) {
        $this->db->where('r.branch_id', (int)$filters['branch_id']);
      }
      if (!empty($filters['status'])) {
        $this->db->where('r.status', strtoupper((string)$filters['status']));
      }
      if (!empty($filters['year']) && ctype_digit((string)$filters['year'])) {
        $this->db->where('p.year', (int)$filters['year']);
      }
      if (!empty($filters['month']) && ctype_digit((string)$filters['month'])) {
        $this->db->where('p.month', (int)$filters['month']);
      }
    };

    // ======================
    // (1) TOTAL ROWS
    // ======================
    $this->db->from('rpt_branch_reports r');
    $this->db->join('rpt_periods p', 'p.id = r.period_id');
    $this->db->join('mst_branches b', 'b.id = r.branch_id', 'left');
    $this->db->join('auth_users u_gen', 'u_gen.id = r.generated_by', 'left');
    $this->db->join('auth_users u_rev', 'u_rev.id = r.reviewed_by', 'left');
    $apply();
    $total = (int)$this->db->count_all_results(); // reset builder

    // ======================
    // (2) DATA ROWS (total live yang menghormati VOID)
    // ======================
    $this->db->select("r.*, p.year, p.month, b.branch_name,
      (SELECT COALESCE(SUM(l.money_amount),0)
         FROM rpt_branch_report_lines l
         LEFT JOIN trx_receipts rc2 ON rc2.id = l.receipt_id
        WHERE l.report_id = r.id AND COALESCE(rc2.is_void,0)=0) AS total_money_calc,
      (SELECT COALESCE(SUM(l.rice_kg),0)
         FROM rpt_branch_report_lines l
         LEFT JOIN trx_receipts rc2 ON rc2.id = l.receipt_id
        WHERE l.report_id = r.id AND COALESCE(rc2.is_void,0)=0) AS total_rice_kg_calc
    ", false);

    $this->db->from('rpt_branch_reports r');
    $this->db->join('rpt_periods p', 'p.id = r.period_id');
    $this->db->join('mst_branches b', 'b.id = r.branch_id', 'left');
    $apply();

    $this->db->order_by('p.year', 'DESC');
    $this->db->order_by('p.month', 'DESC');
    $this->db->order_by('r.id', 'DESC');

    $this->db->limit((int)$limit, (int)$offset);
    $rows = $this->db->get()->result();

    // override total agar UI tidak menampilkan angka transaksi yang sudah VOID
    foreach ($rows as $x) {
      if (isset($x->total_money_calc))   $x->total_money = (float)$x->total_money_calc;
      if (isset($x->total_rice_kg_calc)) $x->total_rice_kg = (float)$x->total_rice_kg_calc;
    }

    return array('total'=>$total,'rows'=>$rows);
  }

public function bendahara_dashboard_metrics($period_id = null)
{
  $p = $this->get_period($period_id);
  if (!$p) return null;

  // =========================
  // (A) Total pemasukan (uang/beras) berdasarkan kuitansi periode tsb
  // =========================
  $inc = $this->db->select("
      SUM(COALESCE(NULLIF(s.amount_money,0), NULLIF(s.fitrah_total_money,0), 0)) AS total_money,
      SUM(COALESCE(s.fitrah_total_kg,0)) AS total_rice
    ", false)
    ->from('trx_receipts rc')
    ->join('trx_submissions s', 's.id = rc.submission_id')
      ->where('COALESCE(rc.is_void,0)=0', null, false)
      ->where("COALESCE(s.status,'') <> 'DELETED'", null, false)
    ->where('DATE(rc.issued_at) >=', $p->start_date)
    ->where('DATE(rc.issued_at) <=', $p->end_date)
    ->get()->row();

  $total_money = (float)($inc->total_money ?? 0);
  $total_rice  = (float)($inc->total_rice ?? 0);

  // pembagian global sesuai aturan (uang & beras)
  $branch_share_money = $total_money * 0.5;
  $center_share_money = $total_money * 0.5;

  $branch_amil_money  = $branch_share_money * 0.125;  // 12.5% dari porsi cabang
  $branch_dist_money  = $branch_share_money * 0.875;  // sisanya untuk distribusi/perbaikan

  $branch_share_rice = $total_rice * 0.5;
  $center_share_rice = $total_rice * 0.5;

  $branch_amil_rice  = $branch_share_rice * 0.125;
  $branch_dist_rice  = $branch_share_rice * 0.875;

  // =========================
  // (B) Jumlah orang/jiwa per kategori
  // - FITRAH/FIDYAH: pakai total jiwa/dependent (fallback 1)
  // - MAL/INFAQ: pakai jumlah submission (orang)
  // =========================
  $fitrah_people = (float)($this->db->select("SUM(COALESCE(NULLIF(s.jiwa_count,0), 1)) AS n", false)
  ->from('trx_receipts rc')
  ->join('trx_submissions s', 's.id = rc.submission_id')
    ->where('COALESCE(rc.is_void,0)=0', null, false)
    ->where("COALESCE(s.status,'') <> 'DELETED'", null, false)
  ->where('DATE(rc.issued_at) >=', $p->start_date)
  ->where('DATE(rc.issued_at) <=', $p->end_date)
  ->where('UPPER(s.zis_type_code)', 'FITRAH')
  ->get()->row()->n ?? 0);


  $fidyah_people = (float)($this->db->select("SUM(COALESCE(NULLIF(s.jiwa_count,0), 1)) AS n", false)
  ->from('trx_receipts rc')
  ->join('trx_submissions s', 's.id = rc.submission_id')
    ->where('COALESCE(rc.is_void,0)=0', null, false)
    ->where("COALESCE(s.status,'') <> 'DELETED'", null, false)
  ->where('DATE(rc.issued_at) >=', $p->start_date)
  ->where('DATE(rc.issued_at) <=', $p->end_date)
  ->where('UPPER(s.zis_type_code)', 'FIDYAH')
  ->get()->row()->n ?? 0);


  $mal_people = (int)$this->db->select("COUNT(DISTINCT s.id) AS n", false)
    ->from('trx_receipts rc')
    ->join('trx_submissions s', 's.id = rc.submission_id')
      ->where('COALESCE(rc.is_void,0)=0', null, false)
      ->where("COALESCE(s.status,'') <> 'DELETED'", null, false)
    ->where('DATE(rc.issued_at) >=', $p->start_date)
    ->where('DATE(rc.issued_at) <=', $p->end_date)
    ->where('UPPER(s.zis_type_code)', 'MAL')
    ->get()->row()->n ?? 0;

  $infaq_people = (int)$this->db->select("COUNT(DISTINCT s.id) AS n", false)
    ->from('trx_receipts rc')
    ->join('trx_submissions s', 's.id = rc.submission_id')
      ->where('COALESCE(rc.is_void,0)=0', null, false)
      ->where("COALESCE(s.status,'') <> 'DELETED'", null, false)
    ->where('DATE(rc.issued_at) >=', $p->start_date)
    ->where('DATE(rc.issued_at) <=', $p->end_date)
    ->where('UPPER(s.zis_type_code)', 'INFAQ')
    ->get()->row()->n ?? 0;


  // =========================
  // (B2) Rekap per jenis (transaksi, jiwa, uang, beras)
  // =========================
  $recap = array(
    'FITRAH' => array('trx'=>0,'jiwa'=>0,'money'=>0,'rice'=>0),
    'MAL'    => array('trx'=>0,'jiwa'=>0,'money'=>0,'rice'=>0),
    'FIDYAH' => array('trx'=>0,'jiwa'=>0,'money'=>0,'rice'=>0),
    'INFAQ'  => array('trx'=>0,'jiwa'=>0,'money'=>0,'rice'=>0),
  );

  $rows = $this->db->select("
      UPPER(s.zis_type_code) AS type,
      COUNT(DISTINCT s.id) AS trx,
      SUM(CASE WHEN UPPER(s.zis_type_code) IN ('FITRAH','FIDYAH')
               THEN COALESCE(NULLIF(s.jiwa_count,0), 1)
               ELSE 1 END) AS jiwa,
      SUM(COALESCE(NULLIF(s.amount_money,0), NULLIF(s.fitrah_total_money,0), 0)) AS money,
      SUM(COALESCE(s.fitrah_total_kg,0)) AS rice
    ", false)
    ->from('trx_receipts rc')
    ->join('trx_submissions s', 's.id = rc.submission_id')
      ->where('COALESCE(rc.is_void,0)=0', null, false)
      ->where("COALESCE(s.status,'') <> 'DELETED'", null, false)
    ->where('DATE(rc.issued_at) >=', $p->start_date)
    ->where('DATE(rc.issued_at) <=', $p->end_date)
    ->group_by('UPPER(s.zis_type_code)')
    ->get()->result_array();

  foreach ($rows as $r) {
    $t = strtoupper((string)($r['type'] ?? ''));
    if (!isset($recap[$t])) continue;
    $recap[$t]['trx']   = (int)($r['trx'] ?? 0);
    $recap[$t]['jiwa']  = (float)($r['jiwa'] ?? 0);
    $recap[$t]['money'] = (float)($r['money'] ?? 0);
    $recap[$t]['rice']  = (float)($r['rice'] ?? 0);
  }


  // =========================
  // (C) Status pelaporan cabang pada periode tsb
  // =========================
  $total_branches = (int)$this->db->where('is_active', 1)->count_all_results('mst_branches');

  $rep = $this->db->select("
      SUM(CASE WHEN r.status='APPROVED' THEN 1 ELSE 0 END) AS approved,
      SUM(CASE WHEN r.status IN ('SENT','REJECTED') THEN 1 ELSE 0 END) AS pending
    ", false)
    ->from('rpt_branch_reports r')
    ->where('r.period_id', (int)$p->id)
    ->get()->row();

  $approved = (int)($rep->approved ?? 0);
  $pending  = (int)($rep->pending ?? 0);

  // belum mengirim = total cabang - (approved + pending + draft)
  // tetapi Anda minta “belum mengirim” = belum mengirim laporan (tidak ada / DRAFT)
  $draft = (int)$this->db->from('rpt_branch_reports')
    ->where('period_id', (int)$p->id)
    ->where('status', 'DRAFT')
    ->count_all_results();

  $unreported = max(0, $total_branches - ($approved + $pending + $draft));

  return array(
    'period' => $p,

    'recap' => $recap,

    'total_money' => $total_money,
    'total_rice'  => $total_rice,

    'branch_share_money' => $branch_share_money,
    'center_share_money' => $center_share_money,
    'branch_amil_money'  => $branch_amil_money,
    'branch_dist_money'  => $branch_dist_money,

    'branch_share_rice' => $branch_share_rice,
    'center_share_rice' => $center_share_rice,
    'branch_amil_rice'  => $branch_amil_rice,
    'branch_dist_rice'  => $branch_dist_rice,

    'fitrah_people' => (float)$fitrah_people,
    'mal_people'    => (int)$mal_people,
    'fidyah_people' => (float)$fidyah_people,
    'infaq_people'  => (int)$infaq_people,

    'branches_total'      => $total_branches,
    'branches_approved'   => $approved,
    'branches_pending'    => $pending,   // SENT + REJECTED
    'branches_unreported' => $unreported,
  );
}


public function bendahara_dashboard_metrics_all_time()
{
  // =========================
  // Dashboard Pusat: mode "Semua Waktu" (ALL TIME)
  // Rekap & agregasi berdasarkan kuitansi yang pernah terbit
  // =========================

  // (A) Total pemasukan (uang/beras)
  $inc = $this->db->select("
      SUM(COALESCE(NULLIF(s.amount_money,0), NULLIF(s.fitrah_total_money,0), 0)) AS total_money,
      SUM(COALESCE(s.fitrah_total_kg,0)) AS total_rice
    ", false)
    ->from('trx_receipts rc')
    ->join('trx_submissions s', 's.id = rc.submission_id')
      ->where('COALESCE(rc.is_void,0)=0', null, false)
      ->where("COALESCE(s.status,'') <> 'DELETED'", null, false)
    ->get()->row();

  $total_money = (float)($inc->total_money ?? 0);
  $total_rice  = (float)($inc->total_rice ?? 0);

  // pembagian global sesuai aturan (uang & beras)
  $branch_share_money = $total_money * 0.5;
  $center_share_money = $total_money * 0.5;

  $branch_amil_money  = $branch_share_money * 0.125;  // 12.5% dari porsi cabang
  $branch_dist_money  = $branch_share_money * 0.875;

  $branch_share_rice = $total_rice * 0.5;
  $center_share_rice = $total_rice * 0.5;

  $branch_amil_rice  = $branch_share_rice * 0.125;
  $branch_dist_rice  = $branch_share_rice * 0.875;

  // (B) Jumlah orang/jiwa per kategori (ALL TIME)
  $fitrah_people = (float)($this->db->select("SUM(COALESCE(NULLIF(s.jiwa_count,0), 1)) AS n", false)
    ->from('trx_receipts rc')
    ->join('trx_submissions s', 's.id = rc.submission_id')
      ->where('COALESCE(rc.is_void,0)=0', null, false)
      ->where("COALESCE(s.status,'') <> 'DELETED'", null, false)
    ->where('UPPER(s.zis_type_code)', 'FITRAH')
    ->get()->row()->n ?? 0);

  $fidyah_people = (float)($this->db->select("SUM(COALESCE(NULLIF(s.jiwa_count,0), 1)) AS n", false)
    ->from('trx_receipts rc')
    ->join('trx_submissions s', 's.id = rc.submission_id')
      ->where('COALESCE(rc.is_void,0)=0', null, false)
      ->where("COALESCE(s.status,'') <> 'DELETED'", null, false)
    ->where('UPPER(s.zis_type_code)', 'FIDYAH')
    ->get()->row()->n ?? 0);

  $mal_people = (int)($this->db->select("COUNT(DISTINCT s.id) AS n", false)
    ->from('trx_receipts rc')
    ->join('trx_submissions s', 's.id = rc.submission_id')
      ->where('COALESCE(rc.is_void,0)=0', null, false)
      ->where("COALESCE(s.status,'') <> 'DELETED'", null, false)
    ->where('UPPER(s.zis_type_code)', 'MAL')
    ->get()->row()->n ?? 0);

  $infaq_people = (int)($this->db->select("COUNT(DISTINCT s.id) AS n", false)
    ->from('trx_receipts rc')
    ->join('trx_submissions s', 's.id = rc.submission_id')
      ->where('COALESCE(rc.is_void,0)=0', null, false)
      ->where("COALESCE(s.status,'') <> 'DELETED'", null, false)
    ->where('UPPER(s.zis_type_code)', 'INFAQ')
    ->get()->row()->n ?? 0);

  // (B2) Rekap kartu per jenis (ALL TIME)
  $recap = $this->dashboard_recap_all_time();

  // (C) Total cabang aktif (untuk referensi)
  $total_branches = (int)$this->db->where('is_active', 1)->count_all_results('mst_branches');

  return array(
    'period' => null,
    'recap'  => $recap,

    'total_money' => $total_money,
    'total_rice'  => $total_rice,

    'branch_share_money' => $branch_share_money,
    'center_share_money' => $center_share_money,
    'branch_amil_money'  => $branch_amil_money,
    'branch_dist_money'  => $branch_dist_money,

    'branch_share_rice' => $branch_share_rice,
    'center_share_rice' => $center_share_rice,
    'branch_amil_rice'  => $branch_amil_rice,
    'branch_dist_rice'  => $branch_dist_rice,

    'fitrah_people' => (float)$fitrah_people,
    'mal_people'    => (int)$mal_people,
    'fidyah_people' => (float)$fidyah_people,
    'infaq_people'  => (int)$infaq_people,

    // mode ALL TIME tidak menampilkan status pelaporan per periode
    'branches_total'      => $total_branches,
    'branches_approved'   => 0,
    'branches_pending'    => 0,
    'branches_unreported' => 0,
  );
}


public function dashboard_recap_all_time()
{
  // Rekap per jenis (ALL TIME) berdasarkan kuitansi yang pernah terbit
  $recap = array(
    'FITRAH' => array('trx'=>0,'jiwa'=>0,'money'=>0,'rice'=>0),
    'MAL'    => array('trx'=>0,'jiwa'=>0,'money'=>0,'rice'=>0),
    'FIDYAH' => array('trx'=>0,'jiwa'=>0,'money'=>0,'rice'=>0),
    'INFAQ'  => array('trx'=>0,'jiwa'=>0,'money'=>0,'rice'=>0),
  );

  $rows = $this->db->select("
      UPPER(s.zis_type_code) AS type,
      COUNT(DISTINCT s.id) AS trx,
      SUM(CASE WHEN UPPER(s.zis_type_code) IN ('FITRAH','FIDYAH')
               THEN COALESCE(NULLIF(s.jiwa_count,0), 1)
               ELSE 1 END) AS jiwa,
      SUM(COALESCE(NULLIF(s.amount_money,0), NULLIF(s.fitrah_total_money,0), 0)) AS money,
      SUM(COALESCE(s.fitrah_total_kg,0)) AS rice
    ", false)
    ->from('trx_receipts rc')
    ->join('trx_submissions s', 's.id = rc.submission_id')
      ->where('COALESCE(rc.is_void,0)=0', null, false)
      ->where("COALESCE(s.status,'') <> 'DELETED'", null, false)
    ->where_in('UPPER(s.zis_type_code)', array('FITRAH','MAL','FIDYAH','INFAQ'))
    ->group_by('UPPER(s.zis_type_code)')
    ->get()->result_array();

  foreach ($rows as $r) {
    $t = strtoupper((string)($r['type'] ?? ''));
    if (!isset($recap[$t])) continue;
    $recap[$t]['trx']   = (int)($r['trx'] ?? 0);
    $recap[$t]['jiwa']  = (float)($r['jiwa'] ?? 0);
    $recap[$t]['money'] = (float)($r['money'] ?? 0);
    $recap[$t]['rice']  = (float)($r['rice'] ?? 0);
  }

  return $recap;
}



  /**
   * ✅ FIX 2 (akar masalah):
   * Method list untuk halaman dashboard/reports.
   * Pakai builder (tanpa string SQL manual) agar tidak ada WHERE dobel / syntax rusak.
   */
  public function list_reports($filters = array(), $limit = 20, $offset = 0)
  {
    $this->db->select('r.*, p.year, p.month, b.branch_name, u_gen.full_name AS generated_by_name, u_rev.full_name AS reviewed_by_name');
    $this->db->from('rpt_branch_reports r');
    $this->db->join('rpt_periods p', 'p.id = r.period_id');
    $this->db->join('mst_branches b', 'b.id = r.branch_id', 'left');
    $this->db->join('auth_users u_gen', 'u_gen.id = r.generated_by', 'left');
    $this->db->join('auth_users u_rev', 'u_rev.id = r.reviewed_by', 'left');

    if (!empty($filters['branch_id'])) {
      $this->db->where('r.branch_id', (int)$filters['branch_id']);
    }
    if (!empty($filters['year'])) {
      $this->db->where('p.year', (int)$filters['year']);
    }
    if (!empty($filters['month'])) {
      $this->db->where('p.month', (int)$filters['month']);
    }
    if (!empty($filters['status'])) {
      $this->db->where('r.status', strtoupper((string)$filters['status']));
    }

    $this->db->order_by('p.year', 'DESC');
    $this->db->order_by('p.month', 'DESC');
    $this->db->order_by('r.id', 'DESC');
    $this->db->limit((int)$limit, (int)$offset);

    return $this->db->get()->result();
  }

  public function branches_active()
  {
    return $this->db->order_by('branch_name','ASC')
      ->get_where('mst_branches', array('is_active'=>1))->result();
  }

    public function find($id)
  {
    $this->db->select('r.*, p.year, p.month, p.start_date, p.end_date, b.branch_name, u_gen.full_name AS generated_by_name, u_rev.full_name AS reviewed_by_name');
    $this->db->from('rpt_branch_reports r');
    $this->db->join('rpt_periods p', 'p.id = r.period_id');
    $this->db->join('mst_branches b', 'b.id = r.branch_id', 'left');
    $this->db->join('auth_users u_gen', 'u_gen.id = r.generated_by', 'left');
    $this->db->join('auth_users u_rev', 'u_rev.id = r.reviewed_by', 'left');
    $this->db->where('r.id', (int)$id);
    $this->db->limit(1);
    $hdr = $this->db->get()->row();
    if (!$hdr) return null;

    // total live agar angka report ikut berubah saat ada transaksi VOID
    $tot = $this->db->select("
        COALESCE(SUM(l.money_amount),0) AS total_money,
        COALESCE(SUM(l.rice_kg),0) AS total_rice_kg
      ", false)
      ->from('rpt_branch_report_lines l')
      ->join('trx_receipts rc', 'rc.id = l.receipt_id', 'left')
      ->where('l.report_id', (int)$id)
      ->where('COALESCE(rc.is_void,0)=0', null, false)
      ->get()->row();

    $hdr->total_money   = (float)($tot->total_money ?? 0);
    $hdr->total_rice_kg = (float)($tot->total_rice_kg ?? 0);

    // ✅ join trx_allocations agar dapat split per item
    $lines = $this->db->select('
        l.*,
        s.submission_no, s.applicant_name, s.zis_type_code,
        rc.receipt_no,
        a.branch_share_money, a.branch_amil_money, a.branch_dist_money, a.center_share_money,
        a.branch_share_rice_kg, a.branch_amil_rice_kg, a.branch_dist_rice_kg, a.center_share_rice_kg
      ')
      ->from('rpt_branch_report_lines l')
      ->join('trx_submissions s', 's.id = l.submission_id')
      ->join('trx_receipts rc', 'rc.id = l.receipt_id', 'left')
      ->join('trx_allocations a', 'a.submission_id = s.id', 'left')
      ->where('l.report_id', (int)$id)
      ->where('COALESCE(rc.is_void,0)=0', null, false)
      ->where('COALESCE(a.is_void,0)=0', null, false)
      ->order_by('l.id ASC')
      ->get()->result();

    // ✅ total split (tempel ke hdr)
    $split = $this->db->select("
        SUM(COALESCE(a.branch_share_money,0)) AS branch_share_money,
        SUM(COALESCE(a.branch_amil_money,0))  AS branch_amil_money,
        SUM(COALESCE(a.branch_dist_money,0))  AS branch_dist_money,
        SUM(COALESCE(a.center_share_money,0)) AS center_share_money,

        SUM(COALESCE(a.branch_share_rice_kg,0)) AS branch_share_rice_kg,
        SUM(COALESCE(a.branch_amil_rice_kg,0))  AS branch_amil_rice_kg,
        SUM(COALESCE(a.branch_dist_rice_kg,0))  AS branch_dist_rice_kg,
        SUM(COALESCE(a.center_share_rice_kg,0)) AS center_share_rice_kg
      ", false)
      ->from('rpt_branch_report_lines l')
      ->join('trx_allocations a', 'a.submission_id = l.submission_id', 'left')
      ->join('trx_receipts rc', 'rc.id = l.receipt_id', 'left')
      ->where('l.report_id', (int)$id)
      ->where('COALESCE(rc.is_void,0)=0', null, false)
      ->where('COALESCE(a.is_void,0)=0', null, false)
      ->get()->row();

    $hdr->branch_share_money = (float)($split->branch_share_money ?? 0);
    $hdr->branch_amil_money  = (float)($split->branch_amil_money ?? 0);
    $hdr->branch_dist_money  = (float)($split->branch_dist_money ?? 0);
    $hdr->center_share_money = (float)($split->center_share_money ?? 0);

    $hdr->branch_share_rice_kg = (float)($split->branch_share_rice_kg ?? 0);
    $hdr->branch_amil_rice_kg  = (float)($split->branch_amil_rice_kg ?? 0);
    $hdr->branch_dist_rice_kg  = (float)($split->branch_dist_rice_kg ?? 0);
    $hdr->center_share_rice_kg = (float)($split->center_share_rice_kg ?? 0);

    return array('hdr'=>$hdr,'lines'=>$lines);
  }


  public function approve($id, $reviewer_user_id, $note='')
  {
    $r = $this->db->get_where('rpt_branch_reports', array('id'=>(int)$id), 1)->row();
    if (!$r) return array('ok'=>false,'msg'=>'Laporan tidak ditemukan.');
    if ($r->status !== 'SENT') return array('ok'=>false,'msg'=>'Hanya laporan SENT yang bisa di-approve.');

    $this->db->where('id',(int)$id)->update('rpt_branch_reports', array(
      'status'=>'APPROVED',
      'reviewed_by'=>(int)$reviewer_user_id,
      'reviewed_at'=>date('Y-m-d H:i:s'),
      'review_note'=>$note
    ));
    return array('ok'=>true);
  }

  public function reject($id, $reviewer_user_id, $note)
  {
    $note = trim((string)$note);
    if ($note === '') return array('ok'=>false,'msg'=>'Catatan wajib diisi saat reject.');

    $r = $this->db->get_where('rpt_branch_reports', array('id'=>(int)$id), 1)->row();
    if (!$r) return array('ok'=>false,'msg'=>'Laporan tidak ditemukan.');
    if ($r->status !== 'SENT') return array('ok'=>false,'msg'=>'Hanya laporan SENT yang bisa di-reject.');

    $this->db->where('id',(int)$id)->update('rpt_branch_reports', array(
      'status'=>'REJECTED',
      'reviewed_by'=>(int)$reviewer_user_id,
      'reviewed_at'=>date('Y-m-d H:i:s'),
      'review_note'=>$note
    ));
    return array('ok'=>true);
  }

    public function consolidation($year, $month)
  {
    // ringkas konsolidasi: total uang/beras per cabang + grand total
    // NOTE: pakai total live (exclude receipt VOID), bukan kolom total_money di header report
    $rows = $this->db->select("
        b.branch_name,
        COALESCE(SUM(CASE WHEN COALESCE(rc.is_void,0)=0 THEN l.money_amount ELSE 0 END),0) AS total_money,
        COALESCE(SUM(CASE WHEN COALESCE(rc.is_void,0)=0 THEN l.rice_kg ELSE 0 END),0) AS total_rice
      ", false)
      ->from('rpt_branch_reports r')
      ->join('rpt_periods p', 'p.id = r.period_id')
      ->join('mst_branches b', 'b.id = r.branch_id', 'left')
      ->join('rpt_branch_report_lines l', 'l.report_id = r.id', 'left')
      ->join('trx_receipts rc', 'rc.id = l.receipt_id', 'left')
      ->where('r.status','APPROVED')
      ->where('p.year',(int)$year)
      ->where('p.month',(int)$month)
      ->group_by('r.branch_id')
      ->order_by('b.branch_name','ASC')
      ->get()->result();

    $grand_money = 0; $grand_rice = 0;
    foreach($rows as $x){
      $grand_money += (float)$x->total_money;
      $grand_rice  += (float)$x->total_rice;
    }

    return array('rows'=>$rows, 'grand_money'=>$grand_money, 'grand_rice'=>$grand_rice);
  }

  public function periods_list($limit = 24)
  {
    return $this->db->order_by('year','DESC')
      ->order_by('month','DESC')
      ->limit((int)$limit)
      ->get('rpt_periods')
      ->result_array();
  }

  public function get_period($period_id = null, $year = null, $month = null)
  {
    if (!empty($period_id) && ctype_digit((string)$period_id)) {
      return $this->db->get_where('rpt_periods', array('id'=>(int)$period_id), 1)->row();
    }

    if (!empty($year) && !empty($month) && ctype_digit((string)$year) && ctype_digit((string)$month)) {
      return $this->db->get_where('rpt_periods', array('year'=>(int)$year, 'month'=>(int)$month), 1)->row();
    }

    // default: periode terbaru
    return $this->db->order_by('year','DESC')
      ->order_by('month','DESC')
      ->limit(1)
      ->get('rpt_periods')
      ->row();
  }

    public function branch_reporting_overview($period_id)
  {
    $p = $this->get_period($period_id);
    if (!$p) return null;

    // (1) daftar cabang aktif
    $branches = $this->db->order_by('branch_name','ASC')
      ->get_where('mst_branches', array('is_active'=>1))
      ->result();

    // (2) map laporan cabang pada periode tsb (jika ada)
    $reports = $this->db->select('r.*, b.branch_name')
      ->from('rpt_branch_reports r')
      ->join('mst_branches b', 'b.id = r.branch_id', 'left')
      ->where('r.period_id', (int)$p->id)
      ->get()->result();

    $report_map = array();
    foreach ($reports as $r) $report_map[(int)$r->branch_id] = $r;

    // (2b) total live untuk cabang yang sudah punya laporan (exclude receipt VOID)
    $reported_income_rows = $this->db->select("
        r.branch_id AS branch_id,
        COALESCE(SUM(l.money_amount),0) AS money_total,
        COALESCE(SUM(l.rice_kg),0) AS rice_total
      ", false)
      ->from('rpt_branch_reports r')
      ->join('rpt_branch_report_lines l', 'l.report_id = r.id', 'left')
      ->join('trx_receipts rc', 'rc.id = l.receipt_id', 'left')
      ->where('r.period_id', (int)$p->id)
      ->where('COALESCE(rc.is_void,0)=0', null, false)
      ->group_by('r.branch_id')
      ->get()->result();

    $reported_income_map = array();
    foreach ($reported_income_rows as $x) {
      $reported_income_map[(int)$x->branch_id] = array(
        'money' => (float)($x->money_total ?? 0),
        'rice'  => (float)($x->rice_total ?? 0),
      );
    }

    // (3) pendapatan periode tsb berdasarkan kuitansi (untuk cabang yang belum punya laporan)
    $income_rows = $this->db->select("
        s.branch_id AS branch_id,
        SUM(COALESCE(NULLIF(s.amount_money,0), NULLIF(s.fitrah_total_money,0), 0)) AS money_total,
        SUM(COALESCE(s.fitrah_total_kg,0)) AS rice_total
      ", false)
      ->from('trx_receipts rc')
      ->join('trx_submissions s', 's.id = rc.submission_id')
      ->where('COALESCE(rc.is_void,0)=0', null, false)
      ->where("COALESCE(s.status,'') <> 'DELETED'", null, false)
      ->where('DATE(rc.issued_at) >=', $p->start_date)
      ->where('DATE(rc.issued_at) <=', $p->end_date)
      ->group_by('s.branch_id')
      ->get()->result();

    $income_map = array();
    foreach ($income_rows as $x) {
      $income_map[(int)$x->branch_id] = array(
        'money' => (float)($x->money_total ?? 0),
        'rice'  => (float)($x->rice_total ?? 0),
      );
    }

    $unreported = array(); // belum kirim (NULL / DRAFT)
    $pending    = array(); // SENT / REJECTED
    $approved   = array(); // APPROVED

    foreach ($branches as $b) {
      $bid = (int)$b->id;
      $rep = $report_map[$bid] ?? null;

      $money = 0; $rice = 0;
      $status = 'BELUM';
      $report_id = null;

      if ($rep) {
        // pakai total live, fallback ke kolom report bila tidak ada line
        $money = (float)($reported_income_map[$bid]['money'] ?? ($rep->total_money ?? 0));
        $rice  = (float)($reported_income_map[$bid]['rice'] ?? ($rep->total_rice_kg ?? 0));
        $status = (string)$rep->status;
        $report_id = (int)$rep->id;
      } else {
        $money = (float)(($income_map[$bid]['money'] ?? 0));
        $rice  = (float)(($income_map[$bid]['rice'] ?? 0));
        $status = 'BELUM';
      }

      // jika laporan belum ada atau masih DRAFT -> belum mengirim
      if (!$rep || $status === 'DRAFT') {
        $unreported[] = (object) array(
          'branch_id'=>$bid, 'branch_name'=>$b->branch_name,
          'status'=>$status, 'report_id'=>$report_id,
          'money'=>$money, 'rice'=>$rice
        );
        continue;
      }

      if (in_array($status, array('SENT','REJECTED'), true)) {
        $pending[] = (object) array(
          'branch_id'=>$bid, 'branch_name'=>$b->branch_name,
          'status'=>$status, 'report_id'=>$report_id,
          'money'=>$money, 'rice'=>$rice
        );
        continue;
      }

      if ($status === 'APPROVED') {
        $approved[] = (object) array(
          'branch_id'=>$bid, 'branch_name'=>$b->branch_name,
          'status'=>$status, 'report_id'=>$report_id,
          'money'=>$money, 'rice'=>$rice
        );
      }
    }

    return array(
      'period'     => $p,
      'unreported' => $unreported,
      'pending'    => $pending,
      'approved'   => $approved,
    );
  }
}