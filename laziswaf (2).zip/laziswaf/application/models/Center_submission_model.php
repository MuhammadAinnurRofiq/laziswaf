<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Center_submission_model extends CI_Model
{
  public function branches_active()
  {
    return $this->db->order_by('branch_name','ASC')
      ->get_where('mst_branches', array('is_active'=>1))
      ->result();
  }

  public function zis_types_active()
  {
    return $this->db->order_by('name','ASC')
      ->get_where('mst_zis_types', array('is_active'=>1))
      ->result();
  }

  public function search($filters, $limit = 20, $offset = 0)
  {
    $this->db->start_cache();

    $this->db->select("s.*, b.branch_name, r.receipt_no, r.public_token, r.is_void AS receipt_is_void");
    $this->db->from('trx_submissions s');
    $this->db->join('mst_branches b', 'b.id = s.branch_id', 'left');
    $this->db->join('trx_receipts r', 'r.submission_id = s.id', 'left');

    $this->apply_filters($filters);

    $this->db->stop_cache();

    // total
    $total = (int)$this->db->count_all_results('', FALSE);

    // rows
    $this->db->order_by('s.submitted_at', 'DESC');
    $this->db->limit((int)$limit, (int)$offset);
    $rows = $this->db->get()->result();

    $this->db->flush_cache();

    return array('total'=>$total, 'rows'=>$rows);
  }

  public function find_detail($id)
  {
    $this->db->select("
      s.*,
      b.branch_name, b.branch_code,
      r.receipt_no, r.public_token, r.issued_at, r.is_void AS receipt_is_void, r.voided_at, r.void_reason,
      p.method_id, p.amount_money AS paid_money, p.amount_rice_kg AS paid_rice, p.received_at,
      a.total_money, a.total_rice_kg,
      a.branch_share_money, a.branch_amil_money, a.branch_dist_money, a.center_share_money,
      a.branch_share_rice_kg, a.branch_amil_rice_kg, a.branch_dist_rice_kg, a.center_share_rice_kg
    ");
    $this->db->from('trx_submissions s');
    $this->db->join('mst_branches b', 'b.id = s.branch_id', 'left');
    $this->db->join('trx_receipts r', 'r.submission_id = s.id', 'left');
    $this->db->join('trx_payments p', 'p.submission_id = s.id', 'left');
    $this->db->join('trx_allocations a', 'a.submission_id = s.id', 'left');
    $this->db->where('s.id', (int)$id);
    $this->db->limit(1);

    $sub = $this->db->get()->row();
    if (!$sub) return null;

    $people = $this->db->order_by('seq_no','ASC')
      ->get_where('trx_submission_people', array('submission_id'=>(int)$id))
      ->result();

    $logs = $this->db->select('l.*, u.full_name AS actor_full_name')
      ->from('trx_approval_logs l')
      ->join('auth_users u', 'u.id = l.actor_user_id', 'left')
      ->where('l.submission_id', (int)$id)
      ->order_by('l.created_at','DESC')
      ->get()->result();

    return array('sub'=>$sub, 'people'=>$people, 'logs'=>$logs);
  }


  public function void_transaction($submission_id, $actor_user_id, $reason = '')
  {
    $submission_id = (int)$submission_id;
    $actor_user_id = (int)$actor_user_id;
    $reason = trim((string)$reason);
    if ($reason === '') $reason = 'VOID oleh pusat';

    $now = date('Y-m-d H:i:s');

    $this->db->trans_begin();

    // update submission: tandai DELETED (soft delete)
    $this->db->where('id', $submission_id)->update('trx_submissions', array(
      'status'     => 'DELETED',
      'deleted_at' => $now,
      'deleted_by' => ($actor_user_id > 0 ? $actor_user_id : null),
      'updated_at' => $now,
      'updated_by' => ($actor_user_id > 0 ? $actor_user_id : null),
    ));

    // VOID receipt/payment/allocation (soft)
    $voidData = array(
      'is_void'    => 1,
      'voided_at'  => $now,
      'voided_by'  => ($actor_user_id > 0 ? $actor_user_id : null),
      'void_reason'=> $reason,
      );

    $this->db->where('submission_id', $submission_id)->update('trx_receipts', $voidData);
    $this->db->where('submission_id', $submission_id)->update('trx_payments', $voidData);
    // trx_allocations memiliki created_at, tapi kita VOID saja
    $this->db->where('submission_id', $submission_id)->update('trx_allocations', $voidData);

    // log approval
    $this->db->insert('trx_approval_logs', array(
      'submission_id'  => $submission_id,
      'action'         => 'VOID_BY_CENTER',
      'note'           => $reason,
      'actor_user_id'  => ($actor_user_id > 0 ? $actor_user_id : null),
      'created_at'     => $now,
    ));

    if ($this->db->trans_status() === false) {
      $this->db->trans_rollback();
      return false;
    }
    $this->db->trans_commit();
    return true;
  }


  private function apply_filters($f)
  {
    // branch_id
    if (!empty($f['branch_id']) && ctype_digit((string)$f['branch_id'])) {
      $this->db->where('s.branch_id', (int)$f['branch_id']);
    }

    // zis_type
    if (!empty($f['zis_type'])) {
      $this->db->where('s.zis_type_code', (string)$f['zis_type']);
    }

    // status
    if (!empty($f['status'])) {
      $this->db->where('s.status', (string)$f['status']);
    }

    // date range (submitted_at)
    if (!empty($f['date_from'])) {
      $this->db->where('s.submitted_at >=', $f['date_from'].' 00:00:00');
    }
    if (!empty($f['date_to'])) {
      $this->db->where('s.submitted_at <=', $f['date_to'].' 23:59:59');
    }

    // keyword search
    if (!empty($f['q'])) {
      $q = trim((string)$f['q']);
      $this->db->group_start();
      $this->db->like('s.submission_no', $q);
      $this->db->or_like('s.applicant_name', $q);
      $this->db->or_like('s.whatsapp', $q);
      $this->db->or_like('r.receipt_no', $q);
      $this->db->group_end();
    }
  }
}
