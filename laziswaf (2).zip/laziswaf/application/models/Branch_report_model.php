<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Branch_report_model extends CI_Model
{
  public function list_by_branch($branch_id)
  {
    return $this->db->select('r.*, p.year, p.month, u_gen.full_name AS generated_by_name, u_rev.full_name AS reviewed_by_name')
      ->from('rpt_branch_reports r')
      ->join('rpt_periods p', 'p.id = r.period_id')
      ->join('auth_users u_gen', 'u_gen.id = r.generated_by', 'left')
      ->join('auth_users u_rev', 'u_rev.id = r.reviewed_by', 'left')
      ->where('r.branch_id', (int)$branch_id)
      ->order_by('p.year DESC, p.month DESC, r.id DESC')
      ->get()->result();
  }

  public function periods()
  {
    return $this->db->order_by('year DESC, month DESC')->get('rpt_periods')->result();
  }

  // ✅ TAMBAHAN: dipakai di BranchReports/index
  public function periods_list($limit = 24)
  {
    return $this->db->order_by('year','DESC')
      ->order_by('month','DESC')
      ->limit((int)$limit)
      ->get('rpt_periods')
      ->result_array();
  }

  public function find_report($id, $branch_id = null)
  {
    $this->db->select('r.*, p.year, p.month, p.start_date, p.end_date, b.branch_name, u_gen.full_name AS generated_by_name, u_rev.full_name AS reviewed_by_name');
    $this->db->from('rpt_branch_reports r');
    $this->db->join('rpt_periods p', 'p.id = r.period_id');
    $this->db->join('mst_branches b', 'b.id = r.branch_id', 'left');
    $this->db->join('auth_users u_gen', 'u_gen.id = r.generated_by', 'left');
    $this->db->join('auth_users u_rev', 'u_rev.id = r.reviewed_by', 'left');
    $this->db->where('r.id', (int)$id);
    if ($branch_id !== null) $this->db->where('r.branch_id', (int)$branch_id);
    $this->db->limit(1);
    $hdr = $this->db->get()->row();
    if (!$hdr) return null;

    // ✅ total live: exclude kuitansi/alokasi yang sudah VOID (agar angka laporan ikut berubah)
    $tot = $this->db->select("
        COALESCE(SUM(CASE WHEN COALESCE(rc.is_void,0)=0 THEN l.money_amount ELSE 0 END),0) AS total_money,
        COALESCE(SUM(CASE WHEN COALESCE(rc.is_void,0)=0 THEN l.rice_kg ELSE 0 END),0) AS total_rice_kg
      ", false)
      ->from('rpt_branch_report_lines l')
      ->join('trx_receipts rc', 'rc.id = l.receipt_id', 'left')
      ->where('l.report_id', (int)$id)
      ->get()->row();
    $hdr->total_money   = (float)($tot->total_money ?? 0);
    $hdr->total_rice_kg = (float)($tot->total_rice_kg ?? 0);


    // ✅ GANTI QUERY LINES: ikut ambil pembagian per item + total split
    $lines = $this->db->select('
        l.*,
        s.submission_no, s.applicant_name, s.whatsapp, s.zis_type_code,
        rc.receipt_no,
        a.branch_share_money, a.branch_amil_money, a.branch_dist_money, a.center_share_money,
        a.branch_share_rice_kg, a.branch_amil_rice_kg, a.branch_dist_rice_kg, a.center_share_rice_kg
      ')
      ->from('rpt_branch_report_lines l')
      ->join('trx_submissions s', 's.id = l.submission_id')
      ->join('trx_receipts rc', 'rc.id = l.receipt_id', 'left')
      ->join('trx_allocations a', 'a.submission_id = s.id', 'left')
      ->where('l.report_id', (int)$id)
      ->where('COALESCE(rc.is_void,0)=0', null, false)
      ->where('COALESCE(a.is_void,0)=0', null, false)
      ->order_by('l.id ASC')
      ->get()->result();

    // ✅ TOTAL SPLIT (disuntikkan ke $hdr)
    $split = $this->db->select("
        SUM(COALESCE(a.branch_share_money,0)) AS branch_share_money,
        SUM(COALESCE(a.branch_amil_money,0))  AS branch_amil_money,
        SUM(COALESCE(a.branch_dist_money,0))  AS branch_dist_money,
        SUM(COALESCE(a.center_share_money,0)) AS center_share_money,

        SUM(COALESCE(a.branch_share_rice_kg,0)) AS branch_share_rice_kg,
        SUM(COALESCE(a.branch_amil_rice_kg,0))  AS branch_amil_rice_kg,
        SUM(COALESCE(a.branch_dist_rice_kg,0))  AS branch_dist_rice_kg,
        SUM(COALESCE(a.center_share_rice_kg,0)) AS center_share_rice_kg
      ", false)
      ->from('rpt_branch_report_lines l')
      ->join('trx_allocations a', 'a.submission_id = l.submission_id', 'left')
      ->where('l.report_id', (int)$id)
      ->where('COALESCE(a.is_void,0)=0', null, false)
      ->get()->row();

    $hdr->branch_share_money = (float)($split->branch_share_money ?? 0);
    $hdr->branch_amil_money  = (float)($split->branch_amil_money ?? 0);
    $hdr->branch_dist_money  = (float)($split->branch_dist_money ?? 0);
    $hdr->center_share_money = (float)($split->center_share_money ?? 0);

    $hdr->branch_share_rice_kg = (float)($split->branch_share_rice_kg ?? 0);
    $hdr->branch_amil_rice_kg  = (float)($split->branch_amil_rice_kg ?? 0);
    $hdr->branch_dist_rice_kg  = (float)($split->branch_dist_rice_kg ?? 0);
    $hdr->center_share_rice_kg = (float)($split->center_share_rice_kg ?? 0);

    return array('hdr'=>$hdr, 'lines'=>$lines);
  }

  public function create_report_from_period($branch_id, $period_id, $user_id)
  {
    $p = $this->db->get_where('rpt_periods', array('id'=>(int)$period_id), 1)->row();
    if (!$p) return array('ok'=>false, 'msg'=>'Periode tidak ditemukan.');

    $exists = $this->db->get_where('rpt_branch_reports', array(
      'branch_id'=>(int)$branch_id,
      'period_id'=>(int)$period_id
    ), 1)->row();
    if ($exists) return array('ok'=>false, 'msg'=>'Laporan periode ini sudah ada.');

    $rows = $this->db->select("
        s.id AS submission_id,
        rc.id AS receipt_id,
        rc.issued_at,
        COALESCE(NULLIF(s.amount_money,0), NULLIF(s.fitrah_total_money,0), 0) AS money_amount,
        COALESCE(s.fitrah_total_kg,0) AS rice_kg
      ", false)
      ->from('trx_submissions s')
      ->join('trx_receipts rc', 'rc.submission_id = s.id')
      ->where('COALESCE(rc.is_void,0)=0', null, false)
      ->where('s.branch_id', (int)$branch_id)
      ->where('s.status', 'BRANCH_APPROVED')
      ->where('DATE(rc.issued_at) >=', $p->start_date)
      ->where('DATE(rc.issued_at) <=', $p->end_date)
      ->order_by('rc.issued_at', 'ASC')
      ->get()->result();

    if (empty($rows)) return array('ok'=>false, 'msg'=>'Tidak ada data approved pada periode ini.');

    $ym = sprintf('%04d%02d', $p->year, $p->month);
    $prefix = 'RPT-'.$branch_id.'-'.$ym.'-';
    $last = $this->db->like('report_no', $prefix)->order_by('id','DESC')->get('rpt_branch_reports',1)->row();
    $seq = 1;
    if ($last && preg_match('/(\d+)$/', $last->report_no, $m)) $seq = (int)$m[1] + 1;
    $report_no = $prefix.str_pad((string)$seq, 4, '0', STR_PAD_LEFT);

    $total_money = 0; $total_rice = 0;
    foreach($rows as $r){
      $total_money += (float)$r->money_amount;
      $total_rice  += (float)$r->rice_kg;
    }

    $this->db->trans_start();

    $this->db->insert('rpt_branch_reports', array(
      'report_no' => $report_no,
      'branch_id' => (int)$branch_id,
      'period_id' => (int)$period_id,
      'status' => 'DRAFT',
      'total_money' => $total_money,
      'total_rice_kg' => $total_rice,
      'generated_by' => (int)$user_id,
      'generated_at' => date('Y-m-d H:i:s')
    ));
    $report_id = (int)$this->db->insert_id();

    foreach($rows as $r){
      $this->db->insert('rpt_branch_report_lines', array(
        'report_id' => $report_id,
        'submission_id' => (int)$r->submission_id,
        'receipt_id' => (int)$r->receipt_id,
        'money_amount' => (float)$r->money_amount,
        'rice_kg' => (float)$r->rice_kg
      ));
    }

    $this->db->trans_complete();

    if ($this->db->trans_status() === false) {
      return array('ok'=>false, 'msg'=>'Gagal membuat laporan (DB error).');
    }

    return array('ok'=>true, 'id'=>$report_id);
  }

  public function send_report($id, $branch_id)
  {
    $r = $this->db->get_where('rpt_branch_reports', array('id'=>(int)$id, 'branch_id'=>(int)$branch_id), 1)->row();
    if (!$r) return array('ok'=>false, 'msg'=>'Laporan tidak ditemukan.');
    if ($r->status !== 'DRAFT') return array('ok'=>false, 'msg'=>'Hanya laporan DRAFT yang bisa dikirim.');

    $this->db->where('id', (int)$id)->update('rpt_branch_reports', array(
      'status' => 'SENT',
      'sent_at' => date('Y-m-d H:i:s')
    ));

    return array('ok'=>true);
  }

  // ✅ TAMBAHAN: refresh laporan
  public function refresh_report($id, $branch_id, $user_id)
{
  $id = (int)$id; $branch_id = (int)$branch_id;

  $r = $this->db->get_where('rpt_branch_reports', array(
    'id' => $id,
    'branch_id' => $branch_id
  ), 1)->row();
  if (!$r) return array('ok'=>false, 'msg'=>'Laporan tidak ditemukan.');

  $p = $this->db->get_where('rpt_periods', array('id'=>(int)$r->period_id), 1)->row();
  if (!$p) return array('ok'=>false, 'msg'=>'Periode tidak valid.');

  // ambil ulang dari kuitansi yg terbit pada periode itu
  $rows = $this->db->select("
      s.id AS submission_id,
      rc.id AS receipt_id,
      rc.issued_at,
      COALESCE(NULLIF(s.amount_money,0), NULLIF(s.fitrah_total_money,0)) AS money_amount,
      COALESCE(s.fitrah_total_kg,0) AS rice_kg
    ", false)
    ->from('trx_submissions s')
    ->join('trx_receipts rc', 'rc.submission_id = s.id', 'inner')
    ->where('s.branch_id', $branch_id)
    ->where_in('s.status', array('BRANCH_APPROVED','CENTER_LOCKED'))
    ->where('DATE(rc.issued_at) >=', $p->start_date)
    ->where('DATE(rc.issued_at) <=', $p->end_date)
    ->order_by('rc.issued_at', 'ASC')
    ->get()->result();

  if (empty($rows)) return array('ok'=>false, 'msg'=>'Tidak ada kuitansi pada periode ini.');

  $this->db->trans_begin();

  $this->db->where('report_id', $id)->delete('rpt_branch_report_lines');

  $total_money = 0; $total_rice = 0;
  foreach ($rows as $x) {
    $m = (float)($x->money_amount ?? 0);
    $k = (float)($x->rice_kg ?? 0);

    $this->db->insert('rpt_branch_report_lines', array(
      'report_id' => $id,
      'submission_id' => (int)$x->submission_id,
      'receipt_id' => (int)$x->receipt_id,
      'money_amount' => $m,
      'rice_kg' => $k,
    ));

    $total_money += $m;
    $total_rice  += $k;
  }

  $update = array(
    'total_money'   => $total_money,
    'total_rice_kg' => $total_rice,
    'generated_by'  => (int)$user_id,
    'generated_at'  => date('Y-m-d H:i:s'),
  );

  // kalau sudah pernah dikirim/diapprove, refresh harus balik DRAFT
  if ($r->status !== 'DRAFT') {
    $update['status'] = 'DRAFT';
    $update['sent_at'] = null;
    $update['reviewed_by'] = null;
    $update['reviewed_at'] = null;
    $update['review_note'] = null;
  }

  $this->db->where('id', $id)->update('rpt_branch_reports', $update);

  if ($this->db->trans_status() === false) {
    $this->db->trans_rollback();
    return array('ok'=>false, 'msg'=>'Gagal refresh laporan.');
  }
  $this->db->trans_commit();

  return array('ok'=>true);
}

}