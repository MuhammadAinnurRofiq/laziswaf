<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Running_number_model extends CI_Model
{
  /**
   * Generate nomor otomatis berbasis sys_running_numbers (per tahun+bulan).
   * Return contoh: SUB-202601-000001
   */
  public function next($key_name)
  {
    $year  = (int)date('Y');
    $month = (int)date('n');

    $this->db->trans_begin();

    // Lock row jika ada
    $row = $this->db->query(
      "SELECT * FROM sys_running_numbers WHERE key_name=? AND year=? AND month=? FOR UPDATE",
      array($key_name, $year, $month)
    )->row();

    if (!$row) {
      // Jika belum ada, buat
      $prefix = $this->default_prefix($key_name);
      $this->db->insert('sys_running_numbers', array(
        'key_name' => $key_name,
        'prefix'   => $prefix,
        'year'     => $year,
        'month'    => $month,
        'last_number' => 0
      ));

      $row = $this->db->query(
        "SELECT * FROM sys_running_numbers WHERE key_name=? AND year=? AND month=? FOR UPDATE",
        array($key_name, $year, $month)
      )->row();
    }

    $next = ((int)$row->last_number) + 1;

    $this->db->where('id', (int)$row->id)->update('sys_running_numbers', array(
      'last_number' => $next
    ));

    if ($this->db->trans_status() === FALSE) {
      $this->db->trans_rollback();
      return null;
    }

    $this->db->trans_commit();

    $ym = sprintf('%04d%02d', $year, $month);
    $num = str_pad((string)$next, 6, '0', STR_PAD_LEFT);

    return $row->prefix . '-' . $ym . '-' . $num;
  }

  private function default_prefix($key_name)
  {
    switch ($key_name) {
      case 'SUBMISSION_NO': return 'SUB';
      case 'RECEIPT_NO': return 'KWT';
      case 'REPORT_NO': return 'RPT';
      default: return 'GEN';
    }
  }
}
