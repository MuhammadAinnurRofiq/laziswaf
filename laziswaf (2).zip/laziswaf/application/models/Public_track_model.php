<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Public_track_model extends CI_Model
{
  private function auto_expire_if_needed($submission_no)
  {
    $minutes = defined('SUBMISSION_EXPIRE_MINUTES') ? (int)SUBMISSION_EXPIRE_MINUTES : 10;
    if ($minutes <= 0) $minutes = 10;
    $cutoff = date('Y-m-d H:i:s', time() - ($minutes * 60));

    $this->db->where('submission_no', trim((string)$submission_no));
    $this->db->where('status', 'SUBMITTED');
    $this->db->where('submitted_at <=', $cutoff);
    $this->db->update('trx_submissions', array(
      'status'     => 'EXPIRED',
      'expired_at' => date('Y-m-d H:i:s'),
    ));
  }

  private function auto_expire_whatsapp($whatsapp)
  {
    $minutes = defined('SUBMISSION_EXPIRE_MINUTES') ? (int)SUBMISSION_EXPIRE_MINUTES : 10;
    if ($minutes <= 0) $minutes = 10;
    $cutoff = date('Y-m-d H:i:s', time() - ($minutes * 60));

    $this->db->where('whatsapp', trim((string)$whatsapp));
    $this->db->where('status', 'SUBMITTED');
    $this->db->where('submitted_at <=', $cutoff);
    $this->db->update('trx_submissions', array(
      'status'     => 'EXPIRED',
      'expired_at' => date('Y-m-d H:i:s'),
    ));
  }

  public function find_submission($submission_no, $whatsapp)
  {
    $this->auto_expire_if_needed($submission_no);
    $submission_no = trim($submission_no);
    $whatsapp = trim($whatsapp);

    $this->db->select("
      s.*,
      b.branch_name,
      r.receipt_no,
      r.public_token,
      r.is_void AS receipt_is_void,
      r.void_reason,
      r.voided_at
    ");
    $this->db->from('trx_submissions s');
    $this->db->join('mst_branches b', 'b.id = s.branch_id', 'left');
    $this->db->join('trx_receipts r', 'r.submission_id = s.id', 'left');
    $this->db->where('s.submission_no', $submission_no);
    $this->db->where('s.whatsapp', $whatsapp);
    $this->db->limit(1);

    $sub = $this->db->get()->row();
    if (!$sub) return null;

    // ambil catatan terbaru dari approval log (untuk NEED_FIX/REJECT)
    $log = $this->db->select('action, note, created_at')
      ->from('trx_approval_logs')
      ->where('submission_id', (int)$sub->id)
      ->order_by('created_at', 'DESC')
      ->limit(1)
      ->get()->row();

    $sub->last_action = $log ? $log->action : null;
    $sub->last_note   = $log ? $log->note : null;
    $sub->last_log_at = $log ? $log->created_at : null;

    return $sub;
  }

  public function find_by_submission_no($submission_no)
{
  $this->auto_expire_if_needed($submission_no);
  $submission_no = trim((string)$submission_no);

  $this->db->select("
    s.*,
    b.branch_name,
    r.receipt_no,
    r.public_token,
    r.is_void AS receipt_is_void,
    r.void_reason,
    r.voided_at
  ");
  $this->db->from('trx_submissions s');
  $this->db->join('mst_branches b', 'b.id = s.branch_id', 'left');
  $this->db->join('trx_receipts r', 'r.submission_id = s.id', 'left');
  $this->db->where('s.submission_no', $submission_no);
  $this->db->limit(1);

  $sub = $this->db->get()->row();
  if (!$sub) return null;

  $log = $this->db->select('action, note, created_at')
    ->from('trx_approval_logs')
    ->where('submission_id', (int)$sub->id)
    ->order_by('created_at', 'DESC')
    ->limit(1)
    ->get()->row();

  $sub->last_action = $log ? $log->action : null;
  $sub->last_note   = $log ? $log->note : null;
  $sub->last_log_at = $log ? $log->created_at : null;

  return $sub;
}

public function list_by_whatsapp($whatsapp, $limit = 20)
{
  $this->auto_expire_whatsapp($whatsapp);
  $whatsapp = trim((string)$whatsapp);
  if ($whatsapp === '') return array();

  $this->db->select("s.submission_no, s.applicant_name, s.zis_type_code, s.submitted_at, s.status, b.branch_name");
  $this->db->from('trx_submissions s');
  $this->db->join('mst_branches b', 'b.id = s.branch_id', 'left');
  $this->db->where('s.whatsapp', $whatsapp);
  $this->db->order_by('s.submitted_at', 'DESC');
  $this->db->limit((int)$limit);

  return $this->db->get()->result();
}

}
