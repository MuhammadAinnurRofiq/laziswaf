<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Branch_submission_model extends CI_Model
{

  /**
   * Auto-expire pengajuan PUBLIC yang masih SUBMITTED dan sudah melewati batas waktu.
   * Tidak perlu cron: dipanggil saat inbox/track/halaman manajemen expired dibuka.
   */
  public function auto_expire_branch($branch_id, $minutes = null)
  {
    $minutes = $minutes !== null ? (int)$minutes : (defined('SUBMISSION_EXPIRE_MINUTES') ? (int)SUBMISSION_EXPIRE_MINUTES : 10);
    if ($minutes <= 0) $minutes = 10;

    $now = date('Y-m-d H:i:s');
    $cutoff = date('Y-m-d H:i:s', time() - ($minutes * 60));

    // Tandai expired hanya untuk yang masih SUBMITTED
    $this->db->set('status', 'EXPIRED');
    $this->db->set('expired_at', $now);
    $this->db->where('branch_id', (int)$branch_id);
    $this->db->where('status', 'SUBMITTED');
    $this->db->where('submitted_at <=', $cutoff);
    $this->db->update('trx_submissions');
  }

  public function is_expired_row($submitted_at, $minutes = null)
  {
    $minutes = $minutes !== null ? (int)$minutes : (defined('SUBMISSION_EXPIRE_MINUTES') ? (int)SUBMISSION_EXPIRE_MINUTES : 10);
    if (!$submitted_at) return false;
    $t = strtotime($submitted_at);
    if ($t === false) return false;
    return $t <= (time() - ($minutes * 60));
  }

  /**
   * List pengajuan untuk halaman "Expired & Hapus" (CABANG).
   * Menampilkan:
   * - SUBMITTED yang sudah > batas menit (kandidat expired)
   * - EXPIRED (siap dihapus)
   */
  public function list_expired_manage($branch_id, $limit = 200)
  {
    $this->auto_expire_branch($branch_id);

    $this->db->select('id, submission_no, zis_type_code, applicant_name, whatsapp, status, submitted_at, expired_at, deleted_at');
    $this->db->from('trx_submissions');
    $this->db->where('branch_id', (int)$branch_id);
    $this->db->where_in('status', array('SUBMITTED','EXPIRED'));
    $this->db->order_by('submitted_at','DESC');
    $this->db->limit((int)$limit);

    $rows = $this->db->get()->result();

    // Filter SUBMITTED agar hanya yang memang sudah melewati batas waktu
    $out = array();
    foreach ($rows as $r) {
      if ($r->status === 'SUBMITTED') {
        if ($this->is_expired_row($r->submitted_at)) $out[] = $r;
      } else {
        $out[] = $r;
      }
    }
    return $out;
  }

  public function mark_expired($id, $branch_id, $actor_user_id)
  {
    $sub = $this->db->get_where('trx_submissions', array('id'=>(int)$id, 'branch_id'=>(int)$branch_id), 1)->row();
    if (!$sub) return array('ok'=>false,'msg'=>'Data tidak ditemukan / bukan cabang Anda.');

    if ($sub->status !== 'SUBMITTED') return array('ok'=>false,'msg'=>'Hanya status SUBMITTED yang dapat ditandai EXPIRED.');

    if (!$this->is_expired_row($sub->submitted_at)) {
      return array('ok'=>false,'msg'=>'Belum melewati batas waktu. Minimal '.(defined('SUBMISSION_EXPIRE_MINUTES')?SUBMISSION_EXPIRE_MINUTES:10).' menit dari jam submit.');
    }

    $this->db->where('id', (int)$id);
    $this->db->update('trx_submissions', array(
      'status'     => 'EXPIRED',
      'expired_at' => date('Y-m-d H:i:s'),
      'expired_by' => (int)$actor_user_id,
      'updated_by' => (int)$actor_user_id,
    ));

    return array('ok'=>true,'msg'=>'Pengajuan berhasil ditandai EXPIRED.');
  }

  public function soft_delete_submission($id, $branch_id, $actor_user_id)
  {
    $sub = $this->db->get_where('trx_submissions', array('id'=>(int)$id, 'branch_id'=>(int)$branch_id), 1)->row();
    if (!$sub) return array('ok'=>false,'msg'=>'Data tidak ditemukan / bukan cabang Anda.');

    if (!in_array($sub->status, array('SUBMITTED','EXPIRED'), true)) {
      return array('ok'=>false,'msg'=>'Hanya status SUBMITTED/EXPIRED yang dapat dihapus.');
    }
    // Untuk SUBMITTED, wajib sudah lewat batas waktu
    if ($sub->status === 'SUBMITTED' && !$this->is_expired_row($sub->submitted_at)) {
      return array('ok'=>false,'msg'=>'Belum melewati batas waktu. Minimal '.(defined('SUBMISSION_EXPIRE_MINUTES')?SUBMISSION_EXPIRE_MINUTES:10).' menit dari jam submit.');
    }

    // Hapus data turunan (aman karena belum jadi pembayaran/kuitansi)
    $this->db->delete('trx_submission_people', array('submission_id'=>(int)$id));
    $this->db->delete('trx_attachments', array('submission_id'=>(int)$id));
    // approval log boleh dibiarkan untuk audit, tapi karena user minta "hapus data", kita bersihkan juga:
    $this->db->delete('trx_approval_logs', array('submission_id'=>(int)$id));

    $this->db->where('id', (int)$id);
    $this->db->update('trx_submissions', array(
      'status'     => 'DELETED',
      'deleted_at' => date('Y-m-d H:i:s'),
      'deleted_by' => (int)$actor_user_id,
      'updated_by' => (int)$actor_user_id,
    ));

    return array('ok'=>true,'msg'=>'Data pengajuan berhasil dihapus (status DELETED).');
  }

  public function inbox($branch_id)
  {
    // auto-expire agar pengajuan lama tidak muncul di inbox
    $this->auto_expire_branch($branch_id);
    $this->db->from('trx_submissions');
    $this->db->where('branch_id', (int)$branch_id);
    $this->db->where_in('status', array('SUBMITTED','NEED_FIX'));
    $this->db->order_by('submitted_at','DESC');
    return $this->db->get()->result();
  }

  public function history($branch_id)
  {
    $this->db->from('trx_submissions');
    $this->db->where('branch_id', (int)$branch_id);
    $this->db->where_in('status', array('BRANCH_APPROVED','BRANCH_REJECTED'));
    $this->db->order_by('submitted_at','DESC');
    return $this->db->get()->result();
  }


  public function dashboard_summary($branch_id, $year = null, $month = null)
{
  $branch_id = (int)$branch_id;
  $statuses = array('BRANCH_APPROVED','CENTER_LOCKED');

  // period filter (default: bulan ini jika year & month dikirim dari controller)
  $start = null; $end = null;
  if (!empty($year) && !empty($month)) {
    $y = (int)$year; $m = (int)$month;
    $start = sprintf('%04d-%02d-01 00:00:00', $y, $m);
    $end   = date('Y-m-d H:i:s', strtotime($start.' +1 month'));
  }

  // === 1) Totals by type (FITRAH / MAL / FIDYAH / INFAQ) + jiwa ===
  $this->db->select("
    zis_type_code,
    COUNT(*) AS trx_count,
    SUM(COALESCE(jiwa_count,0)) AS jiwa_sum,
    SUM(
      CASE WHEN zis_type_code='FITRAH'
        THEN COALESCE(fitrah_total_money,0)
        ELSE COALESCE(amount_money,0)
      END
    ) AS money_sum,
    SUM(
      CASE WHEN zis_type_code='FITRAH'
        THEN COALESCE(fitrah_total_kg,0)
        ELSE 0
      END
    ) AS rice_sum
  ", false);
  $this->db->from('trx_submissions');
  $this->db->where('branch_id', $branch_id);
  $this->db->where_in('status', $statuses);
  if ($start && $end) $this->db->where('submitted_at >=', $start)->where('submitted_at <', $end);
  $this->db->group_by('zis_type_code');
  $rows = $this->db->get()->result_array();

  // normalisasi output (pastikan 4 kategori selalu ada)
  $init = array(
    'FITRAH' => array('trx_count'=>0,'jiwa_sum'=>0,'money_sum'=>0,'rice_sum'=>0),
    'MAL'    => array('trx_count'=>0,'jiwa_sum'=>0,'money_sum'=>0,'rice_sum'=>0),
    'FIDYAH' => array('trx_count'=>0,'jiwa_sum'=>0,'money_sum'=>0,'rice_sum'=>0),
    'INFAQ'  => array('trx_count'=>0,'jiwa_sum'=>0,'money_sum'=>0,'rice_sum'=>0),
  );
  foreach ($rows as $r) {
    $k = strtoupper((string)$r['zis_type_code']);
    if (!isset($init[$k])) $init[$k] = array('trx_count'=>0,'jiwa_sum'=>0,'money_sum'=>0,'rice_sum'=>0);
    $init[$k]['trx_count'] = (int)$r['trx_count'];
    $init[$k]['jiwa_sum']  = (int)$r['jiwa_sum'];
    $init[$k]['money_sum'] = (float)$r['money_sum'];
    $init[$k]['rice_sum']  = (float)$r['rice_sum'];
  }

  $total_money = 0; $total_rice = 0; $total_jiwa = 0;
  foreach ($init as $k => $v) {
    $total_money += (float)$v['money_sum'];
    $total_rice  += (float)$v['rice_sum'];
    $total_jiwa  += (int)$v['jiwa_sum'];
  }

  // === 2) Split totals (pakai trx_allocations biar konsisten dengan sistem) ===
  $this->db->select("
    SUM(COALESCE(a.branch_share_money,0)) AS branch_share_money,
    SUM(COALESCE(a.branch_amil_money,0))  AS branch_amil_money,
    SUM(COALESCE(a.branch_dist_money,0))  AS branch_dist_money,
    SUM(COALESCE(a.center_share_money,0)) AS center_share_money,

    SUM(COALESCE(a.branch_share_rice_kg,0)) AS branch_share_rice_kg,
    SUM(COALESCE(a.branch_amil_rice_kg,0))  AS branch_amil_rice_kg,
    SUM(COALESCE(a.branch_dist_rice_kg,0))  AS branch_dist_rice_kg,
    SUM(COALESCE(a.center_share_rice_kg,0)) AS center_share_rice_kg
  ", false);
  $this->db->from('trx_allocations a');
  $this->db->join('trx_submissions s', 's.id = a.submission_id', 'inner');
  $this->db->where('s.branch_id', $branch_id);
  $this->db->where_in('s.status', $statuses);
  if ($start && $end) $this->db->where('s.submitted_at >=', $start)->where('s.submitted_at <', $end);
  $split = $this->db->get()->row_array();

  // fallback numeric
  foreach (array(
    'branch_share_money','branch_amil_money','branch_dist_money','center_share_money',
    'branch_share_rice_kg','branch_amil_rice_kg','branch_dist_rice_kg','center_share_rice_kg'
  ) as $kk) {
    if (!isset($split[$kk]) || $split[$kk] === null) $split[$kk] = 0;
    $split[$kk] = (float)$split[$kk];
  }

  return array(
    'period' => array('start'=>$start,'end'=>$end,'year'=>$year,'month'=>$month),
    'totals' => array(
      'money' => (float)$total_money,
      'rice_kg' => (float)$total_rice,
      'jiwa' => (int)$total_jiwa,
    ),
    'by_type' => $init,
    'split' => $split,
  );
}


  public function get_detail($id, $branch_id)
  {
    $sub = $this->db->get_where('trx_submissions', array('id'=>(int)$id, 'branch_id'=>(int)$branch_id), 1)->row();
    if (!$sub) return null;

    $people = $this->db->order_by('seq_no','ASC')->get_where('trx_submission_people', array('submission_id'=>(int)$id))->result();
    $receipt = $this->db->get_where('trx_receipts', array('submission_id'=>(int)$id), 1)->row();

    return array('sub'=>$sub, 'people'=>$people, 'receipt'=>$receipt);
  }

  public function approve_generate_all($submission_id, $branch_id, $actor_user_id, $receipt_no)
  {
    $this->db->trans_begin();

$sub = $this->db->get_where('trx_submissions', array('id'=>(int)$submission_id, 'branch_id'=>(int)$branch_id), 1)->row();
    if (!$sub) {
      $this->db->trans_rollback();
      return array('ok'=>false,'msg'=>'Data tidak ditemukan / bukan cabang Anda.');
    }

    // blokir jika sudah DELETED
    if ($sub->status === 'DELETED') {
      $this->db->trans_rollback();
      return array('ok'=>false,'msg'=>'Pengajuan sudah dihapus (DELETED).');
    }

    // jika SUBMITTED sudah lewat batas waktu -> tandai EXPIRED dan blokir approve
    if ($sub->status === 'SUBMITTED' && $this->is_expired_row($sub->submitted_at)) {
      $this->db->where('id', (int)$sub->id);
      $this->db->update('trx_submissions', array(
        'status'     => 'EXPIRED',
        'expired_at' => date('Y-m-d H:i:s'),
        'expired_by' => (int)$actor_user_id,
        'updated_by' => (int)$actor_user_id,
      ));
      $this->db->trans_rollback();
      return array('ok'=>false,'msg'=>'Pengajuan sudah EXPIRED (melewati batas waktu). Silakan minta pengaju submit ulang.');
    }

    if ($sub->status === 'EXPIRED') {
      $this->db->trans_rollback();
      return array('ok'=>false,'msg'=>'Pengajuan sudah EXPIRED. Silakan minta pengaju submit ulang.');
    }

    if ($sub->status === 'BRANCH_APPROVED') {
      $this->db->trans_rollback();
      return array('ok'=>false,'msg'=>'Pengajuan sudah di-approve.');
    }

    // tentukan basis pembayaran dari submission
    $total_money = 0.0;
    $total_rice  = 0.0;

    if ($sub->zis_type_code === 'FITRAH') {
      // pay_method_id sudah ada dari publik
      if (!empty($sub->fitrah_total_kg)) $total_rice = (float)$sub->fitrah_total_kg;
      if (!empty($sub->fitrah_total_money)) $total_money = (float)$sub->fitrah_total_money;
    } else {
      $total_money = (float)$sub->amount_money;
    }

    // 1) create payment
    $payment_id = null;
    $method_id = !empty($sub->pay_method_id) ? (int)$sub->pay_method_id : null;

    if (!$method_id) {
      // default ke CASH jika tidak ada
      $m = $this->db->get_where('mst_payment_methods', array('code'=>'CASH'), 1)->row();
      $method_id = $m ? (int)$m->id : 1;
    }

    $this->db->insert('trx_payments', array(
      'submission_id' => (int)$submission_id,
      'received_at' => date('Y-m-d H:i:s'),
      'received_by_user_id' => (int)$actor_user_id,
      'method_id' => (int)$method_id,
      'amount_money' => $total_money > 0 ? $total_money : null,
      'amount_rice_kg' => $total_rice > 0 ? $total_rice : null,
      'bank_account_id' => null,
      'transfer_ref' => null,
      'note' => 'Auto from approve'
    ));
    $payment_id = (int)$this->db->insert_id();

    // 2) allocations 50/50 + amil 12.5% dari porsi cabang
    $alloc = $this->compute_alloc($total_money, $total_rice);

    $this->db->insert('trx_allocations', array(
      'submission_id' => (int)$submission_id,
      'basis' => ($total_rice > 0 ? 'RICE' : 'MONEY'),
      'total_money' => $total_money > 0 ? $total_money : null,
      'total_rice_kg' => $total_rice > 0 ? $total_rice : null,

      'branch_share_money' => $alloc['branch_share_money'],
      'branch_amil_money'  => $alloc['branch_amil_money'],
      'branch_dist_money'  => $alloc['branch_dist_money'],
      'center_share_money' => $alloc['center_share_money'],

      'branch_share_rice_kg' => $alloc['branch_share_rice_kg'],
      'branch_amil_rice_kg'  => $alloc['branch_amil_rice_kg'],
      'branch_dist_rice_kg'  => $alloc['branch_dist_rice_kg'],
      'center_share_rice_kg' => $alloc['center_share_rice_kg'],

      'created_at' => date('Y-m-d H:i:s')
    ));

    // 3) receipt
    $public_token = bin2hex(random_bytes(16));
    $this->db->insert('trx_receipts', array(
      'submission_id' => (int)$submission_id,
      'receipt_no' => $receipt_no,
      'public_token' => $public_token,
      'issued_at' => date('Y-m-d H:i:s'),
      'issued_by_user_id' => (int)$actor_user_id,
      'template_version' => 'v1',
      'template_snapshot_json' => null,
      'privacy_flags_json' => null,
      'pdf_path' => null
    ));

    // 4) approval log + update status
    $this->db->insert('trx_approval_logs', array(
      'submission_id' => (int)$submission_id,
      'actor_user_id' => (int)$actor_user_id,
      'action' => 'APPROVE',
      'from_status' => $sub->status,
      'to_status' => 'BRANCH_APPROVED',
      'note' => 'Approved + auto payment/allocation/receipt',
      'created_at' => date('Y-m-d H:i:s')
    ));

    $this->db->where('id', (int)$submission_id)->update('trx_submissions', array(
      'status' => 'BRANCH_APPROVED',
      'updated_by' => (int)$actor_user_id
    ));

    if ($this->db->trans_status() === FALSE) {
      $this->db->trans_rollback();
      return array('ok'=>false,'msg'=>'Gagal approve (DB).');
    }

    $this->db->trans_commit();
    return array('ok'=>true,'token'=>$public_token);
  }

  public function reject($submission_id, $branch_id, $actor_user_id, $note)
  {
    return $this->simple_status_change($submission_id, $branch_id, $actor_user_id, 'REJECT', 'BRANCH_REJECTED', $note);
  }

  public function needfix($submission_id, $branch_id, $actor_user_id, $note)
  {
    return $this->simple_status_change($submission_id, $branch_id, $actor_user_id, 'NEED_FIX', 'NEED_FIX', $note);
  }

  private function simple_status_change($submission_id, $branch_id, $actor_user_id, $action, $to_status, $note)
  {
    $this->db->trans_begin();

$sub = $this->db->get_where('trx_submissions', array('id'=>(int)$submission_id, 'branch_id'=>(int)$branch_id), 1)->row();
    if (!$sub) {
      $this->db->trans_rollback();
      return array('ok'=>false,'msg'=>'Data tidak ditemukan / bukan cabang Anda.');
    }

    // blokir jika sudah DELETED
    if ($sub->status === 'DELETED') {
      $this->db->trans_rollback();
      return array('ok'=>false,'msg'=>'Pengajuan sudah dihapus (DELETED).');
    }

    // jika SUBMITTED sudah lewat batas waktu -> tandai EXPIRED dan blokir approve
    if ($sub->status === 'SUBMITTED' && $this->is_expired_row($sub->submitted_at)) {
      $this->db->where('id', (int)$sub->id);
      $this->db->update('trx_submissions', array(
        'status'     => 'EXPIRED',
        'expired_at' => date('Y-m-d H:i:s'),
        'expired_by' => (int)$actor_user_id,
        'updated_by' => (int)$actor_user_id,
      ));
      $this->db->trans_rollback();
      return array('ok'=>false,'msg'=>'Pengajuan sudah EXPIRED (melewati batas waktu). Silakan minta pengaju submit ulang.');
    }

    if ($sub->status === 'EXPIRED') {
      $this->db->trans_rollback();
      return array('ok'=>false,'msg'=>'Pengajuan sudah EXPIRED. Silakan minta pengaju submit ulang.');
    }

    $this->db->insert('trx_approval_logs', array(
      'submission_id' => (int)$submission_id,
      'actor_user_id' => (int)$actor_user_id,
      'action' => $action,
      'from_status' => $sub->status,
      'to_status' => $to_status,
      'note' => (string)$note,
      'created_at' => date('Y-m-d H:i:s')
    ));

    $this->db->where('id', (int)$submission_id)->update('trx_submissions', array(
      'status' => $to_status,
      'updated_by' => (int)$actor_user_id
    ));

    if ($this->db->trans_status() === FALSE) {
      $this->db->trans_rollback();
      return array('ok'=>false,'msg'=>'Gagal update status.');
    }

    $this->db->trans_commit();
    return array('ok'=>true);
  }

  private function compute_alloc($total_money, $total_rice)
  {
    $half_money = $total_money > 0 ? $total_money * 0.5 : 0.0;
    $half_rice  = $total_rice  > 0 ? $total_rice  * 0.5 : 0.0;

    $amil_money = $half_money * 0.125;
    $dist_money = $half_money - $amil_money;
    $center_money = $total_money - $half_money;

    $amil_rice = $half_rice * 0.125;
    $dist_rice = $half_rice - $amil_rice;
    $center_rice = $total_rice - $half_rice;

    return array(
      'branch_share_money' => $total_money > 0 ? $half_money : null,
      'branch_amil_money'  => $total_money > 0 ? $amil_money : null,
      'branch_dist_money'  => $total_money > 0 ? $dist_money : null,
      'center_share_money' => $total_money > 0 ? $center_money : null,

      'branch_share_rice_kg' => $total_rice > 0 ? $half_rice : null,
      'branch_amil_rice_kg'  => $total_rice > 0 ? $amil_rice : null,
      'branch_dist_rice_kg'  => $total_rice > 0 ? $dist_rice : null,
      'center_share_rice_kg' => $total_rice > 0 ? $center_rice : null,
    );
  }
}
