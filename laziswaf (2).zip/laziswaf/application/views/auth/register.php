<div class="p-4 p-md-5">
  <div class="d-flex align-items-center gap-2 mb-2">
    <span class="brand-dot"></span>
    <h4 class="mb-0">Register Akun Cabang</h4>
  </div>
  <p class="text-muted mb-4">Buat akun untuk akses Cabang (role: CABANG).</p>

  <?php if (!empty($error)): ?>
    <div class="alert alert-danger"><?php echo html_escape($error); ?></div>
  <?php endif; ?>

  <?php echo form_open(site_url('register')); ?>
    <div class="mb-3">
      <label class="form-label">Nama Lengkap</label>
      <input type="text" name="full_name" class="form-control" value="<?php echo set_value('full_name'); ?>" required>
      <small class="text-danger"><?php echo form_error('full_name'); ?></small>
    </div>

    <div class="row g-2">
      <div class="col-md-6 mb-3">
        <label class="form-label">Username</label>
        <input type="text" name="username" class="form-control" value="<?php echo set_value('username'); ?>" required>
        <small class="text-danger"><?php echo form_error('username'); ?></small>
      </div>
      <div class="col-md-6 mb-3">
        <label class="form-label">Cabang</label>
        <select name="branch_id" class="form-select" required>
          <option value="">-- pilih cabang --</option>
          <?php foreach ($branches as $b): ?>
            <?php if ($b->branch_code === 'PUSAT') continue; ?>
            <option value="<?php echo (int)$b->id; ?>" <?php echo set_select('branch_id', $b->id); ?>>
              <?php echo html_escape($b->branch_name); ?>
            </option>
          <?php endforeach; ?>
        </select>
        <small class="text-danger"><?php echo form_error('branch_id'); ?></small>
      </div>
    </div>

    <div class="row g-2">
      <div class="col-md-6 mb-3">
        <label class="form-label">Password</label>
        <input type="password" name="password" class="form-control" required>
        <small class="text-danger"><?php echo form_error('password'); ?></small>
      </div>
      <div class="col-md-6 mb-3">
        <label class="form-label">Konfirmasi Password</label>
        <input type="password" name="password2" class="form-control" required>
        <small class="text-danger"><?php echo form_error('password2'); ?></small>
      </div>
    </div>

    <div class="row g-2">
      <div class="col-md-6 mb-3">
        <label class="form-label">No. HP (opsional)</label>
        <input type="text" name="phone" class="form-control" value="<?php echo set_value('phone'); ?>">
      </div>
      <div class="col-md-6 mb-3">
        <label class="form-label">Email (opsional)</label>
        <input type="email" name="email" class="form-control" value="<?php echo set_value('email'); ?>">
      </div>
    </div>

    <button class="btn btn-primary w-100 btn-lg">
      <i class="bi bi-person-plus me-2"></i>Daftar
    </button>

    <div class="text-center mt-3">
      <a class="text-decoration-none" href="<?php echo site_url('login'); ?>">Sudah punya akun? Login</a>
    </div>
  <?php echo form_close(); ?>
</div>
