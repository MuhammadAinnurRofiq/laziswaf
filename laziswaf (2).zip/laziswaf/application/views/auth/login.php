<div class="p-4 p-md-5">
  <div class="d-flex align-items-center gap-2 mb-2">
    <span class="brand-dot"></span>
    <h4 class="mb-0">Login</h4>
  </div>
  <p class="text-muted mb-4">Masuk untuk mengakses dashboard sesuai role Anda.</p>

  <?php if (!empty($error)): ?>
    <div class="alert alert-danger"><?php echo html_escape($error); ?></div>
  <?php endif; ?>

  <?php if ($this->session->flashdata('ok')): ?>
    <div class="alert alert-success"><?php echo html_escape($this->session->flashdata('ok')); ?></div>
  <?php endif; ?>

  <?php echo form_open(site_url('login')); ?>
    <div class="mb-3">
      <label class="form-label">Username</label>
      <input type="text" name="username" class="form-control" value="<?php echo set_value('username'); ?>" required>
      <small class="text-danger"><?php echo form_error('username'); ?></small>
    </div>

    <div class="mb-3">
      <label class="form-label">Password</label>
      <input type="password" name="password" class="form-control" required>
      <small class="text-danger"><?php echo form_error('password'); ?></small>
    </div>

    <button class="btn btn-primary w-100 btn-lg">
      <i class="bi bi-box-arrow-in-right me-2"></i>Masuk
    </button>

    <div class="d-flex justify-content-between mt-3">

      <a class="text-decoration-none opacity-75" href="#">Lupa password hubungi admin</a>
    </div>
  <?php echo form_close(); ?>
</div>
