<?php
defined('BASEPATH') OR exit('No direct script access allowed');

/**
 * View: application/views/center/dashboard/index.php
 * Dashboard Pusat (ADMIN/BENDAHARA)
 */

function rupiah($n){ return 'Rp '.number_format((float)$n,0,',','.'); }
function kg($n){ return (float)$n.' kg'; }

$metrics = $metrics ?? null;
?>

<div class="container-fluid">

  <?php
    $label_period = 'Bulan ini';
    if (($range ?? 'month') === 'all') $label_period = 'Semua waktu';
    else $label_period = sprintf('%02d-%04d', (int)($month ?? date('n')), (int)($year ?? date('Y')));
  ?>

  <div class="page-hero mb-3">
    <div>
      <h3 class="mb-1">Dashboard Pusat</h3>
      <div class="opacity-75">
        Ringkasan pemasukan pusat (<?php echo html_escape($label_period); ?>)
        <?php if (!empty($metrics) && !empty($metrics['period']) && (($range ?? 'month') !== 'all')): ?>
          <span class="d-none d-md-inline">
            (<?php echo html_escape($metrics['period']->start_date); ?> s/d <?php echo html_escape($metrics['period']->end_date); ?>)
          </span>
        <?php endif; ?>.
      </div>
    </div>
  </div>

  <!-- Filter -->
  <div class="card shadow-soft mb-3">
    <div class="card-body">
      <form class="row g-2" method="get">
        <div class="col-auto">
          <select class="form-select" name="range">
            <option value="month" <?php echo (($range ?? 'month')==='month'?'selected':''); ?>>Per Bulan</option>
            <option value="all" <?php echo (($range ?? '')==='all'?'selected':''); ?>>Semua Waktu</option>
          </select>
        </div>
        <div class="col-auto">
          <input class="form-control" type="number" name="month" min="1" max="12" value="<?php echo (int)($month ?? date('n')); ?>" <?php echo (($range ?? 'month')==='all'?'disabled':''); ?>>
        </div>
        <div class="col-auto">
          <input class="form-control" type="number" name="year" min="2020" max="2099" value="<?php echo (int)($year ?? date('Y')); ?>" <?php echo (($range ?? 'month')==='all'?'disabled':''); ?>>
        </div>
        <div class="col-auto">
          <button class="btn btn-primary"><i class="bi bi-funnel me-2"></i>Terapkan</button>
        </div>
      </form>
    </div>
  </div>

<?php if ($metrics): ?>
    <?php
      $recap = $metrics['recap'] ?? array();
      $label_kartu = (($range ?? 'month')==='all') ? 'Semua Waktu' : ('Per Bulan '.$label_period);
      $r0 = function($t, $k, $d=0) use ($recap) {
        return isset($recap[$t]) && array_key_exists($k, $recap[$t]) ? $recap[$t][$k] : $d;
      };
      $fmt_kg2 = function($n){ return number_format((float)$n,2,',','.').' kg'; };
    ?>

    <!-- Rekap per Jenis -->
    <div class="text-muted small mb-2">Rekap kartu: <b><?php echo html_escape($label_kartu); ?></b></div>
    <div class="row g-3 mb-3">
      <?php
        $cards = array(
          array('key'=>'FITRAH', 'label'=>'Zakat Fitrah'),
          array('key'=>'MAL',    'label'=>'Zakat Mal'),
          array('key'=>'FIDYAH', 'label'=>'Fidyah'),
          array('key'=>'INFAQ',  'label'=>'Infak'),
        );
      ?>
      <?php foreach($cards as $c): ?>
        <?php $k = $c['key']; ?>
        <div class="col-12 col-md-6 col-xl-3">
          <div class="card shadow-soft h-100">
            <div class="card-body">
              <div class="fw-semibold"><?php echo html_escape($c['label']); ?></div>
              <div class="text-muted small mb-2">
                <?php echo number_format((int)$r0($k,'trx',0),0,',','.'); ?> transaksi &bull;
                <?php echo number_format((float)$r0($k,'jiwa',0),0,',','.'); ?> jiwa
              </div>

              <div class="d-flex justify-content-between">
                <span class="text-muted">Uang</span>
                <span class="fw-semibold"><?php echo rupiah((float)$r0($k,'money',0)); ?></span>
              </div>
              <div class="d-flex justify-content-between">
                <span class="text-muted">Beras</span>
                <span class="fw-semibold"><?php echo $fmt_kg2((float)$r0($k,'rice',0)); ?></span>
              </div>
            </div>
          </div>
        </div>
      <?php endforeach; ?>
    </div>

    <div class="row g-3">
      <!-- Total pemasukan -->
      <div class="col-md-4">
        <div class="card shadow-soft h-100">
          <div class="card-body">
            <div class="text-muted">Total Pemasukan (Uang)</div>
            <div class="fs-4 fw-semibold"><?php echo rupiah($metrics['total_money']); ?></div>
            <div class="text-muted mt-2">Total Pemasukan (Beras)</div>
            <div class="fs-4 fw-semibold"><?php echo kg($metrics['total_rice']); ?></div>
          </div>
        </div>
      </div>

      <!-- Split 50/50 -->
      <div class="col-md-4">
        <div class="card shadow-soft h-100">
          <div class="card-body">
            <div class="fw-semibold mb-2">Pembagian 50% / 50%</div>

            <div class="d-flex justify-content-between">
              <span class="text-muted">Porsi Cabang (50%)</span>
              <span class="fw-semibold"><?php echo rupiah($metrics['branch_share_money']); ?></span>
            </div>
            <div class="small text-muted">Pengelolaan cabang: 12,5% hak amil + 37,5% distribusi.</div>

            <div class="d-flex justify-content-between mt-2">
              <span class="text-muted">- Hak Amil Cabang</span>
              <span><?php echo rupiah($metrics['branch_amil_money']); ?></span>
            </div>
            <div class="d-flex justify-content-between">
              <span class="text-muted">- Distribusi Cabang</span>
              <span><?php echo rupiah($metrics['branch_dist_money']); ?></span>
            </div>

            <hr class="opacity-25">

            <div class="d-flex justify-content-between">
              <span class="text-muted">Porsi Pusat (50%)</span>
              <span class="fw-semibold"><?php echo rupiah($metrics['center_share_money']); ?></span>
            </div>
            <div class="small text-muted">Porsi pusat: full untuk penyaluran.</div>

            <hr class="opacity-25">

            <div class="d-flex justify-content-between">
              <span class="text-muted">Beras Cabang (50%)</span>
              <span class="fw-semibold"><?php echo kg($metrics['branch_share_rice']); ?></span>
            </div>
            <div class="d-flex justify-content-between">
              <span class="text-muted">Beras Pusat (50%)</span>
              <span class="fw-semibold"><?php echo kg($metrics['center_share_rice']); ?></span>
            </div>
          </div>
        </div>
      </div>

      <!-- Jumlah muzakki -->
      <div class="col-md-4">
        <div class="card shadow-soft h-100">
          <div class="card-body">
            <div class="fw-semibold mb-2">Jumlah Muzakki / Jiwa</div>

            <div class="d-flex justify-content-between">
              <span class="text-muted">Zakat Fitrah</span>
              <span class="fw-semibold"><?php echo number_format((float)$metrics['fitrah_people'],0,',','.'); ?> jiwa</span>
            </div>
            <div class="d-flex justify-content-between">
              <span class="text-muted">Zakat Mal</span>
              <span class="fw-semibold"><?php echo number_format((int)$metrics['mal_people'],0,',','.'); ?> orang</span>
            </div>
            <div class="d-flex justify-content-between">
              <span class="text-muted">Fidyah</span>
              <span class="fw-semibold"><?php echo number_format((float)$metrics['fidyah_people'],0,',','.'); ?> jiwa</span>
            </div>
            <div class="d-flex justify-content-between">
              <span class="text-muted">Infak</span>
              <span class="fw-semibold"><?php echo number_format((int)$metrics['infaq_people'],0,',','.'); ?> orang</span>
            </div>

            <hr class="opacity-25">

            <div class="small text-muted">
              Catatan: Fitrah &amp; Fidyah dihitung dari jumlah jiwa (dependents/people). Mal &amp; Infak dihitung per transaksi.
            </div>
          </div>
        </div>
      </div>

            <?php if ((($range ?? 'month') !== 'all') && !empty($metrics['period'])): ?>
<!-- Status pelaporan cabang -->
      <div class="col-12">
        <div class="card shadow-soft">
          <div class="card-body">
            <div class="fw-semibold mb-2">Status Pelaporan Cabang</div>

            <div class="row g-3">
              <div class="col-md-3">
                <div class="p-3 border rounded-3">
                  <div class="text-muted">Total Cabang</div>
                  <div class="fs-4 fw-semibold"><?php echo number_format((int)$metrics['branches_total'],0,',','.'); ?></div>
                </div>
              </div>
              <div class="col-md-3">
                <div class="p-3 border rounded-3">
                  <div class="text-muted">Sudah Upload &amp; Approved</div>
                  <div class="fs-4 fw-semibold"><?php echo number_format((int)$metrics['branches_approved'],0,',','.'); ?></div>
                </div>
              </div>
              <div class="col-md-3">
                <div class="p-3 border rounded-3">
                  <div class="text-muted">Sudah Kirim (Belum Approve/Revisi)</div>
                  <div class="fs-4 fw-semibold"><?php echo number_format((int)$metrics['branches_pending'],0,',','.'); ?></div>
                </div>
              </div>
              <div class="col-md-3">
                <div class="p-3 border rounded-3">
                  <div class="text-muted">Belum Mengirim</div>
                  <div class="fs-4 fw-semibold"><?php echo number_format((int)$metrics['branches_unreported'],0,',','.'); ?></div>
                </div>
              </div>
            </div>

            <div class="mt-3">
              <a class="btn btn-soft" href="<?php echo site_url('dashboard/reports/branches?period_id='.$metrics['period']->id); ?>">
                <i class="bi bi-list-check me-2"></i>Lihat Status Cabang
              </a>
            </div>
          </div>
        </div>
      </div>
      <?php else: ?>
      <div class="col-12">
        <div class="alert alert-info mb-0">
          Status pelaporan cabang tersedia pada mode <b>Per Bulan</b>. Silakan pilih “Per Bulan”, isi bulan/tahun, lalu klik Terapkan.
        </div>
      </div>
      <?php endif; ?>


    </div>
  <?php else: ?>
    <div class="alert alert-warning">Data periode tidak ditemukan.</div>
  <?php endif; ?>

  <!-- (Opsional) jika masih ada konten dashboard lama, taruh di bawah ini -->
  <!--
  <div class="card shadow-soft mt-3">
    <div class="card-body">
      <div class="opacity-75">
        Ini placeholder dashboard ADMIN/BENDAHARA. Berikutnya kita buat modul monitor pengajuan semua cabang, master data, dan laporan.
      </div>
    </div>
  </div>
  -->

</div>
