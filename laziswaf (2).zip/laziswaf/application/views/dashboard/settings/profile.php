<?php
$logo_url = isset($logo_url) ? (string)$logo_url : '';
$app_name = isset($app_name) ? (string)$app_name : 'LAZISWAF';

$footer_left_text  = isset($footer_left_text) ? (string)$footer_left_text : '';
$footer_build_label = isset($footer_build_label) ? (string)$footer_build_label : 'Built with';
$footer_ci_text     = isset($footer_ci_text) ? (string)$footer_ci_text : 'CI3';
$footer_bs_text     = isset($footer_bs_text) ? (string)$footer_bs_text : 'Bootstrap 5';
$footer_note_text   = isset($footer_note_text) ? (string)$footer_note_text : '';
?>

<div class="container-fluid">
  <div class="row g-3">
    <div class="col-12">
      <div class="page-hero">
        <div>
          <h3 class="mb-1">Setting Profil Aplikasi</h3>
          <div class="opacity-75">Atur nama aplikasi dan logo (tampil di landing + dashboard).</div>
        </div>
      </div>

      <?php if ($this->session->flashdata('success')): ?>
        <div class="alert alert-success"><?php echo $this->session->flashdata('success'); ?></div>
      <?php endif; ?>
      <?php if ($this->session->flashdata('error')): ?>
        <div class="alert alert-danger"><?php echo $this->session->flashdata('error'); ?></div>
      <?php endif; ?>

      <div class="card glass-card">
        <div class="card-body">
          <form method="post" enctype="multipart/form-data" action="<?php echo site_url('dashboard/settings/profile/save'); ?>">
            <div class="row g-3 align-items-start">
              <div class="col-md-8">
                <label class="form-label">Nama Aplikasi</label>
                <input type="text" name="app_name" class="form-control" value="<?php echo html_escape($app_name); ?>" required>
                <div class="form-text">Nama ini akan muncul di landing, sidebar, navbar, footer, dan title halaman.</div>

                <div class="mt-3">
                  <label class="form-label">Logo Aplikasi (PNG/JPG/WEBP, max 2MB)</label>
                  <input type="file" name="app_logo" class="form-control">
                  <div class="form-text">Jika dikosongkan, logo tidak berubah.</div>
                </div>

                
                <hr class="my-4">

                <div class="row g-3">
                  <div class="col-12">
                    <div class="fw-semibold mb-1">Pengaturan Footer</div>
                    <div class="text-muted small">Atur teks kiri (contoh: © 2026 LAZISWAF) dan informasi build di kanan (contoh: Built with CI3 + Bootstrap 5 + keterangan).</div>
                  </div>

                  <div class="col-12">
                    <label class="form-label">Footer Kiri (Copyright)</label>
                    <input type="text" name="footer_left_text" class="form-control" value="<?php echo html_escape($footer_left_text); ?>" placeholder="© 2026 LAZISWAF">
                    <div class="form-text">Kosongkan untuk memakai default otomatis: © {tahun} {nama aplikasi}.</div>
                  </div>

                  <div class="col-md-4">
                    <label class="form-label">Label Build</label>
                    <input type="text" name="footer_build_label" class="form-control" value="<?php echo html_escape($footer_build_label); ?>" placeholder="Built with">
                  </div>
                  <div class="col-md-4">
                    <label class="form-label">Versi CI</label>
                    <input type="text" name="footer_ci_text" class="form-control" value="<?php echo html_escape($footer_ci_text); ?>" placeholder="CI3">
                  </div>
                  <div class="col-md-4">
                    <label class="form-label">Versi Bootstrap</label>
                    <input type="text" name="footer_bs_text" class="form-control" value="<?php echo html_escape($footer_bs_text); ?>" placeholder="Bootstrap 5">
                  </div>

                  <div class="col-12">
                    <label class="form-label">Keterangan Tambahan (opsional)</label>
                    <input type="text" name="footer_note_text" class="form-control" value="<?php echo html_escape($footer_note_text); ?>" placeholder="misal: Backup otomatis • Tracking publik • Laporan cabang">
                  </div>
                </div>
<div class="mt-4 d-flex justify-content-end">
                  <button class="btn btn-primary" type="submit"><i class="bi bi-save2 me-2"></i>Simpan</button>
                </div>
              </div>

              <div class="col-md-4">
                <div class="p-3 rounded-3 border">
                  <div class="fw-semibold mb-2">Preview Logo</div>
                  <?php if ($logo_url): ?>
                    <div class="d-flex justify-content-center">
                      <img src="<?php echo $logo_url; ?>" alt="Logo Aplikasi" class="logo-preview">
                    </div>
                    <div class="text-muted small mt-2">Ukuran preview disesuaikan seperti ikon aplikasi (tetap tersimpan ukuran asli di file).</div>
                  <?php else: ?>
                    <div class="d-flex align-items-center gap-2">
                      <span class="brand-dot"></span>
                      <span class="opacity-75">Belum ada logo</span>
                    </div>
                  <?php endif; ?>
                </div>

                <div class="mt-3 p-3 rounded-3 border">
                  <div class="fw-semibold mb-1">Backup Database</div>
                  <div class="opacity-75 mb-2">Download seluruh database untuk cadangan.</div>
                  <a class="btn btn-soft w-100" href="<?php echo site_url('dashboard/settings/download-db'); ?>">
                    <i class="bi bi-download me-2"></i>Download Database (.sql)
                  </a>
                </div>
              </div>
            </div>
          </form>
        </div>
      </div>

    </div>
  </div>
</div>