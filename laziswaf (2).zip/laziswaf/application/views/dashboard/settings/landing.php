<?php
// $home: array
$home = isset($home) && is_array($home) ? $home : array();

$badge      = $home['badge'] ?? '';
$hero_title = $home['hero_title'] ?? '';
$hero_desc  = $home['hero_desc'] ?? '';
$cta_text   = $home['cta_text'] ?? '';
$cta_url    = $home['cta_url'] ?? '';

$features_lines = '';
if (!empty($home['features']) && is_array($home['features'])) {
  foreach ($home['features'] as $f) {
    $icon  = $f['icon'] ?? 'bi-dot';
    $title = $f['title'] ?? '';
    $desc  = $f['desc'] ?? '';
    $features_lines .= $icon.'|'.$title.'|'.$desc."\n";
  }
}

$videos_lines = '';
if (!empty($home['videos']) && is_array($home['videos'])) {
  foreach ($home['videos'] as $v) {
    $t = $v['title'] ?? 'Video';
    $y = $v['youtube'] ?? '';
    $videos_lines .= $t.'|'.$y."\n";
  }
}
?>

<div class="container-fluid">
  <div class="row g-3">
    <div class="col-12">
      <div class="page-hero">
        <div>
          <h3 class="mb-1">Setting Halaman Utama</h3>
          <div class="opacity-75">Atur konten yang tampil di halaman utama sebelum login.</div>
        </div>
        <a class="btn btn-soft" href="<?php echo site_url('/'); ?>" target="_blank" rel="noopener">
          <i class="bi bi-box-arrow-up-right me-2"></i>Preview Landing
        </a>
      </div>

      <?php if ($this->session->flashdata('success')): ?>
        <div class="alert alert-success"><?php echo $this->session->flashdata('success'); ?></div>
      <?php endif; ?>
      <?php if ($this->session->flashdata('error')): ?>
        <div class="alert alert-danger"><?php echo $this->session->flashdata('error'); ?></div>
      <?php endif; ?>

      <div class="card glass-card">
        <div class="card-body">
          <form method="post" action="<?php echo site_url('dashboard/settings/landing/save'); ?>">
            <div class="row g-3">
              <div class="col-md-6">
                <label class="form-label">Badge (teks kecil di hero)</label>
                <input type="text" name="badge" class="form-control" value="<?php echo html_escape($badge); ?>" placeholder="ZISWAF • Transparan • Terstruktur">
              </div>
              <div class="col-md-6">
                <label class="form-label">Judul Hero</label>
                <input type="text" name="hero_title" class="form-control" value="<?php echo html_escape($hero_title); ?>" placeholder="Kelola ZISWAF Modern & Mudah Dilacak">
              </div>

              <div class="col-12">
                <label class="form-label">Deskripsi / Tagline</label>
                <textarea name="hero_desc" class="form-control" rows="3" placeholder="Pengelolaan ZISWAF yang modern, transparan, dan mudah dilacak."><?php echo html_escape($hero_desc); ?></textarea>
              </div>

              <div class="col-md-6">
                <label class="form-label">Teks Tombol (CTA)</label>
                <input type="text" name="cta_text" class="form-control" value="<?php echo html_escape($cta_text); ?>" placeholder="Masuk Dashboard">
              </div>
              <div class="col-md-6">
                <label class="form-label">URL Tombol (CTA)</label>
                <input type="text" name="cta_url" class="form-control" value="<?php echo html_escape($cta_url); ?>" placeholder="<?php echo site_url('public'); ?>">
              </div>

              <div class="col-12">
                <label class="form-label">Daftar Fitur (per baris: icon|judul|deskripsi)</label>
                <textarea name="features" class="form-control" rows="7" placeholder="bi-search|Tracking Pengajuan|Cek status tanpa login"><?php echo html_escape(trim($features_lines)); ?></textarea>
                <div class="form-text">Contoh icon: bi-search, bi-receipt, bi-file-earmark-text (Bootstrap Icons).</div>
              </div>

              <div class="col-12">
                <label class="form-label">Video Panduan (per baris: judul|youtube_id_atau_url)</label>
                <textarea name="videos" class="form-control" rows="5" placeholder="Panduan Pengajuan|https://youtu.be/xxxxx"><?php echo html_escape(trim($videos_lines)); ?></textarea>
                <div class="form-text">Boleh isi ID YouTube saja (mis: dQw4w9WgXcQ) atau URL lengkap.</div>
              </div>

              <div class="col-12 d-flex justify-content-end gap-2">
                <button class="btn btn-primary" type="submit">
                  <i class="bi bi-save2 me-2"></i>Simpan
                </button>
              </div>
            </div>
          </form>
        </div>
      </div>

    </div>
  </div>
</div>
