<div class="container-fluid">
  <div class="row g-3">
    <div class="col-12">
      <div class="page-hero">
        <div>
          <h3 class="mb-1"><?php echo html_escape($title); ?></h3>
          <div class="opacity-75">
            Anda bisa mengajukan pembayaran Zakat/Infaq/Fidyah tanpa login, cek status, dan akses kuitansi publik.
          </div>
        </div>
        <div class="d-flex gap-2 flex-wrap">
          <a class="btn btn-light" href="<?php echo site_url('public/submission/fitrah'); ?>">
            <i class="bi bi-pencil-square me-2"></i>Ajukan Sekarang
          </a>
          <a class="btn btn-soft" href="<?php echo site_url('public/track'); ?>">
            <i class="bi bi-search me-2"></i>Cek Status
          </a>
        </div>
      </div>
    </div>

    <div class="col-md-4">
      <div class="card shadow-soft card-anim">
        <div class="card-body">
          <div class="d-flex align-items-center justify-content-between">
            <div>
              <div class="text-muted">Ajukan Pembayaran</div>
              <div class="fw-semibold">Zakat / Infaq / Fidyah</div>
            </div>
            <div class="icon-bubble bg-soft"><i class="bi bi-pencil-square"></i></div>
          </div>
          <div class="mt-3 opacity-75 small">
            Pilih jenis pembayaran di menu kiri, lalu isi form pengajuan.
          </div>
        </div>
      </div>
    </div>

    <div class="col-md-4">
      <div class="card shadow-soft card-anim">
        <div class="card-body">
          <div class="d-flex align-items-center justify-content-between">
            <div>
              <div class="text-muted">Tracking Pengajuan</div>
              <div class="fw-semibold">Cek status kapan saja</div>
            </div>
            <div class="icon-bubble bg-soft"><i class="bi bi-search"></i></div>
          </div>
          <div class="mt-3 opacity-75 small">
            Gunakan nomor pengajuan / WA untuk melihat status.
          </div>
        </div>
      </div>
    </div>

    <div class="col-md-4">
      <div class="card shadow-soft card-anim">
        <div class="card-body">
          <div class="d-flex align-items-center justify-content-between">
            <div>
              <div class="text-muted">Kuitansi Publik</div>
              <div class="fw-semibold">Token aman</div>
            </div>
            <div class="icon-bubble bg-soft"><i class="bi bi-receipt"></i></div>
          </div>
          <div class="mt-3 opacity-75 small">
            Kuitansi bisa dibuka via link token setelah pengajuan disetujui.
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
