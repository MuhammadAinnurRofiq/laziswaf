<?php
defined('BASEPATH') OR exit('No direct script access allowed');

/**
 * application/views/landing/index.php
 * - Fallback Opsi B: paksa semua link internal memakai index.php (tanpa rewrite .htaccess)
 * - Animasi Typewriter berulang pada Judul Hero
 * - Card/Box: shadow + animasi floating (loncat halus) + hover lift
 */

// helper lokal: paksa URL selalu mengandung index.php (tanpa bergantung rewrite)
if (!function_exists('force_index_url')) {
  function force_index_url($path = '') {
    $path = trim((string)$path);
    $path = ltrim($path, '/');

    // Jika sudah URL full, jangan diubah
    if (preg_match('~^https?://~i', $path)) return $path;

    // base_url() di CI biasanya sudah berakhir dengan slash
    return base_url('index.php/' . $path);
  }
}

// normalisasi variabel
$app_name  = $app_name ?? 'LAZISWAF';
$logo_url  = $logo_url ?? '';
$tagline   = $tagline ?? '';
$home      = (isset($home) && is_array($home)) ? $home : array();

// CTA URL: jika admin isi kosong → default ke "public" (dashboard umum) pakai index.php
$cta_url_raw = trim((string)($home['cta_url'] ?? ''));
if ($cta_url_raw === '') {
  $cta_url = force_index_url('public');
} else {
  $cta_url = preg_match('~^https?://~i', $cta_url_raw)
    ? $cta_url_raw
    : force_index_url(ltrim($cta_url_raw, '/'));
}

// hero title: dukung multi-kalimat pakai pemisah "||"
$hero_title_raw = trim((string)($home['hero_title'] ?? 'Kelola ZISWAF dengan Tracking, Kuitansi Publik, dan Laporan Cabang.'));
if ($hero_title_raw === '') $hero_title_raw = 'Kelola ZISWAF dengan Tracking, Kuitansi Publik, dan Laporan Cabang.';
?>
<?php $this->load->view('partials/head', array('title'=>$app_name)); ?>
<body class="bg-landing">
  <nav class="navbar navbar-expand-lg landing-nav">
    <div class="container">
      <a class="navbar-brand d-flex align-items-center gap-2" href="<?php echo force_index_url(''); ?>">
        <?php if (!empty($logo_url)): ?>
          <img src="<?php echo $logo_url; ?>" alt="Logo" style="width:28px;height:28px;border-radius:8px;object-fit:cover;">
        <?php else: ?>
          <span class="brand-dot"></span>
        <?php endif; ?>
        <strong><?php echo html_escape($app_name); ?></strong>
      </a>

      <div class="ms-auto d-flex gap-2">
        <!-- Tombol Tema -->
        <button class="btn btn-soft" id="btnTheme" type="button">
          <i class="bi bi-sun me-1"></i> Mode Terang
        </button>

        <!-- Login -->
        <a class="btn btn-soft" href="<?php echo force_index_url('login'); ?>">
          <i class="bi bi-box-arrow-in-right me-1"></i>Login
        </a>

        <!-- Register disembunyikan -->
        <!-- <a class="btn btn-light" href="<?php echo force_index_url('register'); ?>">Register</a> -->
      </div>
    </div>
  </nav>

  <header class="hero">
    <div class="container">
      <div class="row align-items-center g-4">
        <div class="col-lg-7">
          <div class="badge-pill mb-3"><?php echo html_escape($home['badge'] ?? 'ZISWAF • Transparan • Terstruktur'); ?></div>

          <!-- JUDUL HERO: typewriter loop -->
          <h1 class="display-5 fw-bold mb-3 hero-animate">
            <span id="heroTyped"
                  data-texts="<?php echo html_escape($hero_title_raw); ?>"></span>
            <span class="typed-cursor" aria-hidden="true"></span>
          </h1>

          <p class="lead opacity-75 mb-4">
            <?php echo html_escape($home['hero_desc'] ?? $tagline); ?>
          </p>

          <div class="d-flex gap-2 flex-wrap">
            <a href="<?php echo $cta_url; ?>" class="btn btn-light btn-lg">
              <i class="bi bi-speedometer2 me-2"></i><?php echo html_escape($home['cta_text'] ?? 'Masuk Dashboard'); ?>
            </a>
          </div>
        </div>

        <div class="col-lg-5">
          <!-- glass-card sekarang akan floating -->
          <div class="glass-card p-4">
            <div class="d-flex align-items-center gap-3 mb-3">
              <div class="icon-bubble"><i class="bi bi-receipt"></i></div>
              <div>
                <div class="fw-semibold">Kuitansi Otomatis</div>
                <small class="opacity-75">Token publik + PDF + share WA</small>
              </div>
            </div>
            <div class="d-flex align-items-center gap-3 mb-3">
              <div class="icon-bubble"><i class="bi bi-diagram-3"></i></div>
              <div>
                <div class="fw-semibold">Keuangan Pusat</div>
                <small class="opacity-75">Terawasi langsung oleh pusat</small>
              </div>
            </div>
            <div class="d-flex align-items-center gap-3">
              <div class="icon-bubble"><i class="bi bi-file-earmark-bar-graph"></i></div>
              <div>
                <div class="fw-semibold">Laporan Periode</div>
                <small class="opacity-75">Cabang kirim → pusat review</small>
              </div>
            </div>
          </div>
        </div>

      </div>
    </div>
  </header>

  <section class="py-5">
    <div class="container">
      <div class="row g-3">
        <?php
          $features = (isset($home['features']) && is_array($home['features'])) ? $home['features'] : array();
          if (empty($features)) $features = array(
            array('icon'=>'bi-search', 'title'=>'Tracking Pengajuan', 'desc'=>'Nomor pengajuan & status terpantau.'),
            array('icon'=>'bi-shield-check', 'title'=>'RBAC', 'desc'=>'Akses aman per role & cabang.'),
            array('icon'=>'bi-lightning-charge', 'title'=>'Cepat & Responsif', 'desc'=>'UI modern + animasi halus.'),
          );
        ?>

        <?php foreach ($features as $idx => $f): ?>
          <div class="col-md-4">
            <!-- feature-card sekarang akan floating dan punya shadow -->
            <div class="feature-card">
              <i class="bi <?php echo html_escape($f['icon'] ?? 'bi-dot'); ?>"></i>
              <h5 class="mt-3 mb-1"><?php echo html_escape($f['title'] ?? 'Fitur'); ?></h5>
              <p class="opacity-75 mb-0"><?php echo html_escape($f['desc'] ?? ''); ?></p>
            </div>
          </div>
        <?php endforeach; ?>
      </div>
    </div>
  </section>

  <!-- YOUTUBE PREVIEW -->
  <section class="py-5">
    <div class="container">
      <div class="d-flex align-items-end justify-content-between flex-wrap gap-2 mb-3">
        <div>
          <h3 class="mb-1">Video Panduan</h3>
          <p class="opacity-75 mb-0">Klik thumbnail untuk membuka YouTube.</p>
        </div>
      </div>

      <div class="row g-3">
        <?php
          $videos = (isset($home['videos']) && is_array($home['videos'])) ? $home['videos'] : array();

          // helper kecil untuk ambil youtube id dari URL/ID
          $yt_id = function($val) {
            $val = trim((string)$val);
            if ($val === '') return '';
            // jika sudah id
            if (preg_match('/^[A-Za-z0-9_-]{6,}$/', $val) && strpos($val,'http') !== 0) return $val;

            // youtu.be/ID
            if (preg_match('~youtu\.be/([A-Za-z0-9_-]{6,})~', $val, $m)) return $m[1];
            // youtube.com/watch?v=ID
            if (preg_match('~v=([A-Za-z0-9_-]{6,})~', $val, $m)) return $m[1];
            // youtube.com/embed/ID
            if (preg_match('~/embed/([A-Za-z0-9_-]{6,})~', $val, $m)) return $m[1];
            return '';
          };

          $normalized = array();
          foreach ($videos as $v) {
            if (!is_array($v)) continue;
            $id = $yt_id($v['youtube'] ?? '');
            if (!$id) continue;
            $normalized[] = array('id'=>$id, 'title'=>($v['title'] ?? 'Video'));
          }
          $videos = $normalized;
        ?>

        <?php foreach($videos as $v): ?>
          <div class="col-md-4">
            <!-- yt-card sekarang akan floating dan punya shadow -->
            <a class="yt-card shadow-soft d-block text-decoration-none" target="_blank"
               href="https://youtu.be/<?php echo $v['id']; ?>">
              <div class="ratio ratio-16x9 yt-thumb">
                <img src="https://img.youtube.com/vi/<?php echo $v['id']; ?>/hqdefault.jpg"
                     alt="<?php echo html_escape($v['title']); ?>"
                     loading="lazy">
                <div class="yt-play">
                  <i class="bi bi-play-fill"></i>
                </div>
              </div>
              <div class="p-3">
                <div class="fw-semibold"><?php echo html_escape($v['title']); ?></div>
                <small class="opacity-75">YouTube Preview • Klik untuk menonton</small>
              </div>
            </a>
          </div>
        <?php endforeach; ?>
      </div>
    </div>
  </section>

  <!-- STYLE: cursor typewriter + floating cards -->
  <style>
    /* Cursor untuk typewriter */
    .typed-cursor{
      display:inline-block;
      width:2px;
      height:1em;
      margin-left:.15em;
      vertical-align:-0.12em;
      background:currentColor;
      opacity:.75;
      animation: typedBlink .9s infinite;
    }
    @keyframes typedBlink{ 0%,50%{opacity:.2} 51%,100%{opacity:1} }

    /* ===== Shadow + Floating Animation khusus Landing Cards ===== */

    /* Shadow dasar */
    .bg-landing .glass-card,
    .bg-landing .feature-card,
    .bg-landing .yt-card{
      position: relative;
      border-radius: 16px;
      box-shadow:
        0 10px 30px rgba(0,0,0,.10),
        0 2px 8px rgba(0,0,0,.06);
      transform: translateZ(0);
      will-change: transform;
      transition: transform .25s ease, box-shadow .25s ease;
    }

    /* Hover: naik sedikit */
    .bg-landing .glass-card:hover,
    .bg-landing .feature-card:hover,
    .bg-landing .yt-card:hover{
      transform: translateY(-6px);
      box-shadow:
        0 18px 45px rgba(0,0,0,.14),
        0 6px 16px rgba(0,0,0,.08);
    }

    /* Animasi “loncat” halus */
    @keyframes floatBounce {
      0%, 100% { transform: translateY(0); }
      50%      { transform: translateY(-10px); }
    }

    /* Aktifkan floating */
    .bg-landing .glass-card{ animation: floatBounce 3.6s ease-in-out infinite; }
    .bg-landing .feature-card{ animation: floatBounce 4.2s ease-in-out infinite; }
    .bg-landing .yt-card{ animation: floatBounce 4.8s ease-in-out infinite; }

    /* Variasi delay untuk fitur (3/6 kartu) */
    .bg-landing .feature-card:nth-of-type(1){ animation-delay: .10s; }
    .bg-landing .feature-card:nth-of-type(2){ animation-delay: .35s; }
    .bg-landing .feature-card:nth-of-type(3){ animation-delay: .60s; }
    .bg-landing .feature-card:nth-of-type(4){ animation-delay: .85s; }
    .bg-landing .feature-card:nth-of-type(5){ animation-delay: 1.10s; }
    .bg-landing .feature-card:nth-of-type(6){ animation-delay: 1.35s; }

    /* Variasi delay untuk video */
    .bg-landing .yt-card:nth-of-type(1){ animation-delay: .15s; }
    .bg-landing .yt-card:nth-of-type(2){ animation-delay: .45s; }
    .bg-landing .yt-card:nth-of-type(3){ animation-delay: .75s; }
    .bg-landing .yt-card:nth-of-type(4){ animation-delay: 1.05s; }
    .bg-landing .yt-card:nth-of-type(5){ animation-delay: 1.35s; }
    .bg-landing .yt-card:nth-of-type(6){ animation-delay: 1.65s; }

    /* Aksesibilitas: matikan animasi bila user memilih reduce motion */
    @media (prefers-reduced-motion: reduce){
      .bg-landing .glass-card,
      .bg-landing .feature-card,
      .bg-landing .yt-card{
        animation: none !important;
        transition: none !important;
      }
      .typed-cursor{
        animation: none !important;
      }
    }
  </style>

<?php $this->load->view('partials/scripts'); ?>

  <!-- Typewriter loop (tanpa library) -->
  <script>
  (function(){
    function parseTexts(raw){
      raw = (raw || '').trim();
      if(!raw) return [];
      // dukung pemisah "||"
      if(raw.indexOf('||') !== -1){
        return raw.split('||').map(function(s){ return s.trim(); }).filter(Boolean);
      }
      return [raw];
    }

    function typeLoop(el, texts, opt){
      opt = opt || {};
      var typingSpeed   = opt.typingSpeed   || 36;   // ms/char
      var deletingSpeed = opt.deletingSpeed || 20;   // ms/char
      var holdAfterType = opt.holdAfterType || 1200; // jeda selesai ketik
      var holdAfterDel  = opt.holdAfterDel  || 450;  // jeda selesai hapus
      var loop          = (opt.loop !== false);

      var i = 0;     // index teks
      var j = 0;     // index char
      var deleting = false;

      function tick(){
        var current = texts[i] || '';
        if(!deleting){
          j++;
          el.textContent = current.substring(0, j);
          if(j >= current.length){
            if(!loop && i === texts.length - 1) return;
            deleting = true;
            setTimeout(tick, holdAfterType);
            return;
          }
          setTimeout(tick, typingSpeed);
        } else {
          j--;
          el.textContent = current.substring(0, Math.max(0, j));
          if(j <= 0){
            deleting = false;
            i = (i + 1) % texts.length;
            setTimeout(tick, holdAfterDel);
            return;
          }
          setTimeout(tick, deletingSpeed);
        }
      }

      tick();
    }

    document.addEventListener('DOMContentLoaded', function(){
      var el = document.getElementById('heroTyped');
      if(!el) return;

      var raw = el.getAttribute('data-texts') || '';
      var texts = parseTexts(raw);

      if(texts.length === 0){
        texts = ['Kelola ZISWAF dengan Tracking, Kuitansi Publik, dan Laporan Cabang.'];
      }

      typeLoop(el, texts, {
        typingSpeed: 36,
        deletingSpeed: 20,
        holdAfterType: 1200,
        holdAfterDel: 450,
        loop: true
      });
    });
  })();
  </script>
</body>
</html>
