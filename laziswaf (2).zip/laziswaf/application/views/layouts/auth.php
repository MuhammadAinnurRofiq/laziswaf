<?php $this->load->view('partials/head', array('title'=>$title)); ?>
<body class="bg-auth">
  <div class="auth-wrap">
    <div class="auth-card shadow-soft">
      <?php echo $content; ?>
    </div>
  </div>
<?php $this->load->view('partials/scripts'); ?>
</body>
</html>
