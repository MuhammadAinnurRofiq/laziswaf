<?php $this->load->view('partials/head', array('title'=>$title)); ?>
<body class="bg-app">
  <?php
    $notif_unread = isset($notif_unread) ? (int)$notif_unread : 0;
    $notif_url = ($role === 'CABANG') ? site_url('branch/notifications') : site_url('dashboard/notifications');
  ?>

  <div class="app-shell" id="appShell">
    <?php $this->load->view('partials/sidebar', array('menu'=>$menu, 'role'=>$role)); ?>

    <!-- Mobile overlay backdrop (prevents accidental horizontal scroll & allows tap-to-close) -->
    <div class="sidebar-backdrop" id="sidebarBackdrop" aria-hidden="true"></div>

    <div class="app-main">
      <?php
        // kirim ke navbar agar tombol bell muncul di area topbar/header
        $this->load->view('partials/navbar', array(
          'title'        => $title,
          'user'         => $user,
          'role'         => $role,
          'notif_unread' => $notif_unread,
          'notif_url'    => $notif_url,
        ));
      ?>

      <main class="app-content">
        <?php echo $content; ?>
      </main>

      <?php $this->load->view('partials/footer'); ?>
    </div>
  </div>

<?php $this->load->view('partials/scripts'); ?>
</body>
</html>
