<div class="container-fluid">
  <div class="page-hero mb-3">
    <div>
      <h3 class="mb-1"><?php echo html_escape($title); ?></h3>
      <div class="opacity-75">
        Isi <b>salah satu</b>: <b>Token Kuitansi</b> <i>atau</i> <b>No WhatsApp</b>.
      </div>
    </div>
    <a class="btn btn-soft" href="<?php echo site_url('public'); ?>">
      <i class="bi bi-arrow-left me-2"></i>Kembali
    </a>
  </div>

  <?php if (!empty($error)): ?>
    <div class="alert alert-danger"><?php echo $error; ?></div>
  <?php endif; ?>

  <div class="card shadow-soft">
    <div class="card-body">
      <?php echo form_open('', array('method'=>'get')); ?>
        <div class="row g-3">
          <div class="col-md-6">
            <label class="form-label">Token Kuitansi (opsional)</label>
            <input class="form-control" name="token" value="<?php echo html_escape($token ?? ''); ?>"
                   placeholder="Contoh: 3f1a9c...">
            <div class="form-text">Jika punya token/link, isi ini saja.</div>
          </div>

          <div class="col-md-6">
            <label class="form-label">WhatsApp (opsional)</label>
            <input class="form-control" name="whatsapp" value="<?php echo html_escape($whatsapp ?? ''); ?>"
                   placeholder="Contoh: 0812xxxxxxx atau 62812xxxxxxx">
            <div class="form-text">Jika tidak punya token, isi WA saja untuk mencari kwitansi.</div>
          </div>

          <div class="col-12">
            <button class="btn btn-light">
              <i class="bi bi-search me-2"></i>Cari / Buka
            </button>
          </div>
        </div>
      <?php echo form_close(); ?>

      <div class="small opacity-75 mt-3">
        Cara cepat: buka URL <code>/public/receipt/TOKEN</code>
      </div>
    </div>
  </div>

  <?php if (!empty($receipts) && is_array($receipts)): ?>
    <div class="mt-3">
      <div class="alert alert-info">
        Ditemukan <?php echo count($receipts); ?> kuitansi untuk nomor tersebut. Pilih salah satu:
      </div>

      <div class="row g-3">
        <?php foreach ($receipts as $x): ?>
          <?php
            $nom = $x->amount_money ?: $x->fitrah_total_money;
            $label = strtoupper((string)$x->zis_type_code);
          ?>
          <div class="col-md-6 col-lg-4">
            <div class="card shadow-soft h-100">
              <div class="card-body">
                <div class="fw-semibold"><?php echo html_escape($x->receipt_no); ?></div>
                <div class="small opacity-75">
                  <?php echo html_escape($x->submission_no); ?> • <?php echo html_escape($label); ?><br>
                  Cabang: <?php echo html_escape($x->branch_name); ?><br>
                  Tanggal: <?php echo html_escape($x->receipt_at); ?><br>
                  Nominal: <?php echo number_format((float)$nom, 0, ',', '.'); ?>
                </div>

                <a class="btn btn-light w-100 mt-3"
                   href="<?php echo site_url('public/receipt/'.rawurlencode($x->public_token)); ?>">
                  <i class="bi bi-receipt me-2"></i>Buka Kuitansi
                </a>
              </div>
            </div>
          </div>
        <?php endforeach; ?>
      </div>
    </div>
  <?php endif; ?>
</div>
