<div class="card p-3">
  <h4 class="mb-1">Kalkulator Fidyah</h4>
  <div class="text-muted mb-3">
    Tarif aktif: <b>Rp <?= number_format((float)$rate['tarif_per_hari'],0,',','.') ?></b> / hari
    <?php if (!empty($rate['effective_from'])): ?>
      <span class="ms-2 badge text-bg-light">Berlaku <?= html_escape($rate['effective_from']) ?></span>
    <?php endif; ?>
  </div>

  <div class="row g-3">
    <div class="col-md-4">
      <label class="form-label">Jumlah Jiwa</label>
      <input id="jiwa" type="number" class="form-control" min="1" value="1">
    </div>
    <div class="col-md-4">
      <label class="form-label">Jumlah Hari</label>
      <input id="hari" type="number" class="form-control" min="1" value="1">
    </div>
    <div class="col-md-4">
      <label class="form-label">Total (Rp)</label>
      <input id="totalRp" type="text" class="form-control" readonly>
    </div>
  </div>
</div>

<script>
(function(){
  const tarif = parseFloat("<?= (float)$rate['tarif_per_hari'] ?>") || 0;
  const jiwa = document.getElementById('jiwa');
  const hari = document.getElementById('hari');
  const totalRp = document.getElementById('totalRp');

  function fmtRp(n){ return (n||0).toLocaleString('id-ID'); }

  function calc(){
    const j = parseInt(jiwa.value||"0",10) || 1;
    const h = parseInt(hari.value||"0",10);
    totalRp.value = fmtRp(h * tarif * j);
  }

  jiwa.addEventListener('input', calc);
  hari.addEventListener('input', calc);
  calc();
})();
</script>
