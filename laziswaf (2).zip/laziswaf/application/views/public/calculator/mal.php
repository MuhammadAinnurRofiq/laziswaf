<div class="card p-3">
  <h4 class="mb-1">Kalkulator Zakat Maal</h4>
  <div class="text-muted mb-3">
    Nisab aktif: <b>Rp <?= number_format((float)$rate['nisab_amount'],0,',','.') ?></b> |
    Persen: <b><?= html_escape($rate['percent']) ?>%</b>
    <?php if (!empty($rate['effective_from'])): ?>
      <span class="ms-2 badge text-bg-light">Berlaku <?= html_escape($rate['effective_from']) ?></span>
    <?php endif; ?>
  </div>

  <div class="row g-3">
    <div class="col-md-6">
      <label class="form-label">Total Harta (Rp)</label>
      <input id="harta" type="number" class="form-control" min="0" value="0">
    </div>
    <div class="col-md-6">
      <label class="form-label">Zakat yang Harus Dibayar (Rp)</label>
      <input id="zakat" type="text" class="form-control" readonly>
    </div>
    <div class="col-12">
      <div id="info" class="text-muted small"></div>
    </div>
  </div>
</div>

<script>
(function(){
  const nisab = parseFloat("<?= (float)$rate['nisab_amount'] ?>") || 0;
  const percent = parseFloat("<?= (float)$rate['percent'] ?>") || 2.5;

  const harta = document.getElementById('harta');
  const zakat = document.getElementById('zakat');
  const info = document.getElementById('info');

  function fmtRp(n){ return (n||0).toLocaleString('id-ID'); }

  function calc(){
    const v = parseFloat(harta.value||"0") || 0;
    if (v < nisab) {
      zakat.value = "0";
      info.innerHTML = "Harta belum mencapai nisab, zakat maal tidak wajib.";
      return;
    }
    const z = v * (percent/100);
    zakat.value = fmtRp(Math.round(z));
    info.innerHTML = "Harta sudah mencapai nisab, zakat maal = " + percent + "% dari harta.";
  }

  harta.addEventListener('input', calc);
  calc();
})();
</script>
