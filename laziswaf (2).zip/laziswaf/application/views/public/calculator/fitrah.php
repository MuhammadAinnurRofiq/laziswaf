<div class="card p-3">
  <h4 class="mb-1">Kalkulator Zakat Fitrah</h4>
  <div class="text-muted mb-3">
    Tarif aktif: Kg/Jiwa <b><?= html_escape($rate['kg_per_jiwa']) ?></b>,
    Harga/Jiwa <b>Rp <?= number_format((float)$rate['harga_per_jiwa'],0,',','.') ?></b>
    <?php if (!empty($rate['effective_from'])): ?>
      <span class="ms-2 badge text-bg-light">Berlaku <?= html_escape($rate['effective_from']) ?></span>
    <?php endif; ?>
  </div>

  <div class="row g-3">
    <div class="col-md-4">
      <label class="form-label">Jumlah Jiwa</label>
      <input id="jiwa" type="number" class="form-control" min="1" value="1">
    </div>

    <div class="col-md-4">
      <label class="form-label">Total Beras (Kg)</label>
      <input id="totalKg" type="text" class="form-control" readonly>
    </div>

    <div class="col-md-4">
      <label class="form-label">Total Uang (Rp)</label>
      <input id="totalRp" type="text" class="form-control" readonly>
    </div>
  </div>
</div>

<script>
(function(){
  const kgPerJiwa = parseFloat("<?= (float)$rate['kg_per_jiwa'] ?>") || 0;
  const hargaPerJiwa = parseFloat("<?= (float)$rate['harga_per_jiwa'] ?>") || 0;

  const jiwa = document.getElementById('jiwa');
  const totalKg = document.getElementById('totalKg');
  const totalRp = document.getElementById('totalRp');

  function fmtRp(n){
    return (n||0).toLocaleString('id-ID');
  }

  function calc(){
    const j = parseInt(jiwa.value||"0",10);
    const kg = j * kgPerJiwa;
    const rp = j * hargaPerJiwa;
    totalKg.value = kg.toFixed(2);
    totalRp.value = fmtRp(rp);
  }

  jiwa.addEventListener('input', calc);
  calc();
})();
</script>
