<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>

<div class="container-fluid">
  <div class="page-hero mb-3">
    <div>
      <h3 class="mb-1"><?php echo html_escape($title); ?></h3>
      <div class="opacity-75">Hasil pencarian status pengajuan.</div>
    </div>
    <div class="d-flex gap-2 flex-wrap">
      <a class="btn btn-soft" href="<?php echo site_url('public/track'); ?>">
        <i class="bi bi-arrow-left me-2"></i>Ulangi
      </a>
    </div>
  </div>

  <?php if (!empty($list) && is_array($list)): ?>
    <div class="alert alert-info">Ditemukan beberapa pengajuan dari WhatsApp tersebut. Pilih salah satu:</div>
    <div class="row g-3">
      <?php foreach ($list as $x): ?>
        <div class="col-md-6 col-lg-4">
          <div class="card shadow-soft">
            <div class="card-body">
              <div class="fw-semibold"><?php echo html_escape($x->submission_no); ?></div>
              <div class="small opacity-75">
                <?php echo html_escape($x->applicant_name); ?> • <?php echo html_escape($x->zis_type_code); ?><br>
                <?php echo html_escape($x->branch_name ?? '-'); ?><br>
                <?php echo html_escape($x->submitted_at); ?> • <?php echo html_escape($x->status); ?>
              </div>
              <a class="btn btn-light w-100 mt-3"
                 href="<?php echo site_url('public/track/check?submission_no='.rawurlencode($x->submission_no)); ?>">
                Lihat Detail
              </a>
            </div>
          </div>
        </div>
      <?php endforeach; ?>
    </div>
    <?php return; ?>
  <?php endif; ?>

  <?php if (!$sub): ?>
    <div class="alert alert-warning">
      Data tidak ditemukan. Pastikan <b>Nomor Pengajuan</b> atau <b>WhatsApp</b> yang Anda masukkan benar.
    </div>
    <?php return; ?>
  <?php endif; ?>

  <div class="card shadow-soft">
    <div class="card-body">
      <div class="row g-3">
        <div class="col-md-4">
          <div class="opacity-75">Nomor Pengajuan</div>
          <div class="fw-semibold"><?php echo html_escape($sub->submission_no); ?></div>
        </div>
        <div class="col-md-4">
          <div class="opacity-75">Nama</div>
          <div class="fw-semibold"><?php echo html_escape($sub->applicant_name); ?></div>
        </div>
        <div class="col-md-4">
          <div class="opacity-75">Cabang</div>
          <div class="fw-semibold"><?php echo html_escape($sub->branch_name ?? '-'); ?></div>
        </div>

        <div class="col-md-4">
          <div class="opacity-75">Jenis</div>
          <div class="fw-semibold"><?php echo html_escape($sub->zis_type_code); ?></div>
        </div>
        <div class="col-md-4">
          <div class="opacity-75">Tanggal Submit</div>
          <div class="fw-semibold"><?php echo html_escape($sub->submitted_at); ?></div>
        </div>
        <div class="col-md-4">
          <div class="opacity-75">Status</div>
          <div class="fw-semibold">
            <span class="badge text-bg-secondary"><?php echo html_escape($sub->status); ?></span>
            <?php if ($sub->status === 'EXPIRED'): ?>
              <div class="alert alert-danger mt-3 mb-0">
                Pengajuan ini sudah <b>EXPIRED</b> karena melewati batas waktu
                <?php echo (defined('SUBMISSION_EXPIRE_MINUTES') ? SUBMISSION_EXPIRE_MINUTES : 10); ?> menit sejak jam submit.
                Silakan ajukan ulang.
              </div>
            <?php elseif ($sub->status === 'DELETED'): ?>
              <div class="alert alert-warning mt-3 mb-0">
                Data pengajuan ini sudah <b>DIHAPUS</b> oleh petugas cabang.
                Jika masih ingin melanjutkan, silakan ajukan ulang.
              </div>
            <?php endif; ?>

          </div>
        </div>

        <div class="col-12">
          <hr class="opacity-25">
        </div>

        <?php
          $nom = $sub->amount_money ?: $sub->fitrah_total_money;
          $kg  = $sub->fitrah_total_kg;
        ?>
        <div class="col-md-6">
          <div class="opacity-75">Nominal</div>
          <div class="fw-semibold">
            <?php echo $nom ? 'Rp '.number_format((float)$nom,0,',','.') : '-'; ?>
            <?php if (!empty($kg)): ?>
              <span class="ms-2 badge text-bg-secondary"><?php echo (float)$kg; ?> kg</span>
            <?php endif; ?>
          </div>
        </div>

        <div class="col-md-6">
          <div class="opacity-75">Kuitansi</div>
          <?php if (!empty($sub->public_token)): ?>
            <?php if (!empty($sub->receipt_is_void) && (int)$sub->receipt_is_void === 1): ?>
              <div class="alert alert-warning mt-2 mb-2">
                Kuitansi sudah <b>VOID</b> dan tidak berlaku. Anda tetap bisa membukanya untuk melihat riwayat.
                <?php if (!empty($sub->void_reason)): ?>
                  <div class="small opacity-75">Alasan: <?php echo html_escape($sub->void_reason); ?></div>
                <?php endif; ?>
              </div>
            <?php endif; ?>
            <div class="fw-semibold">
              <a class="text-decoration-none" target="_blank" href="<?php echo site_url('public/receipt/'.$sub->public_token); ?>">
                Buka Kuitansi Publik <i class="bi bi-box-arrow-up-right ms-1"></i>
              </a>
              <div class="small opacity-75">No: <?php echo html_escape($sub->receipt_no); ?></div>
            </div>
          <?php else: ?>
            <div class="opacity-75">Belum tersedia (menunggu approve cabang).</div>
          <?php endif; ?>
        </div>

        <?php if (($sub->status === 'NEED_FIX' || $sub->status === 'BRANCH_REJECTED') && !empty($sub->last_note)): ?>
          <div class="col-12">
            <div class="alert alert-warning mb-0">
              <b>Catatan:</b> <?php echo html_escape($sub->last_note); ?>
              <div class="small opacity-75 mt-1">Update: <?php echo html_escape($sub->last_log_at); ?></div>
            </div>
          </div>
        <?php endif; ?>
      </div>
    </div>
  </div>
</div>
