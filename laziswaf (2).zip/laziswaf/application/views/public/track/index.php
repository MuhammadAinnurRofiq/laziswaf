<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>

<div class="container-fluid">
  <div class="page-hero mb-3">
    <div>
      <h3 class="mb-1"><?php echo html_escape($title); ?></h3>
      <div class="opacity-75">Masukkan <b>salah satu</b>: <b>Nomor Pengajuan</b> <i>atau</i> <b>WhatsApp</b> yang dipakai saat submit.</div>
    </div>
    <a class="btn btn-soft" href="<?php echo site_url('public'); ?>">
      <i class="bi bi-arrow-left me-2"></i>Kembali
    </a>
  </div>

  <?php if (!empty($error)): ?>
    <div class="alert alert-danger"><?php echo $error; ?></div>
  <?php endif; ?>

  <div class="card shadow-soft">
    <div class="card-body">
      <?php echo form_open(site_url('public/track/check')); ?>
        <div class="row g-3">

          <div class="col-md-6">
            <label class="form-label">Nomor Pengajuan (opsional)</label>
            <input class="form-control" name="submission_no" placeholder="Contoh: SUB-202601-000001">
          </div>

          <div class="col-md-6">
            <label class="form-label">WhatsApp (opsional)</label>
            <input class="form-control" name="whatsapp" placeholder="Contoh: 0812xxxxxxx / 62812xxxxxxx">
          </div>

          <div class="col-12">
            <button class="btn btn-light">
              <i class="bi bi-search me-2"></i>Cek Status
            </button>
          </div>
        </div>
      <?php echo form_close(); ?>
    </div>
  </div>
</div>
