<?php
defined('BASEPATH') OR exit('No direct script access allowed');

// pola aman
$rate = $rate ?? null;

// pastikan kode jenis tersedia (controller Anda kirim: $zis_code)
$zis_type_code = strtoupper((string)($zis_type_code ?? ($zis_code ?? '')));
?>

<div class="container-fluid">
  <div class="row g-3">
    <div class="col-12">
      <div class="page-hero">
        <div>
          <h3 class="mb-1"><?php echo html_escape($title); ?></h3>
          <div class="opacity-75">Isi data berikut. Setelah submit, Anda akan mendapat nomor pengajuan untuk tracking.</div>
        </div>
        <a class="btn btn-soft" href="<?php echo site_url('public/track'); ?>">
          <i class="bi bi-search me-2"></i>Cek Status
        </a>
      </div>
    </div>

    <div class="col-lg-8">
      <div class="card shadow-soft">
        <div class="card-body">
          <?php
            // Default action untuk publik. Bisa dioverride (mis. form cabang).
            $form_action = isset($form_action) && $form_action ? $form_action : site_url('public/submission/store');
            echo form_open($form_action);
          ?>
            <input type="hidden" name="type" value="<?php echo html_escape($type); ?>">

            <div class="row g-2">
              <div class="col-md-6 mb-3">
                <label class="form-label">Cabang Tujuan</label>

                <?php if (!empty($fixed_branch_id)): ?>
                  <input class="form-control" value="<?php echo html_escape($fixed_branch_name); ?>" disabled>
                  <input type="hidden" name="branch_id" value="<?php echo (int)$fixed_branch_id; ?>">
                  <?php $fixed_branch_note = isset($fixed_branch_note) ? (string)$fixed_branch_note : 'Dipilih otomatis dari QR cabang.'; ?>
                  <div class="text-muted small"><?php echo html_escape($fixed_branch_note); ?></div>
                <?php else: ?>
                  <select name="branch_id" class="form-select" required>
                    <option value="">-- pilih cabang --</option>
                    <?php foreach($branches as $b): ?>
                      <option value="<?php echo (int)$b->id; ?>" <?php echo set_select('branch_id', $b->id); ?>>
                        <?php echo html_escape($b->branch_name); ?>
                      </option>
                    <?php endforeach; ?>
                  </select>
                <?php endif; ?>

                <small class="text-danger"><?php echo form_error('branch_id'); ?></small>
              </div>

              <div class="col-md-6 mb-3">
                <label class="form-label">No. WhatsApp</label>
                <input name="whatsapp" class="form-control" placeholder="contoh: 62812xxxx" value="<?php echo set_value('whatsapp'); ?>" required>
                <small class="text-danger"><?php echo form_error('whatsapp'); ?></small>
              </div>
            </div>

            <div class="mb-3">
              <label class="form-label">Nama Pengaju (Kepala Keluarga / Donatur)</label>
              <input name="applicant_name" class="form-control" value="<?php echo set_value('applicant_name'); ?>" required>
              <small class="text-danger"><?php echo form_error('applicant_name'); ?></small>
            </div>

            <?php if ($type === 'fitrah'): ?>
              <div class="row g-2">
                <div class="col-md-6 mb-3">
                  <label class="form-label">Jumlah Jiwa</label>
                  <input type="number" min="1" name="jiwa_count" class="form-control" value="<?php echo set_value('jiwa_count'); ?>" required>
                  <small class="text-danger"><?php echo form_error('jiwa_count'); ?></small>
                </div>
                <div class="col-md-6 mb-3">
                  <label class="form-label">Metode Pembayaran</label>
                  <select name="pay_method_id" class="form-select" required>
                    <option value="">-- pilih metode --</option>
                    <?php foreach($methods as $m): ?>
                      <option
                        value="<?php echo (int)$m->id; ?>"
                        data-code="<?php echo html_escape($m->code ?? ''); ?>"
                        <?php echo set_select('pay_method_id', $m->id); ?>
                      >
                        <?php echo html_escape($m->name); ?>
                      </option>
                    <?php endforeach; ?>
                  </select>
                  <small class="text-danger"><?php echo form_error('pay_method_id'); ?></small>
                </div>
              </div>

              <div class="mb-3">
                <label class="form-label">Nama Tanggungan (Opsional)</label>
                <textarea name="people_text" class="form-control" rows="4" placeholder="1 baris = 1 nama"><?php echo set_value('people_text'); ?></textarea>
                <div class="form-text opacity-75">Isi jika ingin nama jiwa tercatat. Jika kosong, tetap bisa submit.</div>
              </div>

            <?php elseif ($type === 'fidyah'): ?>
              <div class="row g-2">
                <div class="col-md-4 mb-3">
                  <label class="form-label">Jumlah Jiwa</label>
                  <input type="number" min="1" name="jiwa_count" class="form-control" value="<?php echo set_value('jiwa_count', '1'); ?>" required>
                  <small class="text-danger"><?php echo form_error('jiwa_count'); ?></small>
                </div>
                <div class="col-md-4 mb-3">
                  <label class="form-label">Jumlah Hari</label>
                  <input type="number" min="1" name="fidyah_days" class="form-control" value="<?php echo set_value('fidyah_days','1'); ?>" required>
                  <small class="text-danger"><?php echo form_error('fidyah_days'); ?></small>
                </div>
                <div class="col-md-4 mb-3">
                  <label class="form-label">Tarif / Hari (otomatis)</label>
                  <input class="form-control"
                         value="<?php echo $rate && !empty($rate->tarif_per_hari) ? number_format((float)$rate->tarif_per_hari,0,',','.') : '0'; ?>"
                         disabled>
                </div>
              </div>

            <?php else: ?>
              <div class="mb-3">
                <label class="form-label">Nominal (Rp)</label>
                <input type="number" min="1" name="amount_money" class="form-control" value="<?php echo set_value('amount_money'); ?>" required>
                <small class="text-danger"><?php echo form_error('amount_money'); ?></small>
                <div class="form-text opacity-75">Isi nominal sesuai kemampuan / perhitungan Anda.</div>
              </div>
            <?php endif; ?>

            <button class="btn btn-light btn-lg w-100">
              <i class="bi bi-send me-2"></i>Kirim Pengajuan
            </button>

          <?php echo form_close(); ?>
        </div>
      </div>
    </div>

    <div class="col-lg-4">
      <div class="card p-3">
        <div class="fw-semibold mb-2">Info Tarif Saat Ini</div>

        <?php if (!$rate): ?>
          <div class="text-muted">Tarif belum diatur oleh Admin/Bendahara.</div>
        <?php else: ?>
          <div class="small text-muted">Berlaku sejak: <?php echo html_escape($rate->effective_from); ?></div>

          <?php if ($zis_type_code === 'FITRAH'): ?>
            <div id="rateBoxFitrah"
                 data-kg-per-jiwa="<?php echo (float)($rate->kg_per_jiwa ?? 0); ?>"
                 data-harga-per-jiwa="<?php echo (float)($rate->harga_per_jiwa ?? 0); ?>">

              <div class="mt-2 small">Kg/jiwa:
                <b><?php echo html_escape($rate->kg_per_jiwa); ?></b>
              </div>

              <div class="small">Harga/jiwa:
                <b>Rp <?php echo number_format((float)$rate->harga_per_jiwa, 0, ',', '.'); ?></b>
              </div>

              <hr class="my-2">

              <div class="small">Total Beras (otomatis):
                <b><span id="fitrahTotalKg">0</span> kg</b>
              </div>

              <div class="small">Total Uang (otomatis):
                <b>Rp <span id="fitrahTotalMoney">0</span></b>
              </div>

              <div class="small mt-1">Yang harus dibayar:
                <b><span id="fitrahPayable">-</span></b>
              </div>
            </div>

          <?php elseif ($zis_type_code === 'FIDYAH'): ?>
            <div id="rateBoxFidyah"
                 data-tarif-per-hari="<?php echo (float)($rate->tarif_per_hari ?? 0); ?>">

              <div class="mt-2 small">Tarif/hari:
                <b>Rp <?php echo number_format((float)$rate->tarif_per_hari, 0, ',', '.'); ?></b>
              </div>

              <hr class="my-2">

              <div class="small">Total (otomatis):
                <b>Rp <span id="fidyahTotalMoney">0</span></b>
              </div>

              <div class="small mt-1">Yang harus dibayar:
                <b><span id="fidyahPayable">-</span></b>
              </div>
            </div>

          <?php elseif ($zis_type_code === 'MAL'): ?>
            <div class="mt-2 small">Nisab: <b>Rp <?php echo number_format((float)$rate->nisab_amount, 0, ',', '.'); ?></b></div>
            <div class="small">Persen: <b><?php echo html_escape($rate->percent); ?>%</b></div>

          <?php else: ?>
            <div class="mt-2 small text-muted">Jenis: <?php echo html_escape($zis_type_code); ?></div>
          <?php endif; ?>
        <?php endif; ?>
      </div>
    </div>

  </div>
</div>

<script>
(function(){
  function n(v){
    v = (v ?? '').toString().trim();
    if (!v) return 0;
    v = v.replace(/[^0-9.,-]/g,'');
    if (v.indexOf(',') !== -1 && v.indexOf('.') !== -1) {
      v = v.replace(/\./g,'').replace(',','.');
    } else {
      v = v.replace(',','.');
    }
    var x = parseFloat(v);
    return isNaN(x) ? 0 : x;
  }

  function fmtRp(num){
    num = Math.round(num || 0);
    return new Intl.NumberFormat('id-ID').format(num);
  }

  function fmtKg(num){
    num = (num || 0);
    var s = num.toFixed(2);
    s = s.replace(/\.00$/,'').replace(/(\.\d)0$/,'$1');
    return s;
  }

  function calcFitrah(){
    var box = document.getElementById('rateBoxFitrah');
    if (!box) return;

    var kgPerJiwa    = n(box.getAttribute('data-kg-per-jiwa'));
    var hargaPerJiwa = n(box.getAttribute('data-harga-per-jiwa'));

    var jiwaEl = document.querySelector('input[name="jiwa_count"]');
    var metEl  = document.querySelector('select[name="pay_method_id"]');

    var jiwa = jiwaEl ? n(jiwaEl.value) : 0;
    var totalKg    = jiwa * kgPerJiwa;
    var totalMoney = jiwa * hargaPerJiwa;

    var spanKg = document.getElementById('fitrahTotalKg');
    var spanRp = document.getElementById('fitrahTotalMoney');
    var spanPay= document.getElementById('fitrahPayable');

    if (spanKg) spanKg.textContent = fmtKg(totalKg);
    if (spanRp) spanRp.textContent = fmtRp(totalMoney);

    var code = '';
    if (metEl && metEl.selectedOptions && metEl.selectedOptions[0]) {
      code = (metEl.selectedOptions[0].getAttribute('data-code') || '').toUpperCase();
      if (!code) {
        var t = (metEl.selectedOptions[0].textContent || '').toLowerCase();
        if (t.indexOf('beras') !== -1) code = 'RICE';
      }
    }

    if (!jiwa || jiwa < 1) {
      if (spanPay) spanPay.textContent = '-';
      return;
    }

    if (code === 'RICE') {
      if (spanPay) spanPay.textContent = fmtKg(totalKg) + ' kg beras';
    } else {
      if (spanPay) spanPay.textContent = 'Rp ' + fmtRp(totalMoney);
    }
  }

  function calcFidyah(){
    var box = document.getElementById('rateBoxFidyah');
    if (!box) return;

    var tarif = n(box.getAttribute('data-tarif-per-hari'));
    var daysEl = document.querySelector('input[name="fidyah_days"]');
    var jiwaEl = document.querySelector('input[name="jiwa_count"]');

    var days = daysEl ? n(daysEl.value) : 0;
    var jiwa = jiwaEl ? n(jiwaEl.value) : 1;
    if (!jiwa || jiwa < 1) jiwa = 1;

    var total = days * tarif * jiwa;

    var spanRp = document.getElementById('fidyahTotalMoney');
    var spanPay= document.getElementById('fidyahPayable');

    if (spanRp) spanRp.textContent = fmtRp(total);
    if (spanPay) spanPay.textContent = (days && days >= 1) ? ('Rp ' + fmtRp(total)) : '-';
  }

  document.addEventListener('input', function(e){
    if (e.target && (e.target.name === 'jiwa_count' || e.target.name === 'pay_method_id')) calcFitrah();
    if (e.target && (e.target.name === 'fidyah_days' || e.target.name === 'jiwa_count')) calcFidyah();
  });

  document.addEventListener('change', function(e){
    if (e.target && e.target.name === 'pay_method_id') calcFitrah();
  });

  calcFitrah();
  calcFidyah();
})();
</script>
