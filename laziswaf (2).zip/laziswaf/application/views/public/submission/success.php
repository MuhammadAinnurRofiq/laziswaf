<div class="container-fluid">
  <div class="row g-3">
    <div class="col-12">
      <div class="page-hero">
        <div>
          <h3 class="mb-1">Pengajuan Berhasil</h3>
          <div class="opacity-75">Simpan nomor pengajuan berikut untuk cek status:</div>
          <div class="display-6 fw-bold mt-2"><?php echo html_escape($submission_no); ?></div>
        </div>
        <div class="d-flex gap-2 flex-wrap">
          <?php if (isset($role) && strtoupper((string)$role) === 'CABANG'): ?>
            <a class="btn btn-light" href="<?php echo site_url('branch/submissions'); ?>">
              <i class="bi bi-inbox me-2"></i>Kembali ke Inbox
            </a>
            <a class="btn btn-soft" href="<?php echo site_url('public/track'); ?>">
              <i class="bi bi-search me-2"></i>Cek Status (Publik)
            </a>
          <?php else: ?>
            <a class="btn btn-light" href="<?php echo site_url('public/track'); ?>">
              <i class="bi bi-search me-2"></i>Cek Status
            </a>
            <a class="btn btn-soft" href="<?php echo site_url('public'); ?>">
              <i class="bi bi-speedometer2 me-2"></i>Dashboard Publik
            </a>
          <?php endif; ?>
        </div>
      </div>
    </div>

    <div class="col-12">
      <div class="card shadow-soft">
        <div class="card-body">
          <p class="mb-0 opacity-75">
            Status awal pengajuan adalah <strong>SUBMITTED</strong>.
            Setelah diverifikasi cabang, status akan berubah dan kuitansi dapat diterbitkan.
          </p>
        </div>
      </div>
    </div>
  </div>
</div>
