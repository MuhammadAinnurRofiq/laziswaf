<!doctype html>
<html lang="id">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <?php
    // Nama & logo aplikasi (jika helper tersedia)
    $appName = function_exists('app_setting') ? app_setting('app_name','LAZISWAF') : 'LAZISWAF';
    $logoUrl = function_exists('app_logo_url') ? app_logo_url() : '';
    $pageTitle = $title ?? $appName;
  ?>
  <title><?php echo html_escape($pageTitle); ?></title>

  <?php if (!empty($logoUrl)): ?>
  <link rel="icon" type="image/png" href="<?php echo $logoUrl; ?>">
  <link rel="apple-touch-icon" href="<?php echo $logoUrl; ?>">
<?php endif; ?>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css" rel="stylesheet">

  <?php $appCssVer = @filemtime(FCPATH.'assets/css/app.css') ?: time(); ?>
  <link href="<?php echo base_url('assets/css/app.css?v='.$appCssVer); ?>" rel="stylesheet">
</head>
