<?php
$appName = app_setting('app_name','LAZISWAF');
$logoUrl = app_logo_url();

$leftText = trim((string)app_setting('footer_left_text',''));
if ($leftText === '') $leftText = '© ' . date('Y') . ' ' . $appName;

$buildLabel = trim((string)app_setting('footer_build_label','Built with'));
$ciText     = trim((string)app_setting('footer_ci_text','CI3'));
$bsText     = trim((string)app_setting('footer_bs_text','Bootstrap 5'));
$noteText   = trim((string)app_setting('footer_note_text',''));

$rightText = $buildLabel . ' ' . $ciText . ' + ' . $bsText;
if ($noteText !== '') $rightText .= ' • ' . $noteText;
?>

<footer class="app-footer">
  <div class="container-fluid d-flex justify-content-between align-items-center">
    <div class="d-flex align-items-center gap-2">
      <?php if ($logoUrl): ?>
        <img class="brand-logo" src="<?php echo $logoUrl; ?>" alt="<?php echo html_escape($appName); ?>">
      <?php else: ?>
        <span class="brand-dot"></span>
      <?php endif; ?>
      <small class="opacity-75"><?php echo html_escape($leftText); ?></small>
    </div>

    <small class="opacity-75"><?php echo html_escape($rightText); ?></small>
  </div>
</footer>
