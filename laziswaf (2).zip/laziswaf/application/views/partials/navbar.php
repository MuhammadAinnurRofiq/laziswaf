<nav class="navbar navbar-expand-lg navbar-dark app-navbar">
  <div class="container-fluid">
    <button class="btn btn-icon me-2" type="button" id="btnSidebar">
      <i class="bi bi-grid-fill"></i>
    </button>

    <button class="btn btn-icon me-2" type="button" id="btnTheme" aria-pressed="false" title="Ubah Tema">
      <i class="bi bi-sun"></i>
    </button>

    <?php $appName = app_setting('app_name','LAZISWAF'); $logoUrl = app_logo_url(); ?>
    <span class="navbar-brand d-flex align-items-center gap-2">
      <?php if ($logoUrl): ?>
        <img class="brand-logo" src="<?php echo $logoUrl; ?>" alt="<?php echo html_escape($appName); ?>">
      <?php else: ?>
        <span class="brand-dot"></span>
      <?php endif; ?>
      <strong><?php echo html_escape($appName); ?></strong>
      <small class="ms-2 badge text-bg-light text-dark"><?php echo html_escape($role); ?></small>
    </span>

    <?php $isPublic = (isset($role) && $role === 'PUBLIC'); ?>

    <div class="ms-auto d-flex align-items-center gap-2">
      <div class="text-end d-none d-md-block">
        <div class="fw-semibold"><?php echo html_escape($user->full_name ?? ''); ?></div>
        <small class="opacity-75">@<?php echo html_escape($user->username ?? ''); ?></small>
      </div>

      <?php if ($isPublic): ?>
        <a class="btn btn-soft" href="<?php echo site_url('login'); ?>">
          <i class="bi bi-box-arrow-in-right me-1"></i>Login Petugas
        </a>
      <?php else: ?>
        <div class="dropdown">
          <button class="btn btn-soft dropdown-toggle" data-bs-toggle="dropdown">
            <i class="bi bi-person-circle me-1"></i> Akun
          </button>
          <ul class="dropdown-menu dropdown-menu-end">
            <li><a class="dropdown-item" href="<?php echo site_url('dashboard'); ?>"><i class="bi bi-speedometer2 me-2"></i>Dashboard</a></li>
            <li><hr class="dropdown-divider"></li>
            <li><a class="dropdown-item text-danger" href="<?php echo site_url('logout'); ?>"><i class="bi bi-box-arrow-right me-2"></i>Logout</a></li>
          </ul>
        </div>
      <?php endif; ?>
    </div>
  </div>
</nav>
