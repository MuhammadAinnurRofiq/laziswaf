<?php
defined('BASEPATH') OR exit('No direct script access allowed');

// pemakaian:
// $this->load->view('partials/print_header', ['print_title'=>'...', 'print_year'=>'2026']);

$appName  = function_exists('app_setting') ? app_setting('app_name','LAZISWAF') : 'LAZISWAF';
$logoUrl  = function_exists('app_logo_url') ? app_logo_url() : '';

$print_title = isset($print_title) ? (string)$print_title : '';
$print_year  = isset($print_year) ? (string)$print_year : date('Y');
$print_subtitle = isset($print_subtitle) ? (string)$print_subtitle : '';
?>

<div class="print-header">
  <div class="ph-left">
    <?php if (!empty($logoUrl)): ?>
      <img class="ph-logo" src="<?php echo $logoUrl; ?>" alt="<?php echo html_escape($appName); ?>">
    <?php else: ?>
      <span class="ph-dot" aria-hidden="true"></span>
    <?php endif; ?>

    <div class="ph-text">
      <div class="ph-app"><?php echo html_escape($appName); ?></div>
      <?php if ($print_subtitle !== ''): ?>
        <div class="ph-subtitle"><?php echo html_escape($print_subtitle); ?></div>
      <?php endif; ?>
    </div>
  </div>

  <div class="ph-right">
    <?php if ($print_title !== ''): ?>
      <div class="ph-title"><?php echo html_escape($print_title); ?></div>
    <?php endif; ?>
    <div class="ph-year"><?php echo html_escape($print_year); ?></div>
  </div>
</div>
