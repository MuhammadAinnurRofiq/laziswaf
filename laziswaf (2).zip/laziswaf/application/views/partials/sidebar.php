<?php $current = current_url(); ?>

<aside class="app-sidebar" id="appSidebar">
  <div class="sidebar-header">
    <div class="d-flex align-items-center gap-2">
      <?php $appName = app_setting('app_name','LAZISWAF'); $logoUrl = app_logo_url(); ?>
      <?php if ($logoUrl): ?>
        <img class="brand-logo" src="<?php echo $logoUrl; ?>" alt="<?php echo html_escape($appName); ?>">
      <?php else: ?>
        <span class="brand-dot"></span>
      <?php endif; ?>
      <div class="brand-text">
        <div class="fw-bold"><?php echo html_escape($appName); ?></div>
        <small class="opacity-75">Menu <?php echo html_escape($role); ?></small>
      </div>
    </div>
  </div>

  <div class="sidebar-body">
    <ul class="nav flex-column sidebar-nav">
      <?php foreach ($menu as $item): ?>
        <?php if (isset($item['children'])): ?>
          <li class="nav-item">
            <button class="nav-link sidebar-parent" type="button" data-submenu>
              <i class="bi <?php echo html_escape($item['icon']); ?> me-2"></i>
              <span><?php echo html_escape($item['label']); ?></span>
              <i class="bi bi-chevron-down ms-auto chevron"></i>
            </button>
            <ul class="submenu">
              <?php foreach ($item['children'] as $child): ?>
                <?php $isChildActive = ($current === $child['url']); ?>
                <li>
                  <a class="nav-link <?php echo $isChildActive ? 'active' : ''; ?>" href="<?php echo $child['url']; ?>">
                    <span class="dot"></span>
                    <?php echo html_escape($child['label']); ?>
                  </a>
                </li>
              <?php endforeach; ?>
            </ul>
          </li>
        <?php else: ?>
          <?php $isActive = ($current === $item['url']); ?>
          <li class="nav-item">
            <a class="nav-link <?php echo $isActive ? 'active' : ''; ?>" href="<?php echo $item['url']; ?>">
              <i class="bi <?php echo html_escape($item['icon']); ?> me-2"></i>
              <span><?php echo html_escape($item['label']); ?></span>
            </a>
          </li>
        <?php endif; ?>
      <?php endforeach; ?>
    </ul>
  </div>

  <div class="sidebar-footer">
    <?php
      $leftText = trim((string)app_setting('footer_left_text',''));
      if ($leftText === '') $leftText = '© ' . date('Y') . ' ' . $appName;
    ?>
    <small class="opacity-75"><?php echo html_escape($leftText); ?></small>
  </div>
</aside>
