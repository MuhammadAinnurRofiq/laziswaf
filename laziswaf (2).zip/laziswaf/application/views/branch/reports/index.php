<div class="container-fluid">
  <div class="page-hero mb-3">
    <div>
      <h3 class="mb-1"><?php echo html_escape($title); ?></h3>
      <div class="opacity-75">Buat laporan per periode, kirim ke pusat, lalu tunggu review.</div>
    </div>
  </div>

  <?php if (!empty($ok)): ?><div class="alert alert-success"><?php echo $ok; ?></div><?php endif; ?>
  <?php if (!empty($err)): ?><div class="alert alert-danger"><?php echo $err; ?></div><?php endif; ?>

  <div class="card shadow-soft mb-3">
    <div class="card-body">
      <form method="post" action="<?php echo site_url('branch/reports/create'); ?>">
        <div class="row g-3 align-items-end">
          <div class="col-md-6">
            <label class="form-label" for="period_id">Periode</label>

            <select class="form-select" name="period_id" id="period_id" required>
              <option value="">-- Pilih Periode --</option>

              <?php foreach (($periods ?? []) as $p): ?>
                <?php
                  $label = $p['year'].'-'.str_pad((string)$p['month'], 2, '0', STR_PAD_LEFT)
                    .' ('.$p['start_date'].' s/d '.$p['end_date'].')';
                  $selected = ((int)($selected_period_id ?? 0) === (int)$p['id']) ? 'selected' : '';
                ?>
                <option value="<?php echo (int)$p['id']; ?>" <?php echo $selected; ?>>
                  <?php echo html_escape($label); ?>
                </option>
              <?php endforeach; ?>
            </select>
            <!-- ✅ tidak ada disabled di select -->
          </div>

          <div class="col-md-6">
            <button class="btn btn-light" type="submit">
              <i class="bi bi-plus-lg me-2"></i>Buat Laporan (DRAFT)
            </button>
          </div>
        </div>
      </form>

      <div class="small opacity-75 mt-2">Data diambil dari kuitansi yang terbit pada periode tersebut.</div>
    </div>
  </div>

  <div class="card shadow-soft">
    <div class="card-body">
      <div class="table-responsive">
        <table class="table align-middle mb-0">
          <thead>
            <tr>
              <th>No Laporan</th>
              <th>Periode</th>
              <th>Status</th>
              <th>Total (Uang)</th>
              <th>Total (Beras)</th>
              <th></th>
            </tr>
          </thead>
          <tbody>
            <?php if (empty($rows)): ?>
              <tr><td colspan="6" class="text-center opacity-75 py-4">Belum ada laporan.</td></tr>
            <?php else: ?>
              <?php foreach($rows as $r): ?>
                <tr>
                  <td class="fw-semibold"><?php echo html_escape($r->report_no); ?></td>
                  <td><?php echo (int)$r->year; ?>-<?php echo str_pad((string)$r->month,2,'0',STR_PAD_LEFT); ?></td>
                  <td><span class="badge text-bg-secondary"><?php echo html_escape($r->status); ?></span></td>
                  <td>Rp <?php echo number_format((float)$r->total_money,0,',','.'); ?></td>
                  <td><?php echo (float)$r->total_rice_kg; ?> kg</td>
                  <td class="text-end">
                    <a class="btn btn-soft btn-sm" href="<?php echo site_url('branch/reports/'.$r->id); ?>">
                      Detail <i class="bi bi-arrow-right ms-1"></i>
                    </a>
                  </td>
                </tr>
              <?php endforeach; ?>
            <?php endif; ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>
</div>
