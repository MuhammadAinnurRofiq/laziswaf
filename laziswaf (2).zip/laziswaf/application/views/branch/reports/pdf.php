<!doctype html>
<html>
<head>
  <meta charset="utf-8">
  <style>
    body { font-family: DejaVu Sans, sans-serif; font-size: 10px; }
    .title { font-size: 14px; font-weight: bold; }
    .muted { color: #666; }
    .box { border: 1px solid #ddd; padding: 8px; margin-top: 8px; }
    .row { width: 100%; }
    .col { display: inline-block; vertical-align: top; width: 49%; }
    table { width: 100%; border-collapse: collapse; margin-top: 10px; }
    th, td { border: 1px solid #ddd; padding: 5px; }
    th { background: #f4f4f4; text-align: left; }
    .right { text-align: right; }
    .center { text-align: center; }
    .small { font-size: 9px; }
  </style>
</head>
<body>

  <div class="title">Laporan Cabang</div>
  <div class="muted">
    No: <b><?php echo html_escape($hdr->report_no); ?></b><br>
    Cabang: <b><?php echo html_escape($hdr->branch_name); ?></b><br>
    Periode: <b><?php echo (int)$hdr->year; ?>-<?php echo str_pad((string)$hdr->month,2,'0',STR_PAD_LEFT); ?></b>
    (<?php echo html_escape($hdr->start_date); ?> s/d <?php echo html_escape($hdr->end_date); ?>)<br>
    Status: <b><?php echo html_escape($hdr->status); ?></b><br>
    <?php if (!empty($hdr->reviewed_by_name)): ?>
      <?php $lbl = ($hdr->status === 'APPROVED') ? 'Disetujui oleh' : 'Reviewer'; ?>
      <?php echo html_escape($lbl); ?>: <b><?php echo html_escape($hdr->reviewed_by_name); ?></b>
      <?php if (!empty($hdr->reviewed_at)): ?>(<?php echo html_escape($hdr->reviewed_at); ?>)<?php endif; ?><br>
    <?php endif; ?>
    Dicetak: <?php echo date('Y-m-d H:i:s'); ?>
  </div>

  <!-- Ringkasan Split -->
  <div class="box">
    <div class="row">
      <div class="col">
        <div><b>Ringkasan Pemasukan (Uang)</b></div>
        <table>
          <tr>
            <td>Total Pemasukan</td>
            <td class="right"><b>Rp <?php echo number_format((float)$hdr->total_money,0,',','.'); ?></b></td>
          </tr>
          <tr>
            <td>Porsi Cabang (50%)</td>
            <td class="right">Rp <?php echo number_format((float)($hdr->branch_share_money ?? 0),0,',','.'); ?></td>
          </tr>
          <tr>
            <td class="small">- Hak Amil Cabang (12,5% dari porsi cabang)</td>
            <td class="right small">Rp <?php echo number_format((float)($hdr->branch_amil_money ?? 0),0,',','.'); ?></td>
          </tr>
          <tr>
            <td class="small">- Distribusi/Perbaikan Cabang</td>
            <td class="right small">Rp <?php echo number_format((float)($hdr->branch_dist_money ?? 0),0,',','.'); ?></td>
          </tr>
          <tr>
            <td>Porsi Pusat (50%)</td>
            <td class="right">Rp <?php echo number_format((float)($hdr->center_share_money ?? 0),0,',','.'); ?></td>
          </tr>
          <tr>
            <td class="small">Keterangan</td>
            <td class="small">Porsi pusat digunakan <b>full untuk penyaluran</b>.</td>
          </tr>
        </table>
      </div>

      <div class="col">
        <div><b>Ringkasan Pemasukan (Beras)</b></div>
        <table>
          <tr>
            <td>Total Beras</td>
            <td class="right"><b><?php echo (float)$hdr->total_rice_kg; ?> kg</b></td>
          </tr>
          <tr>
            <td>Porsi Cabang (50%)</td>
            <td class="right"><?php echo (float)($hdr->branch_share_rice_kg ?? 0); ?> kg</td>
          </tr>
          <tr>
            <td class="small">- Hak Amil Cabang (12,5% dari porsi cabang)</td>
            <td class="right small"><?php echo (float)($hdr->branch_amil_rice_kg ?? 0); ?> kg</td>
          </tr>
          <tr>
            <td class="small">- Distribusi/Perbaikan Cabang</td>
            <td class="right small"><?php echo (float)($hdr->branch_dist_rice_kg ?? 0); ?> kg</td>
          </tr>
          <tr>
            <td>Porsi Pusat (50%)</td>
            <td class="right"><?php echo (float)($hdr->center_share_rice_kg ?? 0); ?> kg</td>
          </tr>
          <tr>
            <td class="small">Keterangan</td>
            <td class="small">Porsi pusat digunakan <b>full untuk penyaluran</b>.</td>
          </tr>
        </table>
      </div>
    </div>
  </div>

  <!-- Tabel Detail dengan kolom split -->
  <table>
    <thead>
      <tr>
        <th style="width:28px;">No</th>
        <th style="width:140px;">Submission</th>
        <th style="width:140px;">Kuitansi</th>
        <th>Nama</th>
        <th style="width:70px;">Jenis</th>
        <th class="right" style="width:90px;">Uang</th>
        <th class="right" style="width:95px;">Uang Cabang</th>
        <th class="right" style="width:95px;">Uang Pusat</th>
        <th class="right" style="width:70px;">Beras</th>
        <th class="right" style="width:85px;">Beras Cabang</th>
        <th class="right" style="width:85px;">Beras Pusat</th>
      </tr>
    </thead>
    <tbody>
      <?php $i=1; foreach($lines as $l): ?>
      <tr>
        <td class="center"><?php echo $i++; ?></td>
        <td><?php echo html_escape($l->submission_no); ?></td>
        <td><?php echo html_escape($l->receipt_no); ?></td>
        <td><?php echo html_escape($l->applicant_name); ?></td>
        <td><?php echo html_escape($l->zis_type_code); ?></td>

        <td class="right">Rp <?php echo number_format((float)$l->money_amount,0,',','.'); ?></td>
        <td class="right">Rp <?php echo number_format((float)($l->branch_share_money ?? 0),0,',','.'); ?></td>
        <td class="right">Rp <?php echo number_format((float)($l->center_share_money ?? 0),0,',','.'); ?></td>

        <td class="right"><?php echo (float)$l->rice_kg; ?> kg</td>
        <td class="right"><?php echo (float)($l->branch_share_rice_kg ?? 0); ?> kg</td>
        <td class="right"><?php echo (float)($l->center_share_rice_kg ?? 0); ?> kg</td>
      </tr>
      <?php endforeach; ?>

      <tr>
        <th colspan="5" class="right">TOTAL</th>
        <th class="right">Rp <?php echo number_format((float)$hdr->total_money,0,',','.'); ?></th>
        <th class="right">Rp <?php echo number_format((float)($hdr->branch_share_money ?? 0),0,',','.'); ?></th>
        <th class="right">Rp <?php echo number_format((float)($hdr->center_share_money ?? 0),0,',','.'); ?></th>
        <th class="right"><?php echo (float)$hdr->total_rice_kg; ?> kg</th>
        <th class="right"><?php echo (float)($hdr->branch_share_rice_kg ?? 0); ?> kg</th>
        <th class="right"><?php echo (float)($hdr->center_share_rice_kg ?? 0); ?> kg</th>
      </tr>
    </tbody>
  </table>

</body>
</html>
