<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>

<div class="container-fluid">
  <div class="page-hero mb-3">
    <div>
      <h3 class="mb-1"><?php echo html_escape($hdr->report_no); ?></h3>
      <div class="opacity-75">
        <?php echo (int)$hdr->year; ?>-<?php echo str_pad((string)$hdr->month,2,'0',STR_PAD_LEFT); ?>
        • <?php echo html_escape($hdr->branch_name); ?>
        • <span class="badge text-bg-secondary"><?php echo html_escape($hdr->status); ?></span>
        <?php if (!empty($hdr->reviewed_by_name)):
          $rvAt = !empty($hdr->reviewed_at) ? (' pada '.(string)$hdr->reviewed_at) : '';
          $lbl = ($hdr->status === 'APPROVED') ? 'Disetujui oleh' : 'Reviewer';
        ?>
          <span class="ms-2 small"><?php echo html_escape($lbl); ?>: <b><?php echo html_escape($hdr->reviewed_by_name); ?></b><?php echo html_escape($rvAt); ?></span>
        <?php endif; ?>
      </div>
    </div>
    <div class="d-flex gap-2 flex-wrap">
      <a class="btn btn-soft" href="<?php echo site_url('branch/reports'); ?>">
        <i class="bi bi-arrow-left me-2"></i>Kembali
      </a>

      <!-- EXPORT PDF -->
      <a class="btn btn-soft" href="<?php echo site_url('branch/reports/export/pdf/'.$hdr->id); ?>">
        <i class="bi bi-filetype-pdf me-2"></i>Export PDF
      </a>

      <!-- REFRESH REPORT (PASTI KE branch/reports/refresh/{id}) -->
      <form method="post" action="<?php echo site_url('branch/reports/refresh/'.$hdr->id); ?>" style="display:inline-block">
        <button class="btn btn-soft" onclick="return confirm('Perbaharui laporan?');">
          <i class="bi bi-arrow-repeat me-2"></i>Perbaharui Laporan
        </button>
      </form>

      <?php if ($hdr->status === 'DRAFT'): ?>
        <form method="post" action="<?php echo site_url('branch/reports/send/'.$hdr->id); ?>">
          <button class="btn btn-light">
            <i class="bi bi-send me-2"></i>Kirim ke Pusat
          </button>
        </form>
      <?php endif; ?>
    </div>
  </div>

  <?php if (!empty($ok)): ?><div class="alert alert-success"><?php echo $ok; ?></div><?php endif; ?>
  <?php if (!empty($err)): ?><div class="alert alert-danger"><?php echo $err; ?></div><?php endif; ?>

  <div class="row g-3">
    <div class="col-lg-4">
      <div class="card shadow-soft">
        <div class="card-body">

          <div class="opacity-75">Total Pemasukan (Uang)</div>
          <div class="fw-semibold fs-4">Rp <?php echo number_format((float)$hdr->total_money,0,',','.'); ?></div>

          <div class="opacity-75 mt-2">Total Pemasukan (Beras)</div>
          <div class="fw-semibold fs-4"><?php echo (float)$hdr->total_rice_kg; ?> kg</div>

          <hr class="opacity-25">

          <div class="fw-semibold mb-1">Pembagian 50% / 50%</div>

          <div class="d-flex justify-content-between">
            <span class="opacity-75">Porsi Cabang (50%)</span>
            <span class="fw-semibold">Rp <?php echo number_format((float)$hdr->branch_share_money,0,',','.'); ?></span>
          </div>
          <div class="small opacity-75">
            Pengelolaan cabang: <b>Hak Amil</b> + <b>Distribusi/Perbaikan Cabang (Masjid/Mushola/Lembaga)</b>
          </div>
          <div class="d-flex justify-content-between mt-1">
            <span class="opacity-75">- Hak Amil Cabang</span>
            <span>Rp <?php echo number_format((float)$hdr->branch_amil_money,0,',','.'); ?></span>
          </div>
          <div class="d-flex justify-content-between">
            <span class="opacity-75">- Distribusi Cabang</span>
            <span>Rp <?php echo number_format((float)$hdr->branch_dist_money,0,',','.'); ?></span>
          </div>

          <hr class="opacity-25">

          <div class="d-flex justify-content-between">
            <span class="opacity-75">Disetor ke Pusat (50%)</span>
            <span class="fw-semibold">Rp <?php echo number_format((float)$hdr->center_share_money,0,',','.'); ?></span>
          </div>
          <div class="small opacity-75">Porsi pusat digunakan <b>full untuk penyaluran</b>.</div>

          <hr class="opacity-25">

          <div class="d-flex justify-content-between">
            <span class="opacity-75">Porsi Cabang (Beras)</span>
            <span class="fw-semibold"><?php echo (float)$hdr->branch_share_rice_kg; ?> kg</span>
          </div>
          <div class="d-flex justify-content-between">
            <span class="opacity-75">Disetor ke Pusat (Beras)</span>
            <span class="fw-semibold"><?php echo (float)$hdr->center_share_rice_kg; ?> kg</span>
          </div>

          <?php if (!empty($hdr->review_note)): ?>
            <hr class="opacity-25">
            <div class="fw-semibold">Catatan Pusat</div>
            <div class="opacity-75"><?php echo nl2br(html_escape($hdr->review_note)); ?></div>
          <?php endif; ?>

        </div>
      </div>
    </div>

    <div class="col-lg-8">
      <div class="card shadow-soft">
        <div class="card-body">
          <div class="fw-semibold mb-2">Detail Item</div>
          <div class="table-responsive">
            <table class="table align-middle mb-0">
              <thead>
                <tr>
                  <th>Submission</th>
                  <th>Kuitansi</th>
                  <th>Nama</th>
                  <th>Jenis</th>
                  <th class="text-end">Uang</th>
                  <th class="text-end">Uang Cabang (50%)</th>
                  <th class="text-end">Uang Pusat (50%)</th>
                  <th class="text-end">Beras</th>
                  <th class="text-end">Beras Cabang (50%)</th>
                  <th class="text-end">Beras Pusat (50%)</th>
                </tr>
              </thead>
              <tbody>
                <?php foreach($lines as $l): ?>
                  <tr>
                    <td><?php echo html_escape($l->submission_no); ?></td>
                    <td><?php echo html_escape($l->receipt_no); ?></td>
                    <td><?php echo html_escape($l->applicant_name); ?></td>
                    <td><?php echo html_escape($l->zis_type_code); ?></td>

                    <td class="text-end">Rp <?php echo number_format((float)$l->money_amount,0,',','.'); ?></td>
                    <td class="text-end">Rp <?php echo number_format((float)($l->branch_share_money ?? 0),0,',','.'); ?></td>
                    <td class="text-end">Rp <?php echo number_format((float)($l->center_share_money ?? 0),0,',','.'); ?></td>

                    <td class="text-end"><?php echo (float)$l->rice_kg; ?> kg</td>
                    <td class="text-end"><?php echo (float)($l->branch_share_rice_kg ?? 0); ?> kg</td>
                    <td class="text-end"><?php echo (float)($l->center_share_rice_kg ?? 0); ?> kg</td>
                  </tr>
                <?php endforeach; ?>
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>

  </div>
</div>
