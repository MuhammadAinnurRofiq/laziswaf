<?php
$nom = $r->amount_money ?: $r->fitrah_total_money;
$kg  = $r->fitrah_total_kg;

$shareText = "Kuitansi ".$r->receipt_no." - ".$public_link;
$waLink = "https://wa.me/?text=".rawurlencode($shareText);

// Tahun cetak
$printYear = date('Y');
if (!empty($r->issued_at)) {
  $ts = strtotime((string)$r->issued_at);
  if ($ts) $printYear = date('Y', $ts);
}
?>

<div class="container-fluid">
  <div class="page-hero mb-3">
    <div>
      <h3 class="mb-1">Kuitansi Cabang</h3>
      <div class="opacity-75"><?php echo html_escape($r->receipt_no); ?> • <?php echo html_escape($r->zis_type_code); ?></div>
    </div>
    <div class="d-flex gap-2 flex-wrap">
      <a class="btn btn-soft" href="<?php echo site_url('branch/receipts'); ?>">
        <i class="bi bi-arrow-left me-2"></i>Kembali
      </a>
      <a class="btn btn-soft" target="_blank" href="<?php echo $public_link; ?>">
        <i class="bi bi-box-arrow-up-right me-2"></i>Link Publik
      </a>
      <a class="btn btn-soft" target="_blank" href="<?php echo $waLink; ?>">
        <i class="bi bi-whatsapp me-2"></i>Share WA
      </a>
      <button class="btn btn-light" onclick="window.print()">
        <i class="bi bi-printer me-2"></i>Print
      </button>
    </div>
  </div>

  <div class="card shadow-soft receipt-paper">
    <div class="card-body">

      <?php $this->load->view('partials/print_header', array(
        'print_title' => 'Kwitansi Pembayaran',
        'print_year'  => $printYear,
      )); ?>

      <div class="d-flex justify-content-between flex-wrap gap-3">
        <div>
          <div class="small opacity-75">Cabang</div>
          <div class="fw-semibold"><?php echo html_escape($r->branch_name ?? '-'); ?></div>
        </div>
        <div class="text-end">
          <div class="small opacity-75">No / Tanggal</div>
          <div class="fw-semibold"><?php echo html_escape($r->receipt_no); ?></div>
          <div class="small opacity-75"><?php echo html_escape($r->issued_at); ?></div>
        </div>
      </div>

      <hr class="opacity-25">

      <div class="row g-3">
        <div class="col-md-6">
          <div class="small opacity-75">Nama</div>
          <div class="fw-semibold"><?php echo html_escape($r->applicant_name); ?></div>
        </div>
        <div class="col-md-6">
          <div class="small opacity-75">Nomor Pengajuan</div>
          <div class="fw-semibold"><?php echo html_escape($r->submission_no); ?></div>
        </div>

        <div class="col-md-6">
          <div class="small opacity-75">Jenis</div>
          <div class="fw-semibold"><?php echo html_escape($r->zis_type_code); ?></div>
        </div>
        <div class="col-md-6">
          <div class="small opacity-75">Nominal</div>
          <div class="fw-semibold">
            <?php echo $nom ? 'Rp '.number_format((float)$nom,0,',','.') : '-'; ?>
            <?php if (!empty($kg)): ?>
              <span class="ms-2 badge text-bg-secondary"><?php echo (float)$kg; ?> kg</span>
            <?php endif; ?>
          </div>
        </div>
      </div>

      <?php if (!empty($people)): ?>
        <hr class="opacity-25">
        <div class="fw-semibold mb-2">Tanggungan</div>
        <ul class="mb-0 opacity-75">
          <?php foreach($people as $p): ?>
            <li><?php echo html_escape($p->person_name); ?></li>
          <?php endforeach; ?>
        </ul>
      <?php endif; ?>

      <hr class="opacity-25">

      <div class="small opacity-75">
        Link publik: <span class="fw-semibold"><?php echo html_escape($public_link); ?></span>
      </div>
    </div>
  </div>
</div>
