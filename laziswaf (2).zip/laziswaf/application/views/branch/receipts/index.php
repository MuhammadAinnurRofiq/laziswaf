<div class="container-fluid">
  <div class="page-hero mb-3">
    <div>
      <h3 class="mb-1"><?php echo html_escape($title); ?></h3>
      <div class="opacity-75">Kuitansi yang diterbitkan oleh cabang Anda.</div>
    </div>
  </div>

  <div class="card shadow-soft">
    <div class="card-body">
      <div class="table-responsive">
        <table class="table align-middle mb-0">
          <thead>
            <tr>
              <th>No Kuitansi</th>
              <th>Submission</th>
              <th>Nama</th>
              <th>Jenis</th>
              <th>Tanggal</th>
              <th></th>
            </tr>
          </thead>
          <tbody>
            <?php if (empty($rows)): ?>
              <tr><td colspan="6" class="text-center opacity-75 py-4">Belum ada kuitansi.</td></tr>
            <?php else: ?>
              <?php foreach($rows as $r): ?>
                <tr>
                  <td class="fw-semibold"><?php echo html_escape($r->receipt_no); ?></td>
                  <td><?php echo html_escape($r->submission_no); ?></td>
                  <td><?php echo html_escape($r->applicant_name); ?></td>
                  <td><?php echo html_escape($r->zis_type_code); ?></td>
                  <td class="opacity-75"><?php echo html_escape($r->issued_at); ?></td>
                  <td class="text-end">
                    <a class="btn btn-soft btn-sm" target="_blank" href="<?php echo site_url('public/receipt/'.$r->public_token); ?>">
                      Link Publik
                    </a>
                  </td>
                </tr>
              <?php endforeach; ?>
            <?php endif; ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>
</div>
