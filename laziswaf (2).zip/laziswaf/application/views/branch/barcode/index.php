<div class="d-flex align-items-center justify-content-between mb-3 no-print">
  <div>
    <h3 class="mb-0">QR Cabang</h3>
    <div class="text-muted">
      Scan QR ini untuk memilih cabang otomatis pada pengajuan publik (user umum).
    </div>
  </div>
  <div class="d-flex gap-2">
    <button class="btn btn-outline-primary" onclick="window.print()">Cetak / Simpan PDF</button>
    <a class="btn btn-outline-secondary" href="<?= site_url('branch') ?>">Kembali</a>
  </div>
</div>

<style>
@media print {
  .no-print { display:none !important; }
  .card-print { box-shadow:none !important; border:1px solid #ddd; }
}
.card-print {
  max-width: 520px;
  margin: 0 auto;
}
.qr-wrap { display:flex; justify-content:center; }
</style>

<div class="card shadow-soft card-print">
  <div class="card-body">
    <?php $this->load->view('partials/print_header', array(
      'print_title' => 'Kartu QR Cabang',
      'print_year'  => date('Y'),
    )); ?>

    <div class="text-center">
      <div class="mt-2 fw-bold"><?= html_escape($branch->branch_name) ?></div>
      <div class="small text-muted">Scan untuk pengajuan publik</div>
    </div>

    <hr class="opacity-25">

    <div class="qr-wrap">
      <div id="qrcode"></div>
    </div>

    <div class="small text-muted mt-3">
      Link scan:
      <div class="fw-semibold"><?= html_escape($scan_url) ?></div>
    </div>

    <div class="small text-muted mt-2">
      Cara pakai:
      <ol class="mb-0">
        <li>User umum scan QR</li>
        <li>Otomatis “pilih cabang” tersimpan</li>
        <li>User lanjut isi form pengajuan (fitrah/mal/fidyah/infaq)</li>
      </ol>
    </div>
  </div>
</div>

<!-- QRCode generator (sama seperti kartu cabang pusat) -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/qrcodejs/1.0.0/qrcode.min.js"></script>
<script>
  const scanUrl = <?= json_encode($scan_url) ?>;
  new QRCode(document.getElementById("qrcode"), { text: scanUrl, width: 220, height: 220 });
</script>
