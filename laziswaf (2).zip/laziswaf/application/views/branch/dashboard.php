<?php
$s = $summary ?? null;
$by = $s['by_type'] ?? array();
$tot = $s['totals'] ?? array('money'=>0,'rice_kg'=>0,'jiwa'=>0);
$sp  = $s['split']  ?? array();

function rp($n){ return 'Rp '.number_format((float)$n, 0, ',', '.'); }
function kg($n){ return number_format((float)$n, 2, ',', '.').' kg'; }

$label_period = 'Bulan ini';
if (($range ?? 'month') === 'all') $label_period = 'Semua waktu';
else {
  $label_period = sprintf('%02d-%04d', (int)($month ?? date('n')), (int)($year ?? date('Y')));
}
?>

<div class="container-fluid">
  <div class="page-hero mb-3">
    <div>
      <h3 class="mb-1"><?php echo html_escape($title); ?></h3>
      <div class="opacity-75">Ringkasan pemasukan cabang (<?php echo html_escape($label_period); ?>).</div>
    </div>
    <div class="d-flex gap-2">
      <a class="btn btn-light" href="<?php echo site_url('branch/submissions/inbox'); ?>">
        <i class="bi bi-inbox me-2"></i>Inbox (<?php echo (int)$inbox_count; ?>)
      </a>
    </div>
  </div>

  <!-- Filter -->
  <div class="card shadow-soft mb-3">
    <div class="card-body">
      <form class="row g-2" method="get">
        <div class="col-auto">
          <select class="form-select" name="range">
            <option value="month" <?php echo (($range ?? 'month')==='month'?'selected':''); ?>>Per Bulan</option>
            <option value="all" <?php echo (($range ?? '')==='all'?'selected':''); ?>>Semua Waktu</option>
          </select>
        </div>
        <div class="col-auto">
          <input class="form-control" type="number" name="month" min="1" max="12" value="<?php echo (int)$month; ?>" <?php echo (($range ?? 'month')==='all'?'disabled':''); ?>>
        </div>
        <div class="col-auto">
          <input class="form-control" type="number" name="year" min="2020" max="2099" value="<?php echo (int)$year; ?>" <?php echo (($range ?? 'month')==='all'?'disabled':''); ?>>
        </div>
        <div class="col-auto">
          <button class="btn btn-light"><i class="bi bi-funnel me-2"></i>Terapkan</button>
        </div>
      </form>
    </div>
  </div>

  <div class="row g-3">
    <!-- Inbox -->
    <div class="col-md-3">
      <div class="card shadow-soft card-anim h-100">
        <div class="card-body">
          <div class="text-muted">Pengajuan Masuk</div>
          <div class="display-6 fw-bold"><?php echo (int)$inbox_count; ?></div>
          <div class="opacity-75 small">SUBMITTED / NEED_FIX</div>
        </div>
      </div>
    </div>

    <!-- Total Uang -->
    <div class="col-md-3">
      <div class="card shadow-soft card-anim h-100">
        <div class="card-body">
          <div class="text-muted">Total Pemasukan (Uang)</div>
          <div class="h4 fw-bold mb-0"><?php echo rp($tot['money'] ?? 0); ?></div>
          <div class="opacity-75 small">Akumulasi transaksi uang</div>
        </div>
      </div>
    </div>

    <!-- Total Beras -->
    <div class="col-md-3">
      <div class="card shadow-soft card-anim h-100">
        <div class="card-body">
          <div class="text-muted">Total Pemasukan (Beras)</div>
          <div class="h4 fw-bold mb-0"><?php echo kg($tot['rice_kg'] ?? 0); ?></div>
          <div class="opacity-75 small">Akumulasi beras (kg)</div>
        </div>
      </div>
    </div>

    <!-- Total Jiwa -->
    <div class="col-md-3">
      <div class="card shadow-soft card-anim h-100">
        <div class="card-body">
          <div class="text-muted">Total Jiwa (akumulasi)</div>
          <div class="h4 fw-bold mb-0"><?php echo number_format((int)($tot['jiwa'] ?? 0), 0, ',', '.'); ?> jiwa</div>
          <div class="opacity-75 small">Diambil dari kolom jiwa_count</div>
        </div>
      </div>
    </div>
  </div>

  <!-- Per kategori -->
  <div class="row g-3 mt-1">
    <?php
      $cats = array(
        'FITRAH' => 'Zakat Fitrah',
        'MAL'    => 'Zakat Mal',
        'FIDYAH' => 'Fidyah',
        'INFAQ'  => 'Infak',
      );
      foreach ($cats as $k => $label):
        $v = $by[$k] ?? array('trx_count'=>0,'jiwa_sum'=>0,'money_sum'=>0,'rice_sum'=>0);
    ?>
    <div class="col-md-6 col-lg-3">
      <div class="card shadow-soft h-100">
        <div class="card-body">
          <div class="fw-semibold"><?php echo html_escape($label); ?></div>
          <div class="small opacity-75 mb-2"><?php echo (int)$v['trx_count']; ?> transaksi • <?php echo (int)$v['jiwa_sum']; ?> jiwa</div>

          <div class="d-flex justify-content-between">
            <span class="text-muted">Uang</span>
            <span class="fw-semibold"><?php echo rp($v['money_sum']); ?></span>
          </div>

          <?php if ($k === 'FITRAH'): ?>
          <div class="d-flex justify-content-between">
            <span class="text-muted">Beras</span>
            <span class="fw-semibold"><?php echo kg($v['rice_sum']); ?></span>
          </div>
          <?php endif; ?>
        </div>
      </div>
    </div>
    <?php endforeach; ?>
  </div>

  <!-- Pembagian 50/50 -->
  <div class="row g-3 mt-1">
    <div class="col-lg-6">
      <div class="card shadow-soft h-100">
        <div class="card-body">
          <div class="fw-semibold mb-2">Pembagian Pemasukan (Uang)</div>

          <div class="d-flex justify-content-between">
            <span class="text-muted">Total Uang</span>
            <span class="fw-bold"><?php echo rp(($sp['branch_share_money'] ?? 0) + ($sp['center_share_money'] ?? 0)); ?></span>
          </div>
          <hr class="opacity-25">

          <div class="d-flex justify-content-between">
            <span>Porsi Cabang (50%)</span>
            <span class="fw-semibold"><?php echo rp($sp['branch_share_money'] ?? 0); ?></span>
          </div>
          <div class="small opacity-75">
            Pengelolaan porsi cabang: <b>Hak Amil 12,5%</b> dari porsi cabang, sisanya untuk <b>penyaluran/perbaikan cabang/masjid/mushola/lembaga pendidikan</b>.
          </div>
          <div class="mt-2">
            <div class="d-flex justify-content-between">
              <span class="text-muted">Hak Amil Cabang (12,5% porsi cabang)</span>
              <span><?php echo rp($sp['branch_amil_money'] ?? 0); ?></span>
            </div>
            <div class="d-flex justify-content-between">
              <span class="text-muted">Distribusi Cabang</span>
              <span><?php echo rp($sp['branch_dist_money'] ?? 0); ?></span>
            </div>
          </div>

          <hr class="opacity-25">
          <div class="d-flex justify-content-between">
            <span>Porsi Pusat (50%)</span>
            <span class="fw-semibold"><?php echo rp($sp['center_share_money'] ?? 0); ?></span>
          </div>
          <div class="small opacity-75">
            Porsi pusat digunakan <b>full untuk penyaluran</b>.
          </div>
        </div>
      </div>
    </div>

    <div class="col-lg-6">
      <div class="card shadow-soft h-100">
        <div class="card-body">
          <div class="fw-semibold mb-2">Pembagian Pemasukan (Beras)</div>

          <div class="d-flex justify-content-between">
            <span class="text-muted">Total Beras</span>
            <span class="fw-bold"><?php echo kg(($sp['branch_share_rice_kg'] ?? 0) + ($sp['center_share_rice_kg'] ?? 0)); ?></span>
          </div>
          <hr class="opacity-25">

          <div class="d-flex justify-content-between">
            <span>Porsi Cabang (50%)</span>
            <span class="fw-semibold"><?php echo kg($sp['branch_share_rice_kg'] ?? 0); ?></span>
          </div>
          <div class="small opacity-75">
            Pengelolaan porsi cabang: <b>Hak Amil 12,5%</b> dari porsi cabang, sisanya untuk <b>penyaluran/perbaikan cabang/masjid/mushola/lembaga pendidikan</b>.
          </div>
          <div class="mt-2">
            <div class="d-flex justify-content-between">
              <span class="text-muted">Hak Amil Cabang (12,5% porsi cabang)</span>
              <span><?php echo kg($sp['branch_amil_rice_kg'] ?? 0); ?></span>
            </div>
            <div class="d-flex justify-content-between">
              <span class="text-muted">Distribusi Cabang</span>
              <span><?php echo kg($sp['branch_dist_rice_kg'] ?? 0); ?></span>
            </div>
          </div>

          <hr class="opacity-25">
          <div class="d-flex justify-content-between">
            <span>Porsi Pusat (50%)</span>
            <span class="fw-semibold"><?php echo kg($sp['center_share_rice_kg'] ?? 0); ?></span>
          </div>
          <div class="small opacity-75">
            Porsi pusat digunakan <b>full untuk penyaluran</b>.
          </div>
        </div>
      </div>
    </div>
  </div>

</div>
