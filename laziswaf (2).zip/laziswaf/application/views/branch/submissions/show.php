<div class="container-fluid">
  <div class="page-hero mb-3">
    <div>
      <h3 class="mb-1">Detail Pengajuan</h3>
      <div class="opacity-75"><?php echo html_escape($sub->submission_no); ?> • <?php echo html_escape($sub->zis_type_code); ?> • <?php echo html_escape($sub->status); ?></div>
    </div>
    <a class="btn btn-soft" href="<?php echo site_url('branch/submissions/inbox'); ?>">
      <i class="bi bi-arrow-left me-2"></i>Kembali
    </a>
  </div>

  <?php if (!empty($flash)): ?>
    <div class="alert alert-info"><?php echo html_escape($flash); ?></div>
  <?php endif; ?>

  <div class="row g-3">
    <div class="col-lg-8">
      <div class="card shadow-soft">
        <div class="card-body">
          <div class="row g-2">
            <div class="col-md-6">
              <div class="opacity-75">Nama</div>
              <div class="fw-semibold"><?php echo html_escape($sub->applicant_name); ?></div>
            </div>
            <div class="col-md-6">
              <div class="opacity-75">WhatsApp</div>
              <div class="fw-semibold"><?php echo html_escape($sub->whatsapp); ?></div>
            </div>
            <div class="col-md-6 mt-3">
              <div class="opacity-75">Tanggal</div>
              <div class="fw-semibold"><?php echo html_escape($sub->submitted_at); ?></div>
            </div>
            <div class="col-md-6 mt-3">
              <div class="opacity-75">Nominal</div>
              <div class="fw-semibold">
                <?php
                  $nom = $sub->amount_money ?: $sub->fitrah_total_money;
                  echo $nom ? 'Rp '.number_format((float)$nom,0,',','.') : '-';
                ?>
                <?php if (!empty($sub->fitrah_total_kg)): ?>
                  <span class="ms-2 badge text-bg-secondary"><?php echo (float)$sub->fitrah_total_kg; ?> kg</span>
                <?php endif; ?>
              </div>
            </div>
          </div>

          <?php if (!empty($people)): ?>
            <hr class="opacity-25">
            <div class="fw-semibold mb-2">Tanggungan</div>
            <ul class="mb-0 opacity-75">
              <?php foreach($people as $p): ?>
                <li><?php echo html_escape($p->person_name); ?></li>
              <?php endforeach; ?>
            </ul>
          <?php endif; ?>

          <?php if ($receipt): ?>
            <hr class="opacity-25">
            <div class="alert alert-success mb-0">
              Kuitansi sudah terbit:
              <strong><?php echo html_escape($receipt->receipt_no); ?></strong>
              • Token:
              <a class="text-decoration-none fw-semibold" target="_blank" href="<?php echo site_url('public/receipt/'.$receipt->public_token); ?>">
                buka kuitansi publik
              </a>
            </div>
          <?php endif; ?>
        </div>
      </div>
    </div>

    <div class="col-lg-4">
      <div class="card shadow-soft">
        <div class="card-body">
          <div class="fw-semibold mb-2">Aksi</div>

          <?php if ($sub->status !== 'BRANCH_APPROVED'): ?>
            <form method="post" action="<?php echo site_url('branch/submissions/approve/'.$sub->id); ?>" class="mb-2">
              <button class="btn btn-light w-100">
                <i class="bi bi-check2-circle me-2"></i>Approve + Terbitkan Kuitansi
              </button>
            </form>

            <form method="post" action="<?php echo site_url('branch/submissions/needfix/'.$sub->id); ?>" class="mb-2">
              <input class="form-control mb-2" name="note" placeholder="Catatan perbaikan (opsional)">
              <button class="btn btn-soft w-100">
                <i class="bi bi-exclamation-circle me-2"></i>Need Fix
              </button>
            </form>

            <form method="post" action="<?php echo site_url('branch/submissions/reject/'.$sub->id); ?>">
              <input class="form-control mb-2" name="note" placeholder="Alasan reject (opsional)">
              <button class="btn btn-danger w-100">
                <i class="bi bi-x-circle me-2"></i>Reject
              </button>
            </form>
          <?php else: ?>
            <div class="alert alert-success mb-0">Pengajuan sudah di-approve.</div>
          <?php endif; ?>
        </div>
      </div>
    </div>

  </div>
</div>
