<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>

<div class="container-fluid">
  <div class="page-hero mb-3">
    <div>
      <h3 class="mb-1"><?php echo html_escape($title); ?></h3>
      <div class="opacity-75">
        Halaman khusus cabang untuk mengelola pengajuan <b>PUBLIC</b> yang sudah lewat
        <?php echo (defined('SUBMISSION_EXPIRE_MINUTES') ? SUBMISSION_EXPIRE_MINUTES : 10); ?> menit dari jam submit.
      </div>
    </div>
    <div class="d-flex gap-2 flex-wrap">
      <a class="btn btn-soft" href="<?php echo site_url('branch/submissions'); ?>">
        <i class="bi bi-inbox me-2"></i>Ke Inbox
      </a>
      <a class="btn btn-light" href="<?php echo current_url(); ?>">
        <i class="bi bi-arrow-clockwise me-2"></i>Refresh
      </a>
    </div>
  </div>

  <?php if (!empty($msg)): ?>
    <div class="alert alert-info shadow-soft"><?php echo $msg; ?></div>
  <?php endif; ?>

  <div class="alert alert-warning shadow-soft">
    <div class="fw-semibold mb-1">Aturan yang diterapkan</div>
    <ul class="mb-0">
      <li>Pengajuan <b>SUBMITTED</b> yang lebih dari <b><?php echo (defined('SUBMISSION_EXPIRE_MINUTES') ? SUBMISSION_EXPIRE_MINUTES : 10); ?> menit</b> akan otomatis ditandai <b>EXPIRED</b> (tanpa cron).</li>
      <li>Tombol <b>EXPIRED</b> hanya tersedia untuk kandidat yang sudah melewati batas waktu.</li>
      <li>Tombol <b>Hapus</b> akan mengubah status menjadi <b>DELETED</b> sehingga saat user tracking akan muncul keterangan <b>data telah terhapus</b>.</li>
      <li>Rekomendasi: lakukan penghapusan fisik data lama (di server/DB) setelah <?php echo (defined('SUBMISSION_HARD_DELETE_AFTER_HOURS') ? SUBMISSION_HARD_DELETE_AFTER_HOURS : 24); ?> jam jika diperlukan.</li>
    </ul>
  </div>

  <div class="card shadow-soft">
    <div class="card-body">
      <div class="table-responsive">
        <table class="table align-middle mb-0">
          <thead>
            <tr class="text-nowrap">
              <th>No Pengajuan</th>
              <th>Jenis</th>
              <th>Nama</th>
              <th>WhatsApp</th>
              <th>Submit</th>
              <th>Status</th>
              <th style="width:200px;">Aksi</th>
            </tr>
          </thead>
          <tbody>
          <?php if (empty($rows)): ?>
            <tr><td colspan="7" class="text-center opacity-75 py-4">Tidak ada data expired.</td></tr>
          <?php else: ?>
            <?php foreach ($rows as $r): ?>
              <tr>
                <td class="fw-semibold"><?php echo html_escape($r->submission_no); ?></td>
                <td><?php echo html_escape($r->zis_type_code); ?></td>
                <td><?php echo html_escape($r->applicant_name); ?></td>
                <td><?php echo html_escape($r->whatsapp); ?></td>
                <td class="text-nowrap"><?php echo html_escape($r->submitted_at); ?></td>
                <td class="text-nowrap">
                  <?php if ($r->status === 'EXPIRED'): ?>
                    <span class="badge text-bg-danger">EXPIRED</span>
                  <?php elseif ($r->status === 'SUBMITTED'): ?>
                    <span class="badge text-bg-warning">SUBMITTED</span>
                  <?php else: ?>
                    <span class="badge text-bg-secondary"><?php echo html_escape($r->status); ?></span>
                  <?php endif; ?>
                </td>
                <td class="text-nowrap">
                  <div class="d-flex gap-2">
                    <?php if ($r->status === 'SUBMITTED'): ?>
                      <?php echo form_open(site_url('branch/submissions/do_expire/'.$r->id), array('style'=>'display:inline')); ?>
                        <button type="submit" class="btn btn-sm btn-warning"
                                onclick="return confirm('Tandai pengajuan ini menjadi EXPIRED?');">
                          <i class="bi bi-clock-history me-1"></i>Expired
                        </button>
                      <?php echo form_close(); ?>
                    <?php endif; ?>

                    <?php echo form_open(site_url('branch/submissions/do_delete/'.$r->id), array('style'=>'display:inline')); ?>
                      <button type="submit" class="btn btn-sm btn-outline-danger"
                              onclick="return confirm('Hapus pengajuan ini? Status akan menjadi DELETED dan user tracking akan melihat \'data telah terhapus\'.');">
                        <i class="bi bi-trash me-1"></i>Hapus
                      </button>
                    <?php echo form_close(); ?>
                  </div>
                </td>
              </tr>
            <?php endforeach; ?>
          <?php endif; ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>
</div>
