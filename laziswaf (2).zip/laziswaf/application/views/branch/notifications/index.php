<div class="d-flex align-items-center justify-content-between mb-3">
  <div>
    <h4 class="mb-0">Notifikasi</h4>
    <div class="text-muted small">Kelola notifikasi laporan dan aktivitas.</div>
  </div>
  <div class="d-flex gap-2">
    <a class="btn btn-soft" href="<?php echo site_url('branch/notifications?unread=1'); ?>">Unread</a>
    <a class="btn btn-soft" href="<?php echo site_url('branch/notifications'); ?>">Semua</a>
    <a class="btn btn-primary" href="<?php echo site_url('branch/notifications/read_all'); ?>">
      Tandai semua dibaca
    </a>
  </div>
</div>

<?php if (empty($rows)): ?>
  <div class="card card-soft p-4 text-muted">Belum ada notifikasi.</div>
<?php else: ?>
  <div class="card card-soft">
    <div class="card-body p-0">
      <?php foreach ($rows as $n): ?>
        <div class="p-3 border-bottom d-flex justify-content-between gap-3">
          <div>
            <div class="d-flex align-items-center gap-2">
              <div class="fw-semibold"><?php echo html_escape($n->title); ?></div>
              <?php if ((int)$n->is_read === 0): ?>
                <span class="badge bg-warning text-dark">baru</span>
              <?php endif; ?>
            </div>
            <?php if (!empty($n->body)): ?>
              <div class="text-muted small mt-1"><?php echo nl2br(html_escape($n->body)); ?></div>
            <?php endif; ?>
            <div class="text-muted small mt-2"><?php echo html_escape($n->created_at); ?></div>
          </div>

          <div class="text-end">
            <?php if (!empty($n->link_url)): ?>
              <a class="btn btn-soft btn-sm" href="<?php echo html_escape($n->link_url); ?>">Buka</a>
            <?php endif; ?>

            <?php if ((int)$n->is_read === 0): ?>
              <a class="btn btn-primary btn-sm"
                 href="<?php echo site_url('branch/notifications/read/'.$n->id.'?back='.urlencode(current_url().'?'.http_build_query($_GET))); ?>">
                Tandai dibaca
              </a>
            <?php endif; ?>
          </div>
        </div>
      <?php endforeach; ?>
    </div>
  </div>
<?php endif; ?>
