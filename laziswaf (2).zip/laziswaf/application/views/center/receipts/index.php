<?php
function qs_keep($filters, $extra = array()){
  $q = array_merge($filters, $extra);
  foreach ($q as $k=>$v) {
    if ($v === '' || $v === null) unset($q[$k]);
  }
  return http_build_query($q);
}
$total_pages = (int)ceil($total / max(1,$per_page));
if ($total_pages < 1) $total_pages = 1;

$export_url = site_url('dashboard/receipts/export/csv').'?'.qs_keep($filters);
?>

<div class="container-fluid">
  <div class="page-hero mb-3">
    <div>
      <h3 class="mb-1"><?php echo html_escape($title); ?></h3>
      <div class="opacity-75">Total hasil: <b><?php echo (int)$total; ?></b></div>
    </div>
    <div class="d-flex gap-2 flex-wrap">
      <a class="btn btn-soft" href="<?php echo $export_url; ?>">
        <i class="bi bi-download me-2"></i>Export CSV
      </a>
    </div>
  </div>

  <div class="card shadow-soft mb-3">
    <div class="card-body">
      <form method="get" action="<?php echo site_url('dashboard/receipts'); ?>">
        <div class="row g-3">

          <div class="col-md-2">
            <label class="form-label">Scope</label>
            <select class="form-select" name="scope">
              <?php foreach($scopes as $k=>$v): ?>
                <option value="<?php echo html_escape($k); ?>" <?php echo ((string)$filters['scope'] === (string)$k) ? 'selected' : ''; ?>>
                  <?php echo html_escape($v); ?>
                </option>
              <?php endforeach; ?>
            </select>
          </div>

          <div class="col-md-3">
            <label class="form-label">Cabang</label>
            <select class="form-select" name="branch_id">
              <option value="">Semua</option>
              <?php foreach($branches as $b): ?>
                <option value="<?php echo (int)$b->id; ?>" <?php echo ((string)$filters['branch_id'] === (string)$b->id) ? 'selected' : ''; ?>>
                  <?php echo html_escape($b->branch_name); ?>
                </option>
              <?php endforeach; ?>
            </select>
            <div class="small opacity-75 mt-1">Jika scope = Pusat, branch filter biasanya kosong.</div>
          </div>

          <div class="col-md-2">
            <label class="form-label">Jenis</label>
            <select class="form-select" name="zis_type">
              <option value="">Semua</option>
              <?php foreach($zis_types as $z): ?>
                <option value="<?php echo html_escape($z->code); ?>" <?php echo ((string)$filters['zis_type'] === (string)$z->code) ? 'selected' : ''; ?>>
                  <?php echo html_escape($z->name); ?>
                </option>
              <?php endforeach; ?>
            </select>
          </div>

          <div class="col-md-2">
            <label class="form-label">Status</label>
            <select class="form-select" name="status">
              <?php foreach($statuses as $k=>$v): ?>
                <option value="<?php echo html_escape($k); ?>" <?php echo ((string)$filters['status'] === (string)$k) ? 'selected' : ''; ?>>
                  <?php echo html_escape($v); ?>
                </option>
              <?php endforeach; ?>
            </select>
          </div>

          <div class="col-md-1">
            <label class="form-label">Dari</label>
            <input type="date" class="form-control" name="date_from" value="<?php echo html_escape($filters['date_from']); ?>">
          </div>

          <div class="col-md-1">
            <label class="form-label">Sampai</label>
            <input type="date" class="form-control" name="date_to" value="<?php echo html_escape($filters['date_to']); ?>">
          </div>

          <div class="col-md-6">
            <label class="form-label">Keyword</label>
            <input class="form-control" name="q" placeholder="receipt_no / submission_no / nama / whatsapp / cabang"
              value="<?php echo html_escape($filters['q']); ?>">
          </div>

          <div class="col-md-6 d-flex align-items-end gap-2">
            <button class="btn btn-light"><i class="bi bi-search me-2"></i>Terapkan</button>
            <a class="btn btn-soft" href="<?php echo site_url('dashboard/receipts'); ?>">Reset</a>
          </div>

        </div>
      </form>
    </div>
  </div>

  <div class="card shadow-soft">
    <div class="card-body">
      <div class="table-responsive">
        <table class="table align-middle mb-0">
          <thead>
            <tr>
              <th>Kuitansi</th>
              <th>Tgl Terbit</th>
              <th>Submission</th>
              <th>Nama</th>
              <th>Cabang</th>
              <th>Jenis</th>
              <th>Nominal</th>
              <th>Status</th>
              <th></th>
            </tr>
          </thead>
          <tbody>
            <?php if (empty($rows)): ?>
              <tr><td colspan="9" class="text-center opacity-75 py-4">Tidak ada data.</td></tr>
            <?php else: ?>
              <?php foreach($rows as $r): ?>
                <?php
                  $money = (float)($r->money_amount ?? 0);
                  $kg = (float)($r->rice_kg ?? 0);
                ?>
                <tr>
                  <td class="fw-semibold"><?php echo html_escape($r->receipt_no); ?></td>
                  <td class="opacity-75"><?php echo html_escape($r->issued_at); ?></td>
                  <td><?php echo html_escape($r->submission_no); ?></td>
                  <td><?php echo html_escape($r->applicant_name); ?></td>
                  <td><?php echo html_escape($r->branch_name ?? '-'); ?></td>
                  <td><?php echo html_escape($r->zis_type_code); ?></td>
                  <td>
                    <?php if ($money > 0): ?>
                      Rp <?php echo number_format($money,0,',','.'); ?>
                    <?php else: ?>
                      -
                    <?php endif; ?>
                    <?php if ($kg > 0): ?>
                      <span class="ms-2 badge text-bg-secondary"><?php echo $kg; ?> kg</span>
                    <?php endif; ?>
                  </td>
                  <td><span class="badge text-bg-secondary"><?php echo html_escape($r->status); ?></span></td>
                  <td class="text-end">
                    <?php if (!empty($r->public_token)): ?>
                      <a class="btn btn-soft btn-sm" target="_blank" href="<?php echo site_url('public/receipt/'.$r->public_token); ?>">
                        Publik <i class="bi bi-box-arrow-up-right ms-1"></i>
                      </a>
                    <?php else: ?>
                      <span class="opacity-50">-</span>
                    <?php endif; ?>
                  </td>
                </tr>
              <?php endforeach; ?>
            <?php endif; ?>
          </tbody>
        </table>
      </div>
    </div>

    <div class="card-footer d-flex justify-content-between align-items-center flex-wrap gap-2">
      <div class="opacity-75 small">
        Halaman <?php echo (int)$page; ?> / <?php echo (int)$total_pages; ?>
      </div>

      <div class="d-flex gap-2">
        <?php
          $prev = $page - 1;
          $next = $page + 1;
          $base = site_url('dashboard/receipts').'?';
        ?>
        <a class="btn btn-soft btn-sm <?php echo ($page<=1)?'disabled':''; ?>"
           href="<?php echo $base.qs_keep($filters, array('page'=>$prev)); ?>">
          <i class="bi bi-chevron-left"></i>
        </a>

        <a class="btn btn-soft btn-sm <?php echo ($page>=$total_pages)?'disabled':''; ?>"
           href="<?php echo $base.qs_keep($filters, array('page'=>$next)); ?>">
          <i class="bi bi-chevron-right"></i>
        </a>
      </div>
    </div>
  </div>
</div>
