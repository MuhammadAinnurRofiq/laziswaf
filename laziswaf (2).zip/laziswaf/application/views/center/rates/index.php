<div class="d-flex align-items-center justify-content-between mb-3">
  <div>
    <h3 class="mb-0">Tarif & Kalkulator</h3>
    <div class="text-muted">Tarif pakai sistem tanggal berlaku (effective_from).</div>
  </div>
  <a class="btn btn-primary" href="<?= site_url('dashboard/rates/create') ?>">+ Tambah Tarif</a>
</div>

<?php if (!empty($flash)): ?>
  <div class="alert alert-info"><?= html_escape($flash) ?></div>
<?php endif; ?>

<div class="card">
  <div class="table-responsive">
    <table class="table table-hover align-middle mb-0">
      <thead>
        <tr>
          <th>Jenis</th>
          <th>Mulai Berlaku</th>
          <th>Nilai</th>
          <th>Catatan</th>
          <th style="width:220px;">Aksi</th>
        </tr>
      </thead>
      <tbody>
        <?php foreach($rows as $r): ?>
          <tr>
            <td><?= html_escape($types[$r['zis_type_code']] ?? $r['zis_type_code']) ?></td>
            <td><?= html_escape($r['effective_from']) ?></td>
            <td>
              <?php if ($r['zis_type_code']==='FITRAH'): ?>
                <div>Kg/Jiwa: <b><?= html_escape($r['kg_per_jiwa']) ?></b></div>
                <div>Harga/Jiwa: <b><?= number_format((float)$r['harga_per_jiwa'],0,',','.') ?></b></div>
              <?php elseif ($r['zis_type_code']==='FIDYAH'): ?>
                <div>Tarif/Hari: <b><?= number_format((float)$r['tarif_per_hari'],0,',','.') ?></b></div>
              <?php else: ?>
                <div>Nisab: <b><?= number_format((float)$r['nisab_amount'],0,',','.') ?></b></div>
                <div>Persen: <b><?= html_escape($r['percent']) ?>%</b></div>
              <?php endif; ?>
            </td>
            <td class="text-muted small"><?= html_escape($r['notes'] ?? '') ?></td>
            <td class="d-flex gap-2">
              <a class="btn btn-sm btn-outline-primary" href="<?= site_url('dashboard/rates/edit/'.$r['id']) ?>">Edit</a>
              <form method="post" action="<?= site_url('dashboard/rates/delete/'.$r['id']) ?>" onsubmit="return confirm('Hapus tarif ini?')">
                <button class="btn btn-sm btn-outline-danger" type="submit">Hapus</button>
              </form>
            </td>
          </tr>
        <?php endforeach; ?>
        <?php if (empty($rows)): ?>
          <tr><td colspan="5" class="text-center text-muted py-4">Belum ada tarif.</td></tr>
        <?php endif; ?>
      </tbody>
    </table>
  </div>
</div>
