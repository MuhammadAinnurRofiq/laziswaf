<?php
$is_edit = !empty($row);
$action = $is_edit ? site_url('dashboard/rates/edit/'.$row['id']) : site_url('dashboard/rates/create');
$type_val = $row['zis_type_code'] ?? 'FITRAH';
?>

<div class="d-flex align-items-center justify-content-between mb-3">
  <div>
    <h3 class="mb-0"><?= $is_edit ? 'Edit Tarif' : 'Tambah Tarif' ?></h3>
    <div class="text-muted">Isi sesuai jenis. Sistem mengambil tarif terbaru berdasarkan tanggal berlaku.</div>
  </div>
  <a class="btn btn-outline-secondary" href="<?= site_url('dashboard/rates') ?>">Kembali</a>
</div>

<form class="card p-3" method="post" action="<?= $action ?>">
  <div class="row g-3">
    <div class="col-md-4">
      <label class="form-label">Jenis</label>
      <select class="form-select" name="zis_type_code" id="zis_type_code">
        <?php foreach($types as $k=>$v): ?>
          <option value="<?= $k ?>" <?= $type_val===$k?'selected':'' ?>><?= $v ?></option>
        <?php endforeach; ?>
      </select>
    </div>

    <div class="col-md-4">
      <label class="form-label">Mulai Berlaku</label>
      <input class="form-control" type="date" name="effective_from"
             value="<?= html_escape($row['effective_from'] ?? date('Y-m-d')) ?>" required>
    </div>

    <div class="col-12"><hr class="my-1"></div>

    <div class="col-md-4 rate-fit">
      <label class="form-label">Kg per Jiwa</label>
      <input class="form-control" name="kg_per_jiwa" value="<?= html_escape($row['kg_per_jiwa'] ?? '2.5') ?>">
    </div>
    <div class="col-md-4 rate-fit">
      <label class="form-label">Harga per Jiwa (Rp)</label>
      <input class="form-control" name="harga_per_jiwa" value="<?= html_escape($row['harga_per_jiwa'] ?? '') ?>">
    </div>

    <div class="col-md-4 rate-fid">
      <label class="form-label">Tarif per Hari (Rp)</label>
      <input class="form-control" name="tarif_per_hari" value="<?= html_escape($row['tarif_per_hari'] ?? '') ?>">
    </div>

    <div class="col-md-6 rate-mal">
      <label class="form-label">Nisab (Rp)</label>
      <input class="form-control" name="nisab_amount" value="<?= html_escape($row['nisab_amount'] ?? '') ?>">
    </div>
    <div class="col-md-3 rate-mal">
      <label class="form-label">Persen (%)</label>
      <input class="form-control" name="percent" value="<?= html_escape($row['percent'] ?? '2.5') ?>">
    </div>

    <div class="col-12">
      <label class="form-label">Catatan</label>
      <textarea class="form-control" name="notes" rows="2"><?= html_escape($row['notes'] ?? '') ?></textarea>
    </div>

    <div class="col-12 d-flex gap-2">
      <button class="btn btn-primary" type="submit"><?= $is_edit?'Simpan':'Tambah' ?></button>
      <a class="btn btn-outline-secondary" href="<?= site_url('dashboard/rates') ?>">Batal</a>
    </div>
  </div>
</form>

<script>
(function(){
  const sel = document.getElementById('zis_type_code');
  const toggle = () => {
    const v = sel.value;
    document.querySelectorAll('.rate-fit').forEach(e=>e.style.display = (v==='FITRAH')?'block':'none');
    document.querySelectorAll('.rate-fid').forEach(e=>e.style.display = (v==='FIDYAH')?'block':'none');
    document.querySelectorAll('.rate-mal').forEach(e=>e.style.display = (v==='MAL')?'block':'none');
  };
  sel.addEventListener('change', toggle);
  toggle();
})();
</script>
