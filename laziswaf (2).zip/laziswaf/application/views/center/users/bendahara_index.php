<div class="d-flex align-items-center justify-content-between mb-3">
  <div>
    <h3 class="mb-0">User Bendahara</h3>
    <div class="text-muted">Admin dapat menambah, mengedit, menghapus akun bendahara pusat.</div>
  </div>
  <a class="btn btn-primary" href="<?php echo site_url('dashboard/users/bendahara/create'); ?>">
    <i class="bi bi-plus-lg me-2"></i>Tambah Bendahara
  </a>
</div>

<?php if (!empty($ok)): ?>
  <div class="alert alert-success"><?php echo $ok; ?></div>
<?php endif; ?>
<?php if (!empty($err)): ?>
  <div class="alert alert-danger"><?php echo $err; ?></div>
<?php endif; ?>

<div class="card shadow-soft">
  <div class="card-body">
    <div class="table-responsive">
      <table class="table align-middle">
        <thead>
          <tr>
            <th style="width:60px;">ID</th>
            <th>Username</th>
            <th>Nama</th>
            <th>HP</th>
            <th>Email</th>
            <th>Status</th>
            <th style="width:180px;"></th>
          </tr>
        </thead>
        <tbody>
          <?php if (empty($rows)): ?>
            <tr><td colspan="7" class="text-muted">Belum ada user bendahara.</td></tr>
          <?php else: foreach ($rows as $r): ?>
            <tr>
              <td><?php echo (int)$r->id; ?></td>
              <td class="fw-semibold"><?php echo html_escape($r->username); ?></td>
              <td><?php echo html_escape($r->full_name); ?></td>
              <td><?php echo html_escape($r->phone ?: '-'); ?></td>
              <td><?php echo html_escape($r->email ?: '-'); ?></td>
              <td>
                <?php if ((int)$r->is_active === 1): ?>
                  <span class="badge text-bg-success">AKTIF</span>
                <?php else: ?>
                  <span class="badge text-bg-secondary">NONAKTIF</span>
                <?php endif; ?>
              </td>
              <td class="text-end">
                <a class="btn btn-sm btn-outline-secondary" href="<?php echo site_url('dashboard/users/bendahara/edit/'.$r->id); ?>">
                  Edit
                </a>

                <form method="post" action="<?php echo site_url('dashboard/users/bendahara/delete/'.$r->id); ?>" style="display:inline-block"
                      onsubmit="return confirm('Hapus user ini?');">
                  <button class="btn btn-sm btn-outline-danger">Hapus</button>
                </form>
              </td>
            </tr>
          <?php endforeach; endif; ?>
        </tbody>
      </table>
    </div>
  </div>
</div>
