<?php
defined('BASEPATH') OR exit('No direct script access allowed');

$is_edit = !empty($is_edit);
$row = $row ?? null;

$action = $is_edit ? site_url('dashboard/users/edit/'.(int)$row->id) : site_url('dashboard/users/create');
$val = function($k, $default='') use ($row) {
  if (!$row) return $default;
  return isset($row->$k) ? $row->$k : $default;
};

$role_code = strtoupper((string)($row->role_code ?? 'CABANG'));
$branch_id = (int)($row->branch_id ?? 0);
?>
<div class="d-flex align-items-center justify-content-between mb-3">
  <div>
    <h3 class="mb-0"><?php echo $is_edit ? 'Edit User' : 'Tambah User'; ?></h3>
    <div class="text-muted">Kelola akun pengguna sistem.</div>
  </div>
  <a class="btn btn-soft" href="<?php echo site_url('dashboard/users'); ?>">
    <i class="bi bi-arrow-left me-2"></i>Kembali
  </a>
</div>

<?php if (!empty($ok)): ?>
  <div class="alert alert-success"><?php echo $ok; ?></div>
<?php endif; ?>
<?php if (!empty($err)): ?>
  <div class="alert alert-danger"><?php echo $err; ?></div>
<?php endif; ?>
<?php echo validation_errors('<div class="alert alert-danger">','</div>'); ?>

<div class="card shadow-soft">
  <div class="card-body">
    <form method="post" action="<?php echo $action; ?>">
      <div class="row g-3">
        <div class="col-md-4">
          <label class="form-label">Username</label>
          <input type="text" name="username" class="form-control" value="<?php echo html_escape(set_value('username', $val('username'))); ?>" required>
        </div>
        <div class="col-md-8">
          <label class="form-label">Nama Lengkap</label>
          <input type="text" name="full_name" class="form-control" value="<?php echo html_escape(set_value('full_name', $val('full_name'))); ?>" required>
        </div>

        <div class="col-md-4">
          <label class="form-label">Role</label>
          <select name="role_code" id="role_code" class="form-select" required>
            <?php foreach (($roles ?? array()) as $code => $name): ?>
              <option value="<?php echo html_escape($code); ?>" <?php echo (set_value('role_code', $role_code)===$code ? 'selected' : ''); ?>>
                <?php echo html_escape($code.' - '.$name); ?>
              </option>
            <?php endforeach; ?>
          </select>
          <div class="form-text">Jika memilih CABANG, maka cabang wajib diisi.</div>
        </div>

        <div class="col-md-4" id="wrap_branch">
          <label class="form-label">Cabang</label>
          <select name="branch_id" id="branch_id" class="form-select">
            <option value="0">- Pilih Cabang -</option>
            <?php foreach (($branches ?? array()) as $b): ?>
              <option value="<?php echo (int)$b->id; ?>" <?php echo ((int)set_value('branch_id', $branch_id)===(int)$b->id ? 'selected' : ''); ?>>
                <?php echo html_escape($b->branch_name); ?>
              </option>
            <?php endforeach; ?>
          </select>
        </div>

        <div class="col-md-4">
          <label class="form-label">Aktif</label>
          <select name="is_active" class="form-select">
            <option value="1" <?php echo ((int)set_value('is_active', (int)$val('is_active',1))===1?'selected':''); ?>>Aktif</option>
            <option value="0" <?php echo ((int)set_value('is_active', (int)$val('is_active',1))===0?'selected':''); ?>>Nonaktif</option>
          </select>
        </div>

        <div class="col-md-4">
          <label class="form-label">Password <?php echo $is_edit ? '(opsional)' : ''; ?></label>
          <input type="password" name="password" class="form-control" <?php echo $is_edit ? '' : 'required'; ?> minlength="6">
          <?php if ($is_edit): ?>
            <div class="form-text">Kosongkan jika tidak ingin mengganti password.</div>
          <?php endif; ?>
        </div>

        <div class="col-md-4">
          <label class="form-label">No HP</label>
          <input type="text" name="phone" class="form-control" value="<?php echo html_escape(set_value('phone', $val('phone'))); ?>">
        </div>

        <div class="col-md-4">
          <label class="form-label">Email</label>
          <input type="text" name="email" class="form-control" value="<?php echo html_escape(set_value('email', $val('email'))); ?>">
        </div>

        <div class="col-12">
          <hr class="opacity-25">
        </div>
        <div class="col-12 d-flex gap-2">
          <button class="btn btn-primary">
            <i class="bi bi-save me-2"></i>Simpan
          </button>
          <a class="btn btn-light" href="<?php echo site_url('dashboard/users'); ?>">Batal</a>
        </div>
      </div>
    </form>
  </div>
</div>

<script>
(function(){
  function toggleBranch(){
    var role = (document.getElementById('role_code')||{}).value || '';
    var wrap = document.getElementById('wrap_branch');
    if (!wrap) return;
    if (String(role).toUpperCase() === 'CABANG') {
      wrap.style.display = '';
    } else {
      wrap.style.display = 'none';
      var b = document.getElementById('branch_id');
      if (b) b.value = '0';
    }
  }
  document.getElementById('role_code').addEventListener('change', toggleBranch);
  toggleBranch();
})();
</script>
