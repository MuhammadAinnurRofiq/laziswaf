<?php $is_edit = !empty($row); ?>

<div class="d-flex align-items-center justify-content-between mb-3">
  <div>
    <h3 class="mb-0"><?php echo $is_edit ? 'Edit User Bendahara' : 'Tambah User Bendahara'; ?></h3>
    <div class="text-muted">Role yang dibuat otomatis: BENDAHARA (Pusat).</div>
  </div>
  <a class="btn btn-outline-secondary" href="<?php echo site_url('dashboard/users/bendahara'); ?>">Kembali</a>
</div>

<?php if (!empty($err)): ?>
  <div class="alert alert-danger"><?php echo $err; ?></div>
<?php endif; ?>

<div class="card shadow-soft">
  <div class="card-body">
    <form method="post">
      <div class="row g-3">
        <div class="col-md-6">
          <label class="form-label">Username</label>
          <input class="form-control" name="username" required
                 value="<?php echo set_value('username', $row->username ?? ''); ?>">
        </div>

        <div class="col-md-6">
          <label class="form-label">Nama Lengkap</label>
          <input class="form-control" name="full_name" required
                 value="<?php echo set_value('full_name', $row->full_name ?? ''); ?>">
        </div>

        <div class="col-md-6">
          <label class="form-label"><?php echo $is_edit ? 'Password Baru (opsional)' : 'Password'; ?></label>
          <input class="form-control" name="password" type="password" <?php echo $is_edit ? '' : 'required'; ?>
                 placeholder="<?php echo $is_edit ? 'Kosongkan jika tidak ganti password' : ''; ?>">
        </div>

        <div class="col-md-6">
          <label class="form-label">No HP</label>
          <input class="form-control" name="phone"
                 value="<?php echo set_value('phone', $row->phone ?? ''); ?>">
        </div>

        <div class="col-md-6">
          <label class="form-label">Email</label>
          <input class="form-control" name="email"
                 value="<?php echo set_value('email', $row->email ?? ''); ?>">
        </div>

        <div class="col-md-6 d-flex align-items-end">
          <div class="form-check">
            <?php $active = set_value('is_active', ($row->is_active ?? 1)) ? 1 : 0; ?>
            <input class="form-check-input" type="checkbox" name="is_active" value="1" <?php echo $active ? 'checked' : ''; ?>>
            <label class="form-check-label">Aktif</label>
          </div>
        </div>
      </div>

      <hr class="opacity-25">

      <button class="btn btn-primary">
        <?php echo $is_edit ? 'Simpan Perubahan' : 'Buat User Bendahara'; ?>
      </button>
    </form>
  </div>
</div>
