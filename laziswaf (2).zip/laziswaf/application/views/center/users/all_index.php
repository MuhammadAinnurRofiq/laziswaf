<?php
defined('BASEPATH') OR exit('No direct script access allowed');
$q = $filters['q'] ?? '';
$roleFilter = strtoupper((string)($filters['role'] ?? ''));
?>
<div class="d-flex align-items-center justify-content-between mb-3">
  <div>
    <h3 class="mb-0"><?php echo html_escape($title); ?></h3>
    <div class="text-muted">Administrator dapat melihat, menambah, mengedit, dan menghapus semua user (CABANG, BENDAHARA, ADMIN).</div>
  </div>
  <a class="btn btn-primary" href="<?php echo site_url('dashboard/users/create'); ?>">
    <i class="bi bi-plus-lg me-2"></i>Tambah User
  </a>
</div>

<?php if (!empty($ok)): ?>
  <div class="alert alert-success"><?php echo $ok; ?></div>
<?php endif; ?>
<?php if (!empty($err)): ?>
  <div class="alert alert-danger"><?php echo $err; ?></div>
<?php endif; ?>

<div class="card shadow-soft mb-3">
  <div class="card-body">
    <form method="get" class="row g-2 align-items-end">
      <div class="col-md-6">
        <label class="form-label">Cari</label>
        <input type="text" name="q" class="form-control" placeholder="username / nama / hp / email" value="<?php echo html_escape($q); ?>">
      </div>
      <div class="col-md-4">
        <label class="form-label">Role</label>
        <select name="role" class="form-select">
          <option value="">Semua</option>
          <?php foreach (($roles ?? array()) as $code => $name): ?>
            <option value="<?php echo html_escape($code); ?>" <?php echo ($roleFilter===$code?'selected':''); ?>>
              <?php echo html_escape($code.' - '.$name); ?>
            </option>
          <?php endforeach; ?>
        </select>
      </div>
      <div class="col-md-2 d-grid">
        <button class="btn btn-soft"><i class="bi bi-search me-2"></i>Filter</button>
      </div>
    </form>
  </div>
</div>

<div class="card shadow-soft">
  <div class="card-body">
    <div class="table-responsive">
      <table class="table align-middle">
        <thead>
          <tr>
            <th style="width:60px;">#</th>
            <th>Username</th>
            <th>Nama</th>
            <th>Role</th>
            <th>Cabang</th>
            <th>Status</th>
            <th>Dibuat</th>
            <th style="width:170px;">Aksi</th>
          </tr>
        </thead>
        <tbody>
          <?php if (empty($rows)): ?>
            <tr><td colspan="8" class="text-center text-muted py-4">Belum ada data.</td></tr>
          <?php else: ?>
            <?php $no=1; foreach ($rows as $r): ?>
              <tr>
                <td><?php echo $no++; ?></td>
                <td class="fw-semibold"><?php echo html_escape($r->username); ?></td>
                <td><?php echo html_escape($r->full_name); ?></td>
                <td>
                  <span class="badge text-bg-secondary"><?php echo html_escape($r->role_code ?? '-'); ?></span>
                </td>
                <td><?php echo html_escape($r->branch_name ?? '-'); ?></td>
                <td>
                  <?php if ((int)$r->is_active === 1): ?>
                    <span class="badge text-bg-success">AKTIF</span>
                  <?php else: ?>
                    <span class="badge text-bg-danger">NONAKTIF</span>
                  <?php endif; ?>
                </td>
                <td class="small opacity-75"><?php echo html_escape($r->created_at); ?></td>
                <td>
                  <a class="btn btn-sm btn-light" href="<?php echo site_url('dashboard/users/edit/'.$r->id); ?>">
                    <i class="bi bi-pencil-square me-1"></i>Edit
                  </a>
                  <a class="btn btn-sm btn-outline-danger"
                     href="<?php echo site_url('dashboard/users/delete/'.$r->id); ?>"
                     onclick="return confirm('Hapus user <?php echo html_escape($r->username); ?>? Tindakan ini tidak bisa dibatalkan.');">
                    <i class="bi bi-trash me-1"></i>Hapus
                  </a>
                </td>
              </tr>
            <?php endforeach; ?>
          <?php endif; ?>
        </tbody>
      </table>
    </div>
  </div>
</div>
