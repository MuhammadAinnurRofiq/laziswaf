<?php
$nom = $sub->amount_money ?: $sub->fitrah_total_money;
$kg  = $sub->fitrah_total_kg;
?>

<div class="container-fluid">
  <div class="page-hero mb-3">
    <div>
      <h3 class="mb-1">Detail Pengajuan (Pusat)</h3>
      <div class="opacity-75">
        <?php echo html_escape($sub->submission_no); ?> •
        <?php echo html_escape($sub->branch_name ?? '-'); ?> •
        <span class="badge text-bg-secondary"><?php echo html_escape($sub->status); ?></span>
      </div>
    </div>
    <a class="btn btn-soft" href="<?php echo site_url('dashboard/submissions'); ?>">
      <i class="bi bi-arrow-left me-2"></i>Kembali
    </a>
  </div>

  <div class="row g-3">
    <div class="col-lg-8">
      <div class="card shadow-soft">
        <div class="card-body">
          <div class="row g-3">
            <div class="col-md-6">
              <div class="opacity-75">Nama</div>
              <div class="fw-semibold"><?php echo html_escape($sub->applicant_name); ?></div>
            </div>
            <div class="col-md-6">
              <div class="opacity-75">WhatsApp</div>
              <div class="fw-semibold"><?php echo html_escape($sub->whatsapp); ?></div>
            </div>

            <div class="col-md-6">
              <div class="opacity-75">Jenis</div>
              <div class="fw-semibold"><?php echo html_escape($sub->zis_type_code); ?></div>
            </div>
            <div class="col-md-6">
              <div class="opacity-75">Tanggal Submit</div>
              <div class="fw-semibold"><?php echo html_escape($sub->submitted_at); ?></div>
            </div>

            <div class="col-md-6">
              <div class="opacity-75">Nominal</div>
              <div class="fw-semibold">
                <?php echo $nom ? 'Rp '.number_format((float)$nom,0,',','.') : '-'; ?>
                <?php if (!empty($kg)): ?>
                  <span class="ms-2 badge text-bg-secondary"><?php echo (float)$kg; ?> kg</span>
                <?php endif; ?>
              </div>
            </div>

            <div class="col-md-6">
              <div class="opacity-75">Kuitansi</div>
              <?php if (!empty($sub->receipt_no)): ?>
                <div class="fw-semibold"><?php echo html_escape($sub->receipt_no); ?></div>
                <?php if (!empty($sub->public_token)): ?>
                  <a target="_blank" class="text-decoration-none" href="<?php echo site_url('public/receipt/'.$sub->public_token); ?>">
                    Buka Kuitansi Publik <i class="bi bi-box-arrow-up-right ms-1"></i>
                  </a>
                <?php endif; ?>
              <?php else: ?>
                <div class="opacity-75">Belum terbit.</div>
              <?php endif; ?>

              <?php if (!empty($sub->receipt_is_void) && (int)$sub->receipt_is_void === 1): ?>
                <div class="alert alert-warning mt-3 mb-0">
                  <div class="fw-semibold">Kuitansi sudah tidak berlaku (VOID)</div>
                  <?php if (!empty($sub->voided_at)): ?>
                    <div class="small opacity-75">Divoid pada: <?php echo html_escape($sub->voided_at); ?></div>
                  <?php endif; ?>
                  <?php if (!empty($sub->void_reason)): ?>
                    <div class="small">Alasan: <?php echo html_escape($sub->void_reason); ?></div>
                  <?php endif; ?>
                  <div class="small opacity-75">Link kuitansi publik tetap dapat dibuka, namun akan menampilkan peringatan.</div>
                </div>
              <?php endif; ?>

            </div>
          </div>

          <?php if (!empty($people)): ?>
            <hr class="opacity-25">
            <div class="fw-semibold mb-2">Tanggungan</div>
            <ul class="mb-0 opacity-75">
              <?php foreach($people as $p): ?>
                <li><?php echo html_escape($p->person_name); ?></li>
              <?php endforeach; ?>
            </ul>
          <?php endif; ?>
        </div>
      </div>

      <div class="card shadow-soft mt-3">
        <div class="card-body">
          <div class="fw-semibold mb-2">Riwayat Approval</div>
          <?php if (empty($logs)): ?>
            <div class="opacity-75">Belum ada log.</div>
          <?php else: ?>
            <div class="table-responsive">
              <table class="table mb-0">
                <thead>
                  <tr>
                    <th>Waktu</th>
                    <th>Aksi</th>
                    <th>Oleh</th>
                    <th>Dari</th>
                    <th>Ke</th>
                    <th>Catatan</th>
                  </tr>
                </thead>
                <tbody>
                  <?php foreach($logs as $l): ?>
                    <tr>
                      <td class="opacity-75"><?php echo html_escape($l->created_at); ?></td>
                      <td class="fw-semibold"><?php echo html_escape($l->action); ?></td>
                      <td><?php echo html_escape($l->actor_full_name ?? '-'); ?></td>
                      <td><?php echo html_escape($l->from_status); ?></td>
                      <td><?php echo html_escape($l->to_status); ?></td>
                      <td class="opacity-75"><?php echo html_escape($l->note); ?></td>
                    </tr>
                  <?php endforeach; ?>
                </tbody>
              </table>
            </div>
          <?php endif; ?>
        </div>
      
      <?php if (in_array($role, array('ADMIN','BENDAHARA'), true)): ?>
        <div class="card border-danger shadow-soft mt-3">
          <div class="card-body">
            <div class="d-flex align-items-center justify-content-between">
              <div>
                <div class="fw-semibold text-danger">Hapus Transaksi (VOID)</div>
                <div class="small text-muted">Gunakan jika ada kesalahan approve oleh cabang. Data tidak dihapus fisik; transaksi ditandai VOID dan status submission menjadi DELETED.</div>
              </div>
            </div>

            <?php if (in_array($sub->status, array('BRANCH_APPROVED','CENTER_LOCKED'), true) && (empty($sub->receipt_is_void) || (int)$sub->receipt_is_void === 0)): ?>
              <form method="post" action="<?php echo site_url('dashboard/submissions/delete/'.(int)$sub->id); ?>" onsubmit="return confirm('Batalkan (VOID) transaksi ini? Kuitansi publik akan tetap bisa dibuka namun tidak berlaku.');">
                <div class="mt-3">
                  <label class="form-label">Alasan</label>
                  <textarea name="reason" class="form-control" rows="3" placeholder="Contoh: Salah input nominal / salah approve / duplikat transaksi" required></textarea>
                </div>
                <button class="btn btn-danger mt-3 w-100">
                  <i class="bi bi-trash me-2"></i>VOID Transaksi
                </button>
              </form>
            <?php else: ?>
              <div class="alert alert-secondary mt-3 mb-0">
                Tidak tersedia: transaksi belum APPROVED atau sudah pernah di-VOID.
              </div>
            <?php endif; ?>
          </div>
        </div>
      <?php endif; ?>

</div>
    </div>

    <div class="col-lg-4">
      <div class="card shadow-soft">
        <div class="card-body">
          <div class="fw-semibold mb-2">Pembagian (Auto)</div>
          <?php if (!empty($sub->branch_share_money) || !empty($sub->branch_share_rice_kg)): ?>
            <?php if (!empty($sub->branch_share_money)): ?>
              <div class="small opacity-75">Uang</div>
              <div class="fw-semibold">Cabang: Rp <?php echo number_format((float)$sub->branch_share_money,0,',','.'); ?></div>
              <div class="opacity-75">Hak Amil: Rp <?php echo number_format((float)$sub->branch_amil_money,0,',','.'); ?></div>
              <div class="opacity-75">Distribusi: Rp <?php echo number_format((float)$sub->branch_dist_money,0,',','.'); ?></div>
              <div class="opacity-75">Pusat: Rp <?php echo number_format((float)$sub->center_share_money,0,',','.'); ?></div>
              <hr class="opacity-25">
            <?php endif; ?>

            <?php if (!empty($sub->branch_share_rice_kg)): ?>
              <div class="small opacity-75">Beras</div>
              <div class="fw-semibold">Cabang: <?php echo (float)$sub->branch_share_rice_kg; ?> kg</div>
              <div class="opacity-75">Hak Amil: <?php echo (float)$sub->branch_amil_rice_kg; ?> kg</div>
              <div class="opacity-75">Distribusi: <?php echo (float)$sub->branch_dist_rice_kg; ?> kg</div>
              <div class="opacity-75">Pusat: <?php echo (float)$sub->center_share_rice_kg; ?> kg</div>
            <?php endif; ?>
          <?php else: ?>
            <div class="opacity-75">Belum ada allocation (umumnya belum approve cabang).</div>
          <?php endif; ?>
        </div>
      </div>
    </div>

  </div>
</div>
