<?php
$is_edit = !empty($row);
$action = $is_edit ? site_url('dashboard/branches/edit/'.$row['id']) : site_url('dashboard/branches/create');
?>

<div class="d-flex align-items-center justify-content-between mb-3">
  <div>
    <h3 class="mb-0"><?= $is_edit ? 'Edit Cabang' : 'Tambah Cabang' ?></h3>
    <div class="text-muted">Bendahara/Admin dapat membuat & mengubah akun cabang.</div>
  </div>
  <a class="btn btn-outline-secondary" href="<?= site_url('dashboard/branches') ?>">Kembali</a>
</div>

<form class="card p-3" method="post" action="<?= $action ?>">
  <div class="row g-3">
    <div class="col-md-4">
      <label class="form-label">Kode Cabang</label>
      <input class="form-control" name="branch_code" value="<?= html_escape($row['branch_code'] ?? '') ?>" placeholder="Contoh: MS01" required>
    </div>

    <div class="col-md-8">
      <label class="form-label">Nama Cabang</label>
      <input class="form-control" name="branch_name" value="<?= html_escape($row['branch_name'] ?? '') ?>" placeholder="Nama Masjid/Musholla/Unit" required>
    </div>

    <div class="col-md-6">
      <label class="form-label">No. WA (contact_wa)</label>
      <input class="form-control" name="contact_wa" value="<?= html_escape($row['contact_wa'] ?? '') ?>" placeholder="628xxxxxxxxxxx">
    </div>

    <div class="col-md-6">
      <label class="form-label">Email (opsional)</label>
      <input class="form-control" name="email" value="<?= html_escape($userrow['email'] ?? '') ?>" placeholder="email@contoh.com">
    </div>

    <div class="col-md-12">
      <label class="form-label">Alamat (opsional)</label>
      <input class="form-control" name="address" value="<?= html_escape($row['address'] ?? '') ?>" placeholder="Alamat cabang">
    </div>

    <hr class="my-2">

    <div class="col-md-6">
      <label class="form-label">Username Cabang</label>
      <input class="form-control" name="username" value="<?= html_escape($userrow['username'] ?? '') ?>" required>
    </div>

    <div class="col-md-6">
      <label class="form-label"><?= $is_edit ? 'Password Baru (kosongkan jika tidak diubah)' : 'Password' ?></label>
      <input class="form-control" name="password" type="password" <?= $is_edit ? '' : 'required' ?> minlength="6">
    </div>

    <div class="col-md-3">
      <label class="form-label">Status</label>
      <select class="form-select" name="is_active">
        <?php $active = (int)($row['is_active'] ?? 1); ?>
        <option value="1" <?= $active===1?'selected':'' ?>>Aktif</option>
        <option value="0" <?= $active===0?'selected':'' ?>>Nonaktif</option>
      </select>
    </div>

    <div class="col-12 d-flex gap-2">
      <button class="btn btn-primary" type="submit"><?= $is_edit ? 'Simpan Perubahan' : 'Buat Cabang' ?></button>
      <a class="btn btn-outline-secondary" href="<?= site_url('dashboard/branches') ?>">Batal</a>
    </div>
  </div>
</form>
