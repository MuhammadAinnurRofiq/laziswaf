<?php
$is_edit  = !empty($row);
$branch_id = (int)($branch['id'] ?? 0);
$user_id   = (int)($row['id'] ?? 0);
$action = $is_edit
  ? site_url('dashboard/branches/users/'.$branch_id.'/edit/'.$user_id)
  : site_url('dashboard/branches/users/'.$branch_id.'/create');
?>

<div class="d-flex align-items-center justify-content-between mb-3">
  <div>
    <h3 class="mb-0"><?= $is_edit ? 'Edit User Cabang' : 'Tambah User Cabang' ?></h3>
    <div class="text-muted">
      Cabang: <span class="fw-semibold"><?= html_escape($branch['branch_code'] ?? '') ?></span> — <?= html_escape($branch['branch_name'] ?? '') ?>
    </div>
  </div>
  <a class="btn btn-outline-secondary" href="<?= site_url('dashboard/branches/users/'.$branch_id) ?>">Kembali</a>
</div>

<?php if (!empty($flash)): ?>
  <div class="alert alert-info"><?= html_escape($flash) ?></div>
<?php endif; ?>

<form class="card shadow-soft p-3" method="post" action="<?= $action ?>">
  <div class="row g-3">
    <div class="col-md-6">
      <label class="form-label">Username</label>
      <input class="form-control" name="username" required
             value="<?= html_escape($row['username'] ?? '') ?>">
    </div>

    <div class="col-md-6">
      <label class="form-label">Nama Lengkap</label>
      <input class="form-control" name="full_name" required
             value="<?= html_escape($row['full_name'] ?? '') ?>">
    </div>

    <div class="col-md-6">
      <label class="form-label"><?= $is_edit ? 'Password Baru (opsional)' : 'Password' ?></label>
      <input class="form-control" name="password" type="password" <?= $is_edit ? '' : 'required' ?> minlength="6"
             placeholder="<?= $is_edit ? 'Kosongkan jika tidak ganti password' : '' ?>">
      <div class="form-text">Minimal 6 karakter.</div>
    </div>

    <div class="col-md-6">
      <label class="form-label">No HP</label>
      <input class="form-control" name="phone"
             value="<?= html_escape($row['phone'] ?? '') ?>">
    </div>

    <div class="col-md-6">
      <label class="form-label">Email</label>
      <input class="form-control" name="email"
             value="<?= html_escape($row['email'] ?? '') ?>">
    </div>

    <div class="col-md-3">
      <label class="form-label">Status</label>
      <?php $active = (int)($row['is_active'] ?? 1); ?>
      <select class="form-select" name="is_active">
        <option value="1" <?= $active===1?'selected':'' ?>>Aktif</option>
        <option value="0" <?= $active===0?'selected':'' ?>>Nonaktif</option>
      </select>
    </div>

    <div class="col-12 d-flex gap-2">
      <button class="btn btn-primary" type="submit"><?= $is_edit ? 'Simpan Perubahan' : 'Buat User' ?></button>
      <a class="btn btn-outline-secondary" href="<?= site_url('dashboard/branches/users/'.$branch_id) ?>">Batal</a>
    </div>
  </div>
</form>
