<div class="d-flex align-items-center justify-content-between mb-3">
  <div>
    <h3 class="mb-0">Cabang & Akun Cabang</h3>
    <div class="text-muted">Kelola cabang + user cabang + kartu QR.</div>
  </div>
  <a class="btn btn-primary" href="<?= site_url('dashboard/branches/create') ?>">+ Tambah Cabang</a>
</div>

<?php if (!empty($flash)): ?>
  <div class="alert alert-info"><?= html_escape($flash) ?></div>
<?php endif; ?>

<form class="row g-2 mb-3" method="get" action="<?= site_url('dashboard/branches') ?>">
  <div class="col-md-6">
    <input type="text" class="form-control" name="q" value="<?= html_escape($q) ?>" placeholder="Cari: kode, nama, username...">
  </div>
  <div class="col-md-3">
    <button class="btn btn-outline-secondary w-100">Cari</button>
  </div>
</form>

<div class="card">
  <div class="table-responsive">
    <table class="table table-hover align-middle mb-0">
      <thead>
        <tr>
          <th>Kode</th>
          <th>Nama Cabang</th>
          <th>User Cabang</th>
          <th>WA</th>
          <th>Status</th>
          <th style="width:280px;">Aksi</th>
        </tr>
      </thead>
      <tbody>
        <?php foreach($rows as $r): ?>
          <tr>
            <td><?= html_escape($r['branch_code']) ?></td>
            <td><?= html_escape($r['branch_name']) ?></td>
            <td>
              <div class="fw-semibold"><?= html_escape($r['username'] ?? '-') ?></div>
              <div class="text-muted small"><?= (int)($r['user_count'] ?? 0) ?> user</div>
            </td>
            <td><?= html_escape($r['contact_wa'] ?? '-') ?></td>
            <td>
              <?php if ((int)$r['is_active'] === 1): ?>
                <span class="badge text-bg-success">ACTIVE</span>
              <?php else: ?>
                <span class="badge text-bg-secondary">INACTIVE</span>
              <?php endif; ?>
            </td>
            <td class="d-flex gap-2">
              <a class="btn btn-sm btn-outline-primary" href="<?= site_url('dashboard/branches/edit/'.$r['id']) ?>">Edit</a>
              <a class="btn btn-sm btn-outline-success" href="<?= site_url('dashboard/branches/users/'.$r['id']) ?>">User</a>
              <a class="btn btn-sm btn-outline-dark" href="<?= site_url('dashboard/branches/card/'.$r['id']) ?>">Kartu QR</a>

              <form method="post" action="<?= site_url('dashboard/branches/delete/'.$r['id']) ?>" onsubmit="return confirm('Nonaktifkan cabang ini? (soft delete)')">
                <button class="btn btn-sm btn-outline-danger" type="submit">Hapus</button>
              </form>
            </td>
          </tr>
        <?php endforeach; ?>
        <?php if (empty($rows)): ?>
          <tr><td colspan="6" class="text-center text-muted py-4">Tidak ada data.</td></tr>
        <?php endif; ?>
      </tbody>
    </table>
  </div>
</div>
