<?php
$branch_id = (int)($branch['id'] ?? 0);
?>

<div class="d-flex align-items-center justify-content-between mb-3">
  <div>
    <h3 class="mb-0">User Cabang</h3>
    <div class="text-muted">
      Cabang: <span class="fw-semibold"><?= html_escape($branch['branch_code'] ?? '') ?></span> — <?= html_escape($branch['branch_name'] ?? '') ?>
    </div>
  </div>
  <div class="d-flex gap-2">
    <a class="btn btn-outline-secondary" href="<?= site_url('dashboard/branches') ?>">Kembali</a>
    <a class="btn btn-primary" href="<?= site_url('dashboard/branches/users/'.$branch_id.'/create') ?>">
      <i class="bi bi-plus-lg me-2"></i>Tambah User Cabang
    </a>
  </div>
</div>

<?php if (!empty($flash)): ?>
  <div class="alert alert-info"><?= html_escape($flash) ?></div>
<?php endif; ?>

<form class="row g-2 mb-3" method="get" action="<?= site_url('dashboard/branches/users/'.$branch_id) ?>">
  <div class="col-md-6">
    <input type="text" class="form-control" name="q" value="<?= html_escape($q ?? '') ?>" placeholder="Cari: username, nama, HP, email...">
  </div>
  <div class="col-md-3">
    <button class="btn btn-outline-secondary w-100">Cari</button>
  </div>
</form>

<div class="card shadow-soft">
  <div class="card-body">
    <div class="table-responsive">
      <table class="table align-middle">
        <thead>
          <tr>
            <th style="width:70px;">ID</th>
            <th>Username</th>
            <th>Nama</th>
            <th>HP</th>
            <th>Email</th>
            <th>Last Login</th>
            <th>Status</th>
            <th style="width:220px;"></th>
          </tr>
        </thead>
        <tbody>
          <?php if (empty($rows)): ?>
            <tr><td colspan="8" class="text-muted">Belum ada user cabang.</td></tr>
          <?php else: foreach ($rows as $r): ?>
            <tr>
              <td><?= (int)$r['id'] ?></td>
              <td class="fw-semibold"><?= html_escape($r['username']) ?></td>
              <td><?= html_escape($r['full_name']) ?></td>
              <td><?= html_escape($r['phone'] ?: '-') ?></td>
              <td><?= html_escape($r['email'] ?: '-') ?></td>
              <td><?= !empty($r['last_login_at']) ? html_escape($r['last_login_at']) : '-' ?></td>
              <td>
                <?php if ((int)$r['is_active'] === 1): ?>
                  <span class="badge text-bg-success">AKTIF</span>
                <?php else: ?>
                  <span class="badge text-bg-secondary">NONAKTIF</span>
                <?php endif; ?>
              </td>
              <td class="text-end">
                <a class="btn btn-sm btn-outline-primary" href="<?= site_url('dashboard/branches/users/'.$branch_id.'/edit/'.(int)$r['id']) ?>">
                  Edit
                </a>

                <form method="post" action="<?= site_url('dashboard/branches/users/'.$branch_id.'/toggle/'.(int)$r['id']) ?>" class="d-inline"
                      onsubmit="return confirm('Ubah status user ini?')">
                  <?php if ((int)$r['is_active'] === 1): ?>
                    <button class="btn btn-sm btn-outline-danger" type="submit">Nonaktifkan</button>
                  <?php else: ?>
                    <button class="btn btn-sm btn-outline-success" type="submit">Aktifkan</button>
                  <?php endif; ?>
                </form>
              </td>
            </tr>
          <?php endforeach; endif; ?>
        </tbody>
      </table>
    </div>
  </div>
</div>
