<div class="d-flex align-items-center justify-content-between mb-3 no-print">
  <div>
    <h3 class="mb-0">Kartu Cabang</h3>
    <div class="text-muted">Scan QR untuk memilih cabang otomatis pada pengajuan publik.</div>
  </div>
  <div class="d-flex gap-2">
    <button class="btn btn-outline-primary" onclick="window.print()">Cetak / Simpan PDF</button>
    <a class="btn btn-outline-secondary" href="<?= site_url('dashboard/branches') ?>">Kembali</a>
  </div>
</div>

<style>
@media print {
  .no-print { display:none !important; }
  .card-print { box-shadow:none !important; border:1px solid #ddd; }
}
.card-print{
  max-width: 520px;
  margin: 0 auto;
  border-radius: 16px;
}
.qrbox{
  width: 220px; height: 220px;
  display:flex; align-items:center; justify-content:center;
  border-radius: 12px;
  border: 1px dashed #bbb;
  background: #fff;
}
</style>

<div class="card card-print p-3">
  <?php $this->load->view('partials/print_header', array(
    'print_title' => 'Kartu Cabang',
    'print_year'  => date('Y'),
  )); ?>

  <div class="d-flex align-items-center justify-content-between">
    <div class="text-muted">Kartu Identitas Cabang</div>
    <span class="badge text-bg-dark">CABANG</span>
  </div>

  <hr>

  <div class="mb-2">
    <div class="text-muted small">Kode Cabang</div>
    <div class="fw-semibold"><?= html_escape($branch['branch_code']) ?></div>
  </div>
  <div class="mb-2">
    <div class="text-muted small">Nama Cabang</div>
    <div class="fw-semibold"><?= html_escape($branch['branch_name']) ?></div>
  </div>
  <div class="mb-2">
    <div class="text-muted small">WA</div>
    <div class="fw-semibold"><?= html_escape($branch['contact_wa'] ?? '-') ?></div>
  </div>

  <div class="mb-3">
    <div class="text-muted small">Link Scan</div>
    <div class="small"><a href="<?= $scan_url ?>" target="_blank"><?= $scan_url ?></a></div>
  </div>

  <div class="d-flex gap-3 align-items-start">
    <div class="qrbox" id="qrcode"></div>
    <div class="flex-grow-1">
      <div class="fw-semibold mb-1">Cara pakai:</div>
      <ol class="small mb-0">
        <li>Warga scan QR ini.</li>
        <li>Halaman publik otomatis memilih cabang ini.</li>
        <li>Warga lanjut isi pengajuan.</li>
      </ol>

      <button class="btn btn-sm btn-outline-dark mt-2 no-print" id="btnDownloadQR" type="button">
        Download QR (PNG)
      </button>
    </div>
  </div>

  <hr>
  <?php $appName = function_exists('app_setting') ? app_setting('app_name','LAZISWAF') : 'LAZISWAF'; ?>
  <div class="text-muted small">© <?= date('Y') ?> <?= html_escape($appName) ?></div>
</div>

<!-- QR generator (CDN) -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/qrcodejs/1.0.0/qrcode.min.js"></script>
<script>
  const scanUrl = <?= json_encode($scan_url) ?>;

  // render QR
  const qr = new QRCode(document.getElementById("qrcode"), {
    text: scanUrl,
    width: 210,
    height: 210
  });

  // download QR canvas
  document.getElementById('btnDownloadQR').addEventListener('click', function () {
    const canvas = document.querySelector('#qrcode canvas');
    if (!canvas) return alert('QR belum siap.');
    const a = document.createElement('a');
    a.href = canvas.toDataURL('image/png');
    a.download = 'QR_<?= html_escape($branch['branch_code']) ?>.png';
    a.click();
  });
</script>
