<div class="d-flex align-items-center justify-content-between mb-3">
  <div>
    <h3 class="mb-0">Status Laporan Cabang</h3>
    <div class="text-muted">
      Periode: <b><?php echo (int)$period->year; ?>-<?php echo str_pad((string)$period->month,2,'0',STR_PAD_LEFT); ?></b>
    </div>
  </div>

  <div class="d-flex gap-2">
    <a class="btn btn-soft" href="<?php echo site_url('dashboard/reports/branches/pdf?period_id='.$period->id); ?>">
      <i class="bi bi-filetype-pdf me-2"></i>Export PDF
    </a>
  </div>
</div>

<div class="card shadow-soft mb-3">
  <div class="card-body">
    <form class="row g-2 align-items-end" method="get" action="<?php echo site_url('dashboard/reports/branches'); ?>">
      <div class="col-md-4">
        <label class="form-label">Periode</label>
        <select class="form-select" name="period_id">
          <?php foreach($periods as $p): ?>
            <?php $sel = ((int)$p['id']===(int)$period->id) ? 'selected' : ''; ?>
            <option value="<?php echo (int)$p['id']; ?>" <?php echo $sel; ?>>
              <?php echo (int)$p['year']; ?>-<?php echo str_pad((string)$p['month'],2,'0',STR_PAD_LEFT); ?>
            </option>
          <?php endforeach; ?>
        </select>
      </div>
      <div class="col-md-3">
        <button class="btn btn-primary">
          <i class="bi bi-funnel me-2"></i>Tampilkan
        </button>
      </div>
    </form>
  </div>
</div>

<?php
function fmt_money($x){ return 'Rp '.number_format((float)$x,0,',','.'); }
function fmt_rice($x){ return (float)$x.' kg'; }
function badge_status($s){
  $s = strtoupper((string)$s);
  if ($s==='APPROVED') return '<span class="badge text-bg-success">APPROVED</span>';
  if ($s==='SENT')     return '<span class="badge text-bg-primary">SENT</span>';
  if ($s==='REJECTED') return '<span class="badge text-bg-warning">REVISI</span>';
  if ($s==='DRAFT')    return '<span class="badge text-bg-secondary">DRAFT</span>';
  return '<span class="badge text-bg-dark">BELUM</span>';
}
?>

<div class="row g-3">
  <!-- 1) Belum mengirim -->
  <div class="col-12">
    <div class="card shadow-soft">
      <div class="card-header d-flex align-items-center justify-content-between">
        <div class="fw-semibold">Belum Mengirim Laporan</div>
        <div class="text-muted small">Total cabang: <?php echo count($unreported); ?></div>
      </div>
      <div class="card-body table-responsive">
        <table class="table align-middle mb-0">
          <thead>
            <tr>
              <th>Cabang</th>
              <th>Status</th>
              <th class="text-end">Pendapatan (Uang)</th>
              <th class="text-end">Pendapatan (Beras)</th>
              <th style="width:140px;"></th>
            </tr>
          </thead>
          <tbody>
            <?php if (empty($unreported)): ?>
              <tr><td colspan="5" class="text-muted">Semua cabang sudah mengirim laporan (atau minimal sudah dibuat).</td></tr>
            <?php else: foreach($unreported as $x): ?>
              <tr>
                <td class="fw-semibold"><?php echo html_escape($x->branch_name); ?></td>
                <td><?php echo badge_status($x->status); ?></td>
                <td class="text-end"><?php echo fmt_money($x->money); ?></td>
                <td class="text-end"><?php echo fmt_rice($x->rice); ?></td>
                <td class="text-end">
                  <a class="btn btn-sm btn-outline-secondary"
                     href="<?php echo site_url('dashboard/reports?branch_id='.$x->branch_id); ?>">
                    Lihat Filter
                  </a>
                </td>
              </tr>
            <?php endforeach; endif; ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>

  <!-- 2) SENT / REJECTED -->
  <div class="col-12">
    <div class="card shadow-soft">
      <div class="card-header d-flex align-items-center justify-content-between">
        <div class="fw-semibold">Sudah Mengirim (Belum Approve / Revisi)</div>
        <div class="text-muted small">Total cabang: <?php echo count($pending); ?></div>
      </div>
      <div class="card-body table-responsive">
        <table class="table align-middle mb-0">
          <thead>
            <tr>
              <th>Cabang</th>
              <th>Status</th>
              <th class="text-end">Pendapatan (Uang)</th>
              <th class="text-end">Pendapatan (Beras)</th>
              <th style="width:160px;"></th>
            </tr>
          </thead>
          <tbody>
            <?php if (empty($pending)): ?>
              <tr><td colspan="5" class="text-muted">Tidak ada cabang yang sedang menunggu approve / revisi pada periode ini.</td></tr>
            <?php else: foreach($pending as $x): ?>
              <tr>
                <td class="fw-semibold"><?php echo html_escape($x->branch_name); ?></td>
                <td><?php echo badge_status($x->status); ?></td>
                <td class="text-end"><?php echo fmt_money($x->money); ?></td>
                <td class="text-end"><?php echo fmt_rice($x->rice); ?></td>
                <td class="text-end">
                  <?php if (!empty($x->report_id)): ?>
                    <a class="btn btn-sm btn-primary" href="<?php echo site_url('dashboard/reports/'.$x->report_id); ?>">Buka Laporan</a>
                  <?php endif; ?>
                </td>
              </tr>
            <?php endforeach; endif; ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>

  <!-- 3) APPROVED -->
  <div class="col-12">
    <div class="card shadow-soft">
      <div class="card-header d-flex align-items-center justify-content-between">
        <div class="fw-semibold">Sudah Approved</div>
        <div class="text-muted small">Total cabang: <?php echo count($approved); ?></div>
      </div>
      <div class="card-body table-responsive">
        <table class="table align-middle mb-0">
          <thead>
            <tr>
              <th>Cabang</th>
              <th>Status</th>
              <th class="text-end">Pendapatan (Uang)</th>
              <th class="text-end">Pendapatan (Beras)</th>
              <th style="width:160px;"></th>
            </tr>
          </thead>
          <tbody>
            <?php if (empty($approved)): ?>
              <tr><td colspan="5" class="text-muted">Belum ada laporan yang approved pada periode ini.</td></tr>
            <?php else: foreach($approved as $x): ?>
              <tr>
                <td class="fw-semibold"><?php echo html_escape($x->branch_name); ?></td>
                <td><?php echo badge_status($x->status); ?></td>
                <td class="text-end"><?php echo fmt_money($x->money); ?></td>
                <td class="text-end"><?php echo fmt_rice($x->rice); ?></td>
                <td class="text-end">
                  <?php if (!empty($x->report_id)): ?>
                    <a class="btn btn-sm btn-outline-secondary" href="<?php echo site_url('dashboard/reports/'.$x->report_id); ?>">Lihat</a>
                  <?php endif; ?>
                </td>
              </tr>
            <?php endforeach; endif; ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>
</div>
