<!doctype html>
<html>
<head>
  <meta charset="utf-8">
  <style>
    body { font-family: DejaVu Sans, sans-serif; font-size: 10px; }
    .title { font-size: 14px; font-weight: bold; }
    .muted { color: #666; }
    table { width: 100%; border-collapse: collapse; margin-top: 8px; }
    th, td { border: 1px solid #ddd; padding: 5px; }
    th { background: #f4f4f4; text-align: left; }
    .right { text-align: right; }
    .section { margin-top: 12px; }
  </style>
</head>
<body>

<div class="title">Status Laporan Cabang</div>
<div class="muted">
  Periode: <b><?php echo (int)$period->year; ?>-<?php echo str_pad((string)$period->month,2,'0',STR_PAD_LEFT); ?></b>
  (<?php echo html_escape($period->start_date); ?> s/d <?php echo html_escape($period->end_date); ?>)<br>
  Dicetak: <?php echo date('Y-m-d H:i:s'); ?>
</div>

<?php
function fmt_money($x){ return 'Rp '.number_format((float)$x,0,',','.'); }
function fmt_rice($x){ return (float)$x.' kg'; }
?>

<div class="section">
  <b>1) Belum Mengirim Laporan</b>
  <table>
    <thead>
      <tr>
        <th>Cabang</th>
        <th>Status</th>
        <th class="right">Uang</th>
        <th class="right">Beras</th>
      </tr>
    </thead>
    <tbody>
      <?php if (empty($unreported)): ?>
        <tr><td colspan="4" class="muted">Tidak ada.</td></tr>
      <?php else: foreach($unreported as $x): ?>
        <tr>
          <td><?php echo html_escape($x->branch_name); ?></td>
          <td><?php echo html_escape($x->status); ?></td>
          <td class="right"><?php echo fmt_money($x->money); ?></td>
          <td class="right"><?php echo fmt_rice($x->rice); ?></td>
        </tr>
      <?php endforeach; endif; ?>
    </tbody>
  </table>
</div>

<div class="section">
  <b>2) Sudah Mengirim (Belum Approve / Revisi)</b>
  <table>
    <thead>
      <tr>
        <th>Cabang</th>
        <th>Status</th>
        <th class="right">Uang</th>
        <th class="right">Beras</th>
      </tr>
    </thead>
    <tbody>
      <?php if (empty($pending)): ?>
        <tr><td colspan="4" class="muted">Tidak ada.</td></tr>
      <?php else: foreach($pending as $x): ?>
        <tr>
          <td><?php echo html_escape($x->branch_name); ?></td>
          <td><?php echo html_escape($x->status); ?></td>
          <td class="right"><?php echo fmt_money($x->money); ?></td>
          <td class="right"><?php echo fmt_rice($x->rice); ?></td>
        </tr>
      <?php endforeach; endif; ?>
    </tbody>
  </table>
</div>

<div class="section">
  <b>3) Sudah Approved</b>
  <table>
    <thead>
      <tr>
        <th>Cabang</th>
        <th>Status</th>
        <th class="right">Uang</th>
        <th class="right">Beras</th>
      </tr>
    </thead>
    <tbody>
      <?php if (empty($approved)): ?>
        <tr><td colspan="4" class="muted">Tidak ada.</td></tr>
      <?php else: foreach($approved as $x): ?>
        <tr>
          <td><?php echo html_escape($x->branch_name); ?></td>
          <td><?php echo html_escape($x->status); ?></td>
          <td class="right"><?php echo fmt_money($x->money); ?></td>
          <td class="right"><?php echo fmt_rice($x->rice); ?></td>
        </tr>
      <?php endforeach; endif; ?>
    </tbody>
  </table>
</div>

</body>
</html>
