<div class="container-fluid">
  <div class="page-hero mb-3">
    <div>
      <h3 class="mb-1"><?php echo html_escape($title); ?></h3>
      <div class="opacity-75">Menarik data dari laporan cabang yang sudah <b>APPROVED</b>.</div>
    </div>

    <!-- EXPORT PDF -->
    <div class="d-flex gap-2 flex-wrap">
      <a class="btn btn-soft"
         href="<?php echo site_url('dashboard/reports/consolidation/pdf?year='.$year.'&month='.$month); ?>">
        <i class="bi bi-filetype-pdf me-2"></i>Export PDF
      </a>
    </div>
  </div>

  <div class="card shadow-soft mb-3">
    <div class="card-body">
      <form method="get" action="<?php echo site_url('dashboard/reports/consolidation'); ?>">
        <div class="row g-3 align-items-end">
          <div class="col-md-3">
            <label class="form-label">Tahun</label>
            <input class="form-control" name="year" value="<?php echo (int)$year; ?>">
          </div>
          <div class="col-md-3">
            <label class="form-label">Bulan</label>
            <input class="form-control" name="month" value="<?php echo (int)$month; ?>">
          </div>
          <div class="col-md-6 d-flex gap-2 flex-wrap">
            <button class="btn btn-light"><i class="bi bi-search me-2"></i>Tampilkan</button>

            <!-- EXPORT PDF (juga dekat filter biar mudah) -->
            <a class="btn btn-soft"
               href="<?php echo site_url('dashboard/reports/consolidation/pdf?year='.$year.'&month='.$month); ?>">
              <i class="bi bi-filetype-pdf me-2"></i>Export PDF
            </a>
          </div>
        </div>
      </form>
    </div>
  </div>

  <div class="card shadow-soft">
    <div class="card-body">
      <div class="table-responsive">
        <table class="table align-middle mb-0">
          <thead>
            <tr>
              <th>Cabang</th>
              <th>Total Uang</th>
              <th>Total Beras</th>
            </tr>
          </thead>
          <tbody>
            <?php if (empty($rows)): ?>
              <tr><td colspan="3" class="text-center opacity-75 py-4">Belum ada laporan APPROVED pada periode ini.</td></tr>
            <?php else: ?>
              <?php foreach($rows as $r): ?>
                <tr>
                  <td class="fw-semibold"><?php echo html_escape($r->branch_name); ?></td>
                  <td>Rp <?php echo number_format((float)$r->total_money,0,',','.'); ?></td>
                  <td><?php echo (float)$r->total_rice; ?> kg</td>
                </tr>
              <?php endforeach; ?>
              <tr>
                <td class="fw-semibold">GRAND TOTAL</td>
                <td class="fw-semibold">Rp <?php echo number_format((float)$grand_money,0,',','.'); ?></td>
                <td class="fw-semibold"><?php echo (float)$grand_rice; ?> kg</td>
              </tr>
            <?php endif; ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>
</div>
