<!doctype html>
<html>
<head>
  <meta charset="utf-8">
  <style>
    body { font-family: DejaVu Sans, sans-serif; font-size: 12px; }
    .title { font-size: 16px; font-weight: bold; }
    .muted { color: #666; }
    table { width: 100%; border-collapse: collapse; margin-top: 10px; }
    th, td { border: 1px solid #ddd; padding: 6px; }
    th { background: #f4f4f4; text-align: left; }
    .right { text-align: right; }
  </style>
</head>
<body>

  <div class="title">Konsolidasi Laporan Pusat</div>
  <div class="muted">
    Periode: <b><?php echo (int)$year; ?>-<?php echo str_pad((string)$month,2,'0',STR_PAD_LEFT); ?></b><br>
    Dicetak: <?php echo date('Y-m-d H:i:s'); ?>
  </div>

  <table>
    <thead>
      <tr>
        <th>Cabang</th>
        <th class="right">Total Uang</th>
        <th class="right">Total Beras (kg)</th>
      </tr>
    </thead>
    <tbody>
      <?php if (empty($rows)): ?>
        <tr><td colspan="3" class="muted">Belum ada laporan APPROVED.</td></tr>
      <?php else: ?>
        <?php foreach($rows as $r): ?>
          <tr>
            <td><?php echo html_escape($r->branch_name); ?></td>
            <td class="right">Rp <?php echo number_format((float)$r->total_money,0,',','.'); ?></td>
            <td class="right"><?php echo (float)$r->total_rice; ?></td>
          </tr>
        <?php endforeach; ?>
        <tr>
          <th>GRAND TOTAL</th>
          <th class="right">Rp <?php echo number_format((float)$grand_money,0,',','.'); ?></th>
          <th class="right"><?php echo (float)$grand_rice; ?></th>
        </tr>
      <?php endif; ?>
    </tbody>
  </table>

</body>
</html>
