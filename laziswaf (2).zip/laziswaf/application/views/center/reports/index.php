<?php
function qs_keep($filters, $extra = array()){
  $q = array_merge($filters, $extra);
  foreach ($q as $k=>$v) if ($v === '' || $v === null) unset($q[$k]);
  return http_build_query($q);
}
$total_pages = (int)ceil($total / max(1,$per_page));
if ($total_pages < 1) $total_pages = 1;
?>

<div class="container-fluid">
  <div class="page-hero mb-3">
    <div>
      <h3 class="mb-1"><?php echo html_escape($title); ?></h3>
      <div class="opacity-75">Total: <b><?php echo (int)$total; ?></b></div>
    </div>
    <a class="btn btn-soft" href="<?php echo site_url('dashboard/reports/consolidation'); ?>">
      <i class="bi bi-diagram-3 me-2"></i>Konsolidasi
    </a>
  </div>

  <?php if (!empty($ok)): ?><div class="alert alert-success"><?php echo $ok; ?></div><?php endif; ?>
  <?php if (!empty($err)): ?><div class="alert alert-danger"><?php echo $err; ?></div><?php endif; ?>

  <div class="card shadow-soft mb-3">
    <div class="card-body">
      <form method="get" action="<?php echo site_url('dashboard/reports'); ?>">
        <div class="row g-3">
          <div class="col-md-4">
            <label class="form-label">Cabang</label>
            <select class="form-select" name="branch_id">
              <option value="">Semua</option>
              <?php foreach($branches as $b): ?>
                <option value="<?php echo (int)$b->id; ?>" <?php echo ((string)$filters['branch_id']===(string)$b->id)?'selected':''; ?>>
                  <?php echo html_escape($b->branch_name); ?>
                </option>
              <?php endforeach; ?>
            </select>
          </div>

          <div class="col-md-2">
            <label class="form-label">Status</label>
            <select class="form-select" name="status">
              <?php foreach($statuses as $k=>$v): ?>
                <option value="<?php echo html_escape($k); ?>" <?php echo ((string)$filters['status']===(string)$k)?'selected':''; ?>>
                  <?php echo html_escape($v); ?>
                </option>
              <?php endforeach; ?>
            </select>
          </div>

          <div class="col-md-2">
            <label class="form-label">Tahun</label>
            <input class="form-control" name="year" value="<?php echo html_escape($filters['year']); ?>" placeholder="2026">
          </div>

          <div class="col-md-2">
            <label class="form-label">Bulan</label>
            <input class="form-control" name="month" value="<?php echo html_escape($filters['month']); ?>" placeholder="1..12">
          </div>

          <div class="col-md-2 d-flex align-items-end gap-2">
            <button class="btn btn-light w-100"><i class="bi bi-search me-2"></i>Filter</button>
            <a class="btn btn-soft w-100" href="<?php echo site_url('dashboard/reports'); ?>">Reset</a>
          </div>
        </div>
      </form>
    </div>
  </div>

  <div class="card shadow-soft">
    <div class="card-body">
      <div class="table-responsive">
        <table class="table align-middle mb-0">
          <thead>
            <tr>
              <th>No Laporan</th>
              <th>Cabang</th>
              <th>Periode</th>
              <th>Status</th>
              <th>Total Uang</th>
              <th>Total Beras</th>
              <th></th>
            </tr>
          </thead>
          <tbody>
            <?php if (empty($rows)): ?>
              <tr><td colspan="7" class="text-center opacity-75 py-4">Tidak ada data.</td></tr>
            <?php else: ?>
              <?php foreach($rows as $r): ?>
                <tr>
                  <td class="fw-semibold"><?php echo html_escape($r->report_no); ?></td>
                  <td><?php echo html_escape($r->branch_name); ?></td>
                  <td><?php echo (int)$r->year; ?>-<?php echo str_pad((string)$r->month,2,'0',STR_PAD_LEFT); ?></td>
                  <td><span class="badge text-bg-secondary"><?php echo html_escape($r->status); ?></span></td>
                  <td>Rp <?php echo number_format((float)$r->total_money,0,',','.'); ?></td>
                  <td><?php echo (float)$r->total_rice_kg; ?> kg</td>
                  <td class="text-end">
                    <a class="btn btn-soft btn-sm" href="<?php echo site_url('dashboard/reports/'.$r->id); ?>">
                      Detail <i class="bi bi-arrow-right ms-1"></i>
                    </a>
                  </td>
                </tr>
              <?php endforeach; ?>
            <?php endif; ?>
          </tbody>
        </table>
      </div>
    </div>

    <div class="card-footer d-flex justify-content-between align-items-center flex-wrap gap-2">
      <div class="opacity-75 small">Halaman <?php echo (int)$page; ?> / <?php echo (int)$total_pages; ?></div>
      <div class="d-flex gap-2">
        <?php
          $prev = $page - 1; $next = $page + 1;
          $base = site_url('dashboard/reports').'?';
        ?>
        <a class="btn btn-soft btn-sm <?php echo ($page<=1)?'disabled':''; ?>"
           href="<?php echo $base.qs_keep($filters, array('page'=>$prev)); ?>"><i class="bi bi-chevron-left"></i></a>
        <a class="btn btn-soft btn-sm <?php echo ($page>=$total_pages)?'disabled':''; ?>"
           href="<?php echo $base.qs_keep($filters, array('page'=>$next)); ?>"><i class="bi bi-chevron-right"></i></a>
      </div>
    </div>
  </div>
</div>
