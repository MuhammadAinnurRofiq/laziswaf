<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class PublicDashboard extends CI_Controller
{
  public function __construct()
  {
    parent::__construct();
    $this->load->helper(array('url','menu'));
  }

  public function index()
  {
    // dashboard publik tanpa login
    $data = array(
      'title' => 'Dashboard Publik',
      'role'  => 'PUBLIC',
      'user'  => (object) array(
        'full_name' => 'Pengunjung',
        'username'  => 'public'
      ),
    );

    // WAJIB: menu dari helper
    $data['menu'] = menu_public_sidebar();

    $this->load->view('layouts/app', array(
      'content' => $this->load->view('dashboard/public', $data, TRUE),
      'title'   => $data['title'],
      'menu'    => $data['menu'],
      'user'    => $data['user'],
      'role'    => $data['role']
    ));
  }
}
