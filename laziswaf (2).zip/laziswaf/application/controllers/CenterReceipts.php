<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class CenterReceipts extends MY_Controller
{
  public function __construct()
  {
    parent::__construct();
    $this->require_login();

    $role = (string)$this->session->userdata('auth_role');
    if (!in_array($role, array('ADMIN','BENDAHARA'), true)) {
      show_error('Akses ditolak', 403);
    }

    $this->load->model('Center_receipt_model');
    $this->load->helper(array('url','form'));

    // WAJIB: helper menu
    $this->load->helper('menu');
  }

  public function index()
  {
    $role = (string)$this->session->userdata('auth_role');
    $u = $this->session->userdata('auth_user');

    $filters = array(
      'scope'     => $this->input->get('scope', TRUE),     // all|branch|center
      'branch_id' => $this->input->get('branch_id', TRUE),
      'zis_type'  => $this->input->get('zis_type', TRUE),
      'status'    => $this->input->get('status', TRUE),
      'date_from' => $this->input->get('date_from', TRUE),
      'date_to'   => $this->input->get('date_to', TRUE),
      'q'         => $this->input->get('q', TRUE),
    );

    // default scope
    if (empty($filters['scope'])) $filters['scope'] = 'all';

    $per_page = 20;
    $page = (int)$this->input->get('page', TRUE);
    if ($page < 1) $page = 1;
    $offset = ($page - 1) * $per_page;

    $res = $this->Center_receipt_model->search($filters, $per_page, $offset);

    $data = array(
      'title' => 'Kuitansi (Pusat)',
      'role'  => $role,
      'user'  => (object) array(
        'full_name' => $u['full_name'] ?? 'User',
        'username'  => $u['username'] ?? 'user',
      ),

      'rows'  => $res['rows'],
      'total' => $res['total'],
      'page'  => $page,
      'per_page' => $per_page,

      'filters'  => $filters,
      'branches' => $this->Center_receipt_model->branches_active(),
      'zis_types'=> $this->Center_receipt_model->zis_types_active(),

      'scopes' => array(
        'all'    => 'Semua',
        'branch' => 'Cabang',
        'center' => 'Pusat',
      ),
      'statuses' => array(
        '' => 'Semua',
        'BRANCH_APPROVED' => 'BRANCH_APPROVED',
        'CENTER_LOCKED' => 'CENTER_LOCKED',
        'SUBMITTED' => 'SUBMITTED',
        'NEED_FIX' => 'NEED_FIX',
        'BRANCH_REJECTED' => 'BRANCH_REJECTED',
      )
    );

    // WAJIB: isi menu dari helper (ADMIN mendapat Setting + User Bendahara)
    $data['menu'] = menu_center_sidebar($role);

    $this->load->view('layouts/app', array(
      'content' => $this->load->view('center/receipts/index', $data, TRUE),
      'title'   => $data['title'],
      'menu'    => $data['menu'],
      'user'    => $data['user'],
      'role'    => $data['role']
    ));
  }

  public function export_csv()
  {
    $role = (string)$this->session->userdata('auth_role');
    if (!in_array($role, array('ADMIN','BENDAHARA'), true)) {
      show_error('Akses ditolak', 403);
    }

    $filters = array(
      'scope'     => $this->input->get('scope', TRUE),
      'branch_id' => $this->input->get('branch_id', TRUE),
      'zis_type'  => $this->input->get('zis_type', TRUE),
      'status'    => $this->input->get('status', TRUE),
      'date_from' => $this->input->get('date_from', TRUE),
      'date_to'   => $this->input->get('date_to', TRUE),
      'q'         => $this->input->get('q', TRUE),
    );

    $rows = $this->Center_receipt_model->export_rows($filters, 5000);

    $filename = 'kuitansi_'.date('Ymd_His').'.csv';
    header('Content-Type: text/csv; charset=utf-8');
    header('Content-Disposition: attachment; filename="'.$filename.'"');

    $out = fopen('php://output', 'w');

    // BOM UTF-8 agar Excel tidak berantakan
    fprintf($out, chr(0xEF).chr(0xBB).chr(0xBF));

    fputcsv($out, array(
      'receipt_no','issued_at','submission_no','zis_type',
      'applicant_name','whatsapp','branch_name','status',
      'money_amount','rice_kg','public_receipt_link'
    ));

    foreach ($rows as $r) {
      $public_link = site_url('public/receipt/'.$r['public_token']);
      fputcsv($out, array(
        $r['receipt_no'],
        $r['issued_at'],
        $r['submission_no'],
        $r['zis_type_code'],
        $r['applicant_name'],
        $r['whatsapp'],
        $r['branch_name'],
        $r['status'],
        $r['money_amount'],
        $r['rice_kg'],
        $public_link
      ));
    }

    fclose($out);
    exit;
  }
}
