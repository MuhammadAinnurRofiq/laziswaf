<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class CenterSettings extends MY_Controller
{
  public function __construct()
  {
    parent::__construct();
    $this->require_login();
    $this->require_role('ADMIN');

    $this->load->model('Setting_model');
    $this->load->helper(array('url','form','app_setting','menu'));
    $this->load->library(array('form_validation','upload'));
  }

  private function default_landing_home()
  {
    return array(
      'badge'      => 'ZISWAF • Transparan • Terstruktur',
      'hero_title' => 'Kelola ZISWAF Modern & Mudah Dilacak',
      'hero_desc'  => app_setting('landing_tagline', 'Pengelolaan ZISWAF yang modern, transparan, dan mudah dilacak.'),
      'cta_text'   => 'Masuk Dashboard',
      'cta_url'    => site_url('public'),
      'features'   => array(
        array('icon'=>'bi-search', 'title'=>'Tracking Pengajuan', 'desc'=>'Cek status tanpa login.'),
        array('icon'=>'bi-receipt', 'title'=>'Kuitansi Publik', 'desc'=>'Token publik + PDF + share WA.'),
        array('icon'=>'bi-file-earmark-text', 'title'=>'Laporan Cabang', 'desc'=>'Rekap bulanan rapi & terstruktur.'),
        array('icon'=>'bi-sliders', 'title'=>'Tarif & Kalkulator', 'desc'=>'Fitrah, Fidyah, Mal, Infaq.'),
        array('icon'=>'bi-shield-check', 'title'=>'Multi Role', 'desc'=>'Umum, Cabang, Bendahara, Admin.'),
        array('icon'=>'bi-diagram-3', 'title'=>'Alokasi Tercatat', 'desc'=>'Pembagian otomatis tercatat rapi.'),
      ),
      'videos' => array(
        array('title'=>'Panduan Pengajuan & Tracking', 'youtube'=>''),
      )
    );
  }

  public function landing()
  {
    $home = $this->Setting_model->get_json('landing_home', array());
    if (!is_array($home) || empty($home)) $home = $this->default_landing_home();

    // normalisasi
    $home = array_merge($this->default_landing_home(), $home);

    $data = array(
      'title'    => 'Setting - Halaman Utama',
      'role'     => $this->role(),
      'menu'     => app_sidebar_menu($this->role()),
      'user'     => $this->user(),
      'home'     => $home,
      'app_name' => app_setting('app_name', 'LAZISWAF'),
      'logo_url' => app_logo_url()
    );

    $this->load->view('layouts/app', array(
      'content' => $this->load->view('dashboard/settings/landing', $data, TRUE),
      'title'   => $data['title'],
      'menu'    => $data['menu'],
      'user'    => $data['user'],
      'role'    => $data['role']
    ));
  }

  public function landing_save()
  {
    if ($this->input->method(TRUE) !== 'POST') show_404();

    $badge      = trim((string)$this->input->post('badge', TRUE));
    $hero_title = trim((string)$this->input->post('hero_title', TRUE));
    $hero_desc  = trim((string)$this->input->post('hero_desc', TRUE));
    $cta_text   = trim((string)$this->input->post('cta_text', TRUE));
    $cta_url    = trim((string)$this->input->post('cta_url', TRUE));

    $features_raw = trim((string)$this->input->post('features', TRUE));
    $videos_raw   = trim((string)$this->input->post('videos', TRUE));

    $features = array();
    if ($features_raw) {
      // format: icon|judul|deskripsi per baris
      $lines = preg_split('/\r\n|\r|\n/', $features_raw);
      foreach ($lines as $ln) {
        $ln = trim($ln);
        if ($ln === '') continue;
        $parts = array_map('trim', explode('|', $ln));
        $features[] = array(
          'icon'  => $parts[0] ?? 'bi-dot',
          'title' => $parts[1] ?? '',
          'desc'  => $parts[2] ?? ''
        );
      }
    }

    $videos = array();
    if ($videos_raw) {
      // format: judul|youtube_id_or_url per baris
      $lines = preg_split('/\r\n|\r|\n/', $videos_raw);
      foreach ($lines as $ln) {
        $ln = trim($ln);
        if ($ln === '') continue;
        $parts = array_map('trim', explode('|', $ln));
        $videos[] = array(
          'title'   => $parts[0] ?? 'Video',
          'youtube' => $parts[1] ?? ''
        );
      }
    }

    $home = array(
      'badge'      => $badge,
      'hero_title' => $hero_title,
      'hero_desc'  => $hero_desc,
      'cta_text'   => $cta_text,
      'cta_url'    => $cta_url,
      'features'   => $features,
      'videos'     => $videos
    );

    // fallback minimal agar landing tidak kosong total
    $def = $this->default_landing_home();
    $home = array_merge($def, array_filter($home, function($v){ return $v !== null; }));

    $user_id = (int)($this->user()['id'] ?? 0);
    $this->Setting_model->upsert('landing_home', null, json_encode($home, JSON_UNESCAPED_UNICODE), $user_id);

    $this->session->set_flashdata('success', 'Konten Halaman Utama berhasil disimpan.');
    redirect('dashboard/settings/landing');
  }

  public function profile()
  {
    $data = array(
      'title'     => 'Setting - Profil Aplikasi',
      'role'      => $this->role(),
      'menu'      => app_sidebar_menu($this->role()),
      'user'      => $this->user(),
      'app_name'  => app_setting('app_name', 'LAZISWAF'),
      'logo_url'  => app_logo_url(),
      'logo_path' => app_setting('app_logo_path', ''),
      'footer_left_text'   => app_setting('footer_left_text',''),
      'footer_build_label' => app_setting('footer_build_label','Built with'),
      'footer_ci_text'     => app_setting('footer_ci_text','CI3'),
      'footer_bs_text'     => app_setting('footer_bs_text','Bootstrap 5'),
      'footer_note_text'   => app_setting('footer_note_text','')
    );

    $this->load->view('layouts/app', array(
      'content' => $this->load->view('dashboard/settings/profile', $data, TRUE),
      'title'   => $data['title'],
      'menu'    => $data['menu'],
      'user'    => $data['user'],
      'role'    => $data['role']
    ));
  }

  public function profile_save()
  {
    if ($this->input->method(TRUE) !== 'POST') show_404();

    $user_id = (int)($this->user()['id'] ?? 0);

    $app_name = trim((string)$this->input->post('app_name', TRUE));
    if ($app_name === '') $app_name = 'LAZISWAF';

    // upload logo opsional
    $logo_path = app_setting('app_logo_path', '');
    if (!empty($_FILES['app_logo']['name'])) {
      $upload_dir = FCPATH . 'assets/img/brand/';
      if (!is_dir($upload_dir)) @mkdir($upload_dir, 0755, true);

      $config = array(
        'upload_path'   => $upload_dir,
        'allowed_types' => 'jpg|jpeg|png|webp',
        'max_size'      => 2048, // KB
        'encrypt_name'  => TRUE
      );

      $this->upload->initialize($config);
      if (!$this->upload->do_upload('app_logo')) {
        $this->session->set_flashdata('error', $this->upload->display_errors('', ''));
        redirect('dashboard/settings/profile');
      }

      $up = $this->upload->data();
      // simpan ke database (BLOB)
      $mime = (string)($up['file_type'] ?? 'image/png');
      $blob = @file_get_contents($up['full_path']);
      if ($blob === false || $blob === null) {
        $this->session->set_flashdata('error', 'Gagal membaca file logo.');
        redirect('dashboard/settings/profile');
      }

      $this->Setting_model->upsert_asset('app_logo', $mime, $blob, $user_id);
      // versi untuk cache-busting
      $this->Setting_model->upsert('app_logo_ver', (string)time(), null, $user_id);

      // opsional: tidak perlu simpan path lagi (logo sudah di DB)
      $logo_path = '';
    }

$this->Setting_model->upsert('app_name', $app_name, null, $user_id);
    $this->Setting_model->upsert('app_logo_path', $logo_path, null, $user_id);

    // footer settings
    $footer_left_text   = trim((string)$this->input->post('footer_left_text', TRUE));
    $footer_build_label = trim((string)$this->input->post('footer_build_label', TRUE));
    $footer_ci_text     = trim((string)$this->input->post('footer_ci_text', TRUE));
    $footer_bs_text     = trim((string)$this->input->post('footer_bs_text', TRUE));
    $footer_note_text   = trim((string)$this->input->post('footer_note_text', TRUE));

    if ($footer_build_label === '') $footer_build_label = 'Built with';
    if ($footer_ci_text === '') $footer_ci_text = 'CI3';
    if ($footer_bs_text === '') $footer_bs_text = 'Bootstrap 5';

    $this->Setting_model->upsert('footer_left_text', $footer_left_text, null, $user_id);
    $this->Setting_model->upsert('footer_build_label', $footer_build_label, null, $user_id);
    $this->Setting_model->upsert('footer_ci_text', $footer_ci_text, null, $user_id);
    $this->Setting_model->upsert('footer_bs_text', $footer_bs_text, null, $user_id);
    $this->Setting_model->upsert('footer_note_text', $footer_note_text, null, $user_id);

    $this->session->set_flashdata('success', 'Profil aplikasi berhasil disimpan.');
    redirect('dashboard/settings/profile');
  }

  public function download_db()
  {
    $this->load->dbutil();
    $this->load->helper('download');

    $prefs = array(
      'format'   => 'txt', // menghasilkan file SQL
      'filename' => 'backup_laziswaf.sql'
    );

    $backup = $this->dbutil->backup($prefs);

    $name = 'backup_laziswaf_' . date('Ymd_His') . '.sql';
    force_download($name, $backup);
  }
}
