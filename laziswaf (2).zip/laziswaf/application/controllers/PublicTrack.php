<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class PublicTrack extends CI_Controller
{
  public function __construct()
  {
    parent::__construct();
    $this->load->library(array('form_validation','session'));
    $this->load->helper(array('url','form','menu'));
    $this->load->model('Public_track_model');
  }

  public function index()
  {
    $data = array(
      'title' => 'Cek Status Pengajuan',
      'role'  => 'PUBLIC',
      'user'  => (object) array('full_name'=>'Pengunjung','username'=>'public'),
      'error' => $this->session->flashdata('error'),
    );

    // WAJIB: menu dari helper
    $data['menu'] = menu_public_sidebar();

    $this->load->view('layouts/app', array(
      'content' => $this->load->view('public/track/index', $data, TRUE),
      'title'   => $data['title'],
      'menu'    => $data['menu'],
      'user'    => $data['user'],
      'role'    => $data['role']
    ));
  }

  public function check()
{
  // izinkan POST (form) dan GET (dari link pilihan)
  $method = $this->input->method(TRUE);
  if (!in_array($method, array('POST','GET'), true)) show_404();

  $submission_no = trim((string)($method==='POST'
    ? $this->input->post('submission_no', TRUE)
    : $this->input->get('submission_no', TRUE)
  ));
  $whatsapp_in = trim((string)($method==='POST'
    ? $this->input->post('whatsapp', TRUE)
    : $this->input->get('whatsapp', TRUE)
  ));

  // validasi: minimal salah satu terisi
  if ($submission_no === '' && $whatsapp_in === '') {
    $this->session->set_flashdata('error', 'Isi salah satu: Nomor Pengajuan atau WhatsApp.');
    redirect('public/track');
    return;
  }

  $whatsapp = $whatsapp_in ? $this->normalize_wa($whatsapp_in) : '';

  $sub = null;
  $list = array();

  // 1) jika nomor pengajuan ada -> ambil by nomor (WA opsional untuk verifikasi)
  if ($submission_no !== '') {
    if ($whatsapp !== '') {
      $sub = $this->Public_track_model->find_submission($submission_no, $whatsapp); // versi lama tetap dipakai utk verifikasi WA
    } else {
      $sub = $this->Public_track_model->find_by_submission_no($submission_no);
    }
  }
  // 2) jika nomor kosong tapi WA ada -> list by WA
  else if ($whatsapp !== '') {
    $list = $this->Public_track_model->list_by_whatsapp($whatsapp, 20);
    if (count($list) === 1) {
      $sub = $this->Public_track_model->find_by_submission_no($list[0]->submission_no);
      $list = array();
    }
  }

  $data = array(
    'title' => 'Hasil Tracking',
    'role'  => 'PUBLIC',
    'user'  => (object) array('full_name'=>'Pengunjung','username'=>'public'),
    'sub'   => $sub,
    'list'  => $list,
    'menu'  => menu_public_sidebar(),
  );

  $this->load->view('layouts/app', array(
    'content' => $this->load->view('public/track/result', $data, TRUE),
    'title'   => $data['title'],
    'menu'    => $data['menu'],
    'user'    => $data['user'],
    'role'    => $data['role']
  ));
}

private function normalize_wa($wa)
{
  $wa = preg_replace('/[^0-9]/', '', (string)$wa);
  if (strpos($wa, '0') === 0) $wa = '62' . substr($wa, 1);
  return $wa;
}

}
