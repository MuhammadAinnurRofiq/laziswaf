<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class CenterRates extends MY_Controller
{
  public function __construct()
  {
    parent::__construct();
    $this->require_login();

    $role = (string)$this->session->userdata('auth_role');
    if (!in_array($role, array('ADMIN','BENDAHARA'), true)) {
      show_error('Akses ditolak', 403);
    }

    $this->load->model('Rate_model');
    $this->load->helper(array('url','form','menu'));
  }

  public function index()
  {
    $u = (array)$this->session->userdata('auth_user');
    $role = (string)$this->session->userdata('auth_role');

    $data = array(
      'title' => 'Tarif & Kalkulator',
      'rows'  => $this->Rate_model->list_all(),
      'flash' => $this->session->flashdata('msg'),
      'role'  => $role,
      'user'  => (object) array(
        'full_name' => $u['full_name'] ?? 'User',
        'username'  => $u['username'] ?? 'user',
      ),
      'menu'  => function_exists('menu_center_sidebar') ? menu_center_sidebar($role) : array(),
      'types' => array(
        'FITRAH' => 'Zakat Fitrah',
        'FIDYAH' => 'Fidyah',
        'MAL'    => 'Zakat Maal'
      ),
    );

    $this->load->view('layouts/app', array(
      'content' => $this->load->view('center/rates/index', $data, TRUE),
      'title'   => $data['title'],
      'menu'    => $data['menu'],
      'user'    => $data['user'],
      'role'    => $data['role'],
    ));
  }

  public function create()
  {
    $u = (array)$this->session->userdata('auth_user');
    $role = (string)$this->session->userdata('auth_role');

    if ($this->input->method(TRUE) === 'POST') {
      $type = strtoupper(trim((string)$this->input->post('zis_type_code', TRUE)));
      $effective = (string)$this->input->post('effective_from', TRUE);

      if (!in_array($type, array('FITRAH','FIDYAH','MAL'), true) || $effective === '') {
        $this->session->set_flashdata('msg', 'Gagal: jenis & tanggal berlaku wajib diisi.');
        redirect('dashboard/rates/create');
        return;
      }

      $data = $this->_collect_post_data($type, $effective, (int)($u['id'] ?? 0));
      $this->Rate_model->create($data);

      $this->session->set_flashdata('msg', 'Berhasil menambah tarif.');
      redirect('dashboard/rates');
      return;
    }

    $data = array(
      'title' => 'Tambah Tarif',
      'row'   => null,
      'role'  => $role,
      'user'  => (object) array(
        'full_name' => $u['full_name'] ?? 'User',
        'username'  => $u['username'] ?? 'user',
      ),
      'menu'  => function_exists('menu_center_sidebar') ? menu_center_sidebar($role) : array(),
      'types' => array(
        'FITRAH' => 'Zakat Fitrah',
        'FIDYAH' => 'Fidyah',
        'MAL'    => 'Zakat Maal'
      ),
    );

    $this->load->view('layouts/app', array(
      'content' => $this->load->view('center/rates/form', $data, TRUE),
      'title'   => $data['title'],
      'menu'    => $data['menu'],
      'user'    => $data['user'],
      'role'    => $data['role'],
    ));
  }

  public function edit($id)
  {
    $row = $this->Rate_model->get($id);
    if (!$row) show_404();

    $u = (array)$this->session->userdata('auth_user');
    $role = (string)$this->session->userdata('auth_role');

    if ($this->input->method(TRUE) === 'POST') {
      $type = strtoupper(trim((string)$this->input->post('zis_type_code', TRUE)));
      $effective = (string)$this->input->post('effective_from', TRUE);

      if (!in_array($type, array('FITRAH','FIDYAH','MAL'), true) || $effective === '') {
        $this->session->set_flashdata('msg', 'Gagal: jenis & tanggal berlaku wajib diisi.');
        redirect('dashboard/rates/edit/'.$id);
        return;
      }

      $data = $this->_collect_post_data($type, $effective, (int)($row['created_by'] ?? 0));
      $this->Rate_model->update($id, $data);

      $this->session->set_flashdata('msg', 'Berhasil update tarif.');
      redirect('dashboard/rates');
      return;
    }

    $data = array(
      'title' => 'Edit Tarif',
      'row'   => $row,
      'role'  => $role,
      'user'  => (object) array(
        'full_name' => $u['full_name'] ?? 'User',
        'username'  => $u['username'] ?? 'user',
      ),
      'menu'  => function_exists('menu_center_sidebar') ? menu_center_sidebar($role) : array(),
      'types' => array(
        'FITRAH' => 'Zakat Fitrah',
        'FIDYAH' => 'Fidyah',
        'MAL'    => 'Zakat Maal'
      ),
    );

    $this->load->view('layouts/app', array(
      'content' => $this->load->view('center/rates/form', $data, TRUE),
      'title'   => $data['title'],
      'menu'    => $data['menu'],
      'user'    => $data['user'],
      'role'    => $data['role'],
    ));
  }

  public function delete($id)
  {
    if ($this->input->method(TRUE) !== 'POST') show_404();

    $this->Rate_model->delete($id);
    $this->session->set_flashdata('msg', 'Tarif dihapus.');
    redirect('dashboard/rates');
  }

  private function _collect_post_data($type, $effective, $created_by)
  {
    $num = function($v){
      $v = trim((string)$v);
      if ($v === '') return null;
      // "10.000" => "10000", "10,5" => "10.5"
      $v = str_replace('.', '', $v);
      $v = str_replace(',', '.', $v);
      return (float)$v;
    };

    $data = array(
      'zis_type_code'  => $type,
      'effective_from' => $effective,
      'kg_per_jiwa'    => null,
      'harga_per_jiwa' => null,
      'tarif_per_hari' => null,
      'nisab_amount'   => null,
      'percent'        => null,
      'notes'          => $this->input->post('notes', TRUE),
      'created_by'     => $created_by,
    );

    if ($type === 'FITRAH') {
      $data['kg_per_jiwa']    = $num($this->input->post('kg_per_jiwa', TRUE));
      $data['harga_per_jiwa'] = $num($this->input->post('harga_per_jiwa', TRUE));
    } elseif ($type === 'FIDYAH') {
      $data['tarif_per_hari'] = $num($this->input->post('tarif_per_hari', TRUE));
    } elseif ($type === 'MAL') {
      $data['nisab_amount'] = $num($this->input->post('nisab_amount', TRUE));
      $data['percent']      = $num($this->input->post('percent', TRUE));
      if ($data['percent'] === null) $data['percent'] = 2.5;
    }

    return $data;
  }
}
