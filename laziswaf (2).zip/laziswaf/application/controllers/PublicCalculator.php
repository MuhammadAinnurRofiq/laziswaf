<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class PublicCalculator extends CI_Controller
{
  public function __construct()
  {
    parent::__construct();

    $this->load->helper(array('url','form','menu'));
    $this->load->library('session');
    $this->load->model('Rate_model');
  }

  public function index()
  {
    redirect('public/calculator/fitrah');
  }

  public function fitrah()
{
  // Rate_model->get_current() return OBJECT (row()),
  // sedangkan view kalkulator memakai array (mis. $rate['kg_per_jiwa']).
  // Jadi kita cast dulu agar aman.
  $rate = (array) $this->Rate_model->get_current('FITRAH');

  // pastikan key ada agar view tidak notice
  $rate['effective_from'] = $rate['effective_from'] ?? null;
  $rate['kg_per_jiwa']    = $rate['kg_per_jiwa'] ?? 2.5;
  $rate['harga_per_jiwa'] = $rate['harga_per_jiwa'] ?? 0;

  $data = array(
    'title' => 'Kalkulator Zakat Fitrah',
    'rate'  => $rate
  );

  $this->render('public/calculator/fitrah', $data);
}

public function fidyah()
{
  $rate = (array) $this->Rate_model->get_current('FIDYAH');

  $rate['effective_from'] = $rate['effective_from'] ?? null;
  $rate['tarif_per_hari'] = $rate['tarif_per_hari'] ?? 0;

  $data = array(
    'title' => 'Kalkulator Fidyah',
    'rate'  => $rate
  );

  $this->render('public/calculator/fidyah', $data);
}

public function mal()
{
  $rate = (array) $this->Rate_model->get_current('MAL');

  $rate['effective_from'] = $rate['effective_from'] ?? null;
  $rate['nisab_amount']   = $rate['nisab_amount'] ?? 0;
  $rate['percent']        = $rate['percent'] ?? 2.5;

  $data = array(
    'title' => 'Kalkulator Zakat Maal',
    'rate'  => $rate
  );

  $this->render('public/calculator/mal', $data);
}


  private function render($view, $data)
  {
    // Sidebar menu publik
    $menu = function_exists('menu_public_sidebar') ? menu_public_sidebar() : array();

    // User publik dummy untuk layout/app
    $user = (object) array(
      'full_name' => 'Publik',
      'username'  => 'public'
    );

    $role = 'PUBLIC';

    $this->load->view('layouts/app', array(
      'content' => $this->load->view($view, $data, TRUE),
      'title'   => $data['title'] ?? 'Kalkulator',
      'menu'    => $menu,
      'user'    => $user,
      'role'    => $role
    ));
  }
}
