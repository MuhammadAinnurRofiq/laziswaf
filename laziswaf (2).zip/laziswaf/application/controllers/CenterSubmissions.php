<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class CenterSubmissions extends MY_Controller
{
  public function __construct()
  {
    parent::__construct();
    $this->require_login();

    // hanya ADMIN / BENDAHARA
    $role = (string)$this->session->userdata('auth_role');
    if (!in_array($role, array('ADMIN','BENDAHARA'), true)) show_error('Akses ditolak', 403);

    $this->load->model('Center_submission_model');
    $this->load->helper(array('url','form'));

    // WAJIB: helper menu
    $this->load->helper('menu');
  }

  public function index()
  {
    $role = (string)$this->session->userdata('auth_role');
    $u = $this->session->userdata('auth_user');

    // GET filters
    $filters = array(
      'branch_id' => $this->input->get('branch_id', TRUE),
      'zis_type'  => $this->input->get('zis_type', TRUE),
      'status'    => $this->input->get('status', TRUE),
      'date_from' => $this->input->get('date_from', TRUE),
      'date_to'   => $this->input->get('date_to', TRUE),
      'q'         => $this->input->get('q', TRUE),
    );

    // pagination simple
    $per_page = 20;
    $page = (int)$this->input->get('page', TRUE);
    if ($page < 1) $page = 1;
    $offset = ($page - 1) * $per_page;

    $res = $this->Center_submission_model->search($filters, $per_page, $offset);

    $branches  = $this->Center_submission_model->branches_active();
    $zis_types = $this->Center_submission_model->zis_types_active();

    $data = array(
      'title' => 'Monitor Pengajuan (Pusat)',
      'role'  => $role,
      'user'  => (object) array(
        'full_name' => $u['full_name'] ?? 'User',
        'username'  => $u['username'] ?? 'user',
      ),

      'rows'  => $res['rows'],
      'total' => $res['total'],
      'page'  => $page,
      'per_page' => $per_page,

      'filters'  => $filters,
      'branches' => $branches,
      'zis_types'=> $zis_types,

      'statuses' => array(
        '' => 'Semua',
        'SUBMITTED' => 'SUBMITTED',
        'NEED_FIX' => 'NEED_FIX',
        'BRANCH_APPROVED' => 'BRANCH_APPROVED',
        'BRANCH_REJECTED' => 'BRANCH_REJECTED',
        'CENTER_LOCKED' => 'CENTER_LOCKED',
      )
    );

    // WAJIB: isi menu dari helper (ADMIN mendapat Setting + User Bendahara)
    $data['menu'] = menu_center_sidebar($role);

    $this->load->view('layouts/app', array(
      'content' => $this->load->view('center/submissions/index', $data, TRUE),
      'title'   => $data['title'],
      'menu'    => $data['menu'],
      'user'    => $data['user'],
      'role'    => $data['role']
    ));
  }


  public function delete($id)
  {
    $role = (string)$this->session->userdata('auth_role');
    $u = (array)$this->session->userdata('auth_user');

    $id = (int)$id;
    $detail = $this->Center_submission_model->find_detail($id);
    if (!$detail) show_404();

    $sub = $detail['sub'];

    // Hanya transaksi yang sudah disetujui cabang / terkunci pusat
    if (!in_array($sub->status, array('BRANCH_APPROVED','CENTER_LOCKED'), true)) {
      $this->session->set_flashdata('err', 'Tidak bisa menghapus: status pengajuan belum APPROVED.');
      redirect('dashboard/submissions/'.$id);
      return;
    }

    $reason = trim((string)$this->input->post('reason', TRUE));
    if ($reason === '') $reason = 'Dibatalkan oleh pusat.';

    $actor_id = (int)($u['id'] ?? 0);
    $ok = $this->Center_submission_model->void_transaction($id, $actor_id, $reason);

    if ($ok) $this->session->set_flashdata('ok', 'Transaksi berhasil dibatalkan (VOID). Kuitansi publik tetap bisa dibuka dan akan menampilkan peringatan.');
    else $this->session->set_flashdata('err', 'Gagal membatalkan transaksi.');

    redirect('dashboard/submissions/'.$id);
  }


  public function show($id)
  {
    $role = (string)$this->session->userdata('auth_role');
    $u = $this->session->userdata('auth_user');

    $detail = $this->Center_submission_model->find_detail((int)$id);
    if (!$detail) show_404();

    $data = array(
      'title' => 'Detail Pengajuan (Pusat)',
      'role'  => $role,
      'user'  => (object) array(
        'full_name' => $u['full_name'] ?? 'User',
        'username'  => $u['username'] ?? 'user',
      ),

      'sub'    => $detail['sub'],
      'people' => $detail['people'],
      'logs'   => $detail['logs'],
    );

    // WAJIB: isi menu dari helper (ADMIN mendapat Setting + User Bendahara)
    $data['menu'] = menu_center_sidebar($role);

    $this->load->view('layouts/app', array(
      'content' => $this->load->view('center/submissions/show', $data, TRUE),
      'title'   => $data['title'],
      'menu'    => $data['menu'],
      'user'    => $data['user'],
      'role'    => $data['role']
    ));
  }
}
