<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Auth extends CI_Controller
{
  public function __construct()
  {
    parent::__construct();

    // Pastikan library & model yang dipakai tersedia
    $this->load->library(array('Auth_lib', 'form_validation', 'session'));
    $this->load->model('User_model');
  }

  public function login()
  {
    // Kalau sudah login, arahkan sesuai role
    if ($this->auth_lib->is_logged_in()) {
      $role = $this->session->userdata('auth_role');
      $this->_redirect_by_role($role);
      return;
    }

    $data = array();
    $data['error'] = null;
    $data['title'] = 'Login';

    if ($this->input->method(TRUE) === 'POST') {

      $this->form_validation->set_rules('username','Username','required|min_length[3]|max_length[50]');
      $this->form_validation->set_rules('password','Password','required|min_length[6]');

      if ($this->form_validation->run()) {

        $username = trim($this->input->post('username', TRUE));
        $password = (string)$this->input->post('password', TRUE);

        $u = $this->User_model->find_by_username($username);

        if ($u && (int)$u->is_active === 1 && password_verify($password, $u->password_hash)) {

          // roles bisa berupa array role code (contoh: ['CABANG'])
          $roles = $this->User_model->get_user_roles($u->id);

          // Tetap panggil auth_lib agar flow Anda tidak berubah
          $this->auth_lib->login($u, $roles);

          // === WAJIB untuk modul Branch (MY_Controller) ===
          // Set session yang dibaca oleh MY_Controller: auth_user & auth_role
          $primary_role = $this->_pick_primary_role($roles);

          $this->session->set_userdata('auth_user', array(
            'id'        => (int)$u->id,
            'username'  => (string)$u->username,
            'full_name' => (string)$u->full_name,
            'branch_id' => $u->branch_id ? (int)$u->branch_id : null,
          ));

          // Simpan role utama (string) agar simple: CABANG / BENDAHARA / ADMIN
          $this->session->set_userdata('auth_role', $primary_role);

          $this->User_model->update_last_login($u->id);

          // Redirect sesuai role
          $this->_redirect_by_role($primary_role);
          return;
        }

        $data['error'] = 'Username atau password salah / akun nonaktif.';
      }
    }

    $this->load->view('layouts/auth', array(
      'content' => $this->load->view('auth/login', $data, TRUE),
      'title'   => 'Login'
    ));
  }

  public function register()
  {
    show_404(); // ditutup total
  }

  public function logout()
  {
    $this->auth_lib->logout();

    // bersihkan session yang kita pakai di MY_Controller
    $this->session->unset_userdata('auth_user');
    $this->session->unset_userdata('auth_role');

    redirect('login');
  }

  // =========================
  // Helpers
  // =========================

  private function _redirect_by_role($role)
  {
    // role bisa string atau array
    if (is_array($role)) $role = $this->_pick_primary_role($role);

    $role = (string)$role;

    if ($role === 'CABANG') {
      redirect('branch');
      return;
    }

    // ADMIN / BENDAHARA / lainnya -> langsung ke monitor
    redirect('dashboard/submissions');
  }

  private function _pick_primary_role($roles)
  {
    // roles dari User_model->get_user_roles($id) biasanya array:
    // mis: ['CABANG'] atau ['ADMIN','BENDAHARA'] dll.
    if (!is_array($roles)) return (string)$roles;

    // prioritas tertinggi
    $priority = array('ADMIN', 'BENDAHARA', 'CABANG');

    foreach ($priority as $p) {
      if (in_array($p, $roles, true)) return $p;
    }

    // fallback
    return isset($roles[0]) ? (string)$roles[0] : 'CABANG';
  }
}
