<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Submissions extends MY_Controller
{
  private $allowed = array('fitrah','mal','fidyah','infaq');

  public function __construct()
  {
    parent::__construct();
    $this->require_role('CABANG');

    $this->load->model('Branch_submission_model');
    $this->load->model('Running_number_model');
    $this->load->model('Rate_model');
    $this->load->model('Submission_model');

    $this->load->library(array('form_validation','session'));
    $this->load->helper(array('url','form'));

    // menu helper
    $this->load->helper('menu');
  }

  /**
   * Cabang bisa input pengajuan untuk membantu donatur.
   * branch_id dikunci ke cabang user yang login.
   * URL: /branch/submissions/create/{fitrah|mal|fidyah|infaq}
   */
  public function create($type = 'fitrah')
  {
    $type = strtolower($type);
    if (!in_array($type, $this->allowed, true)) show_404();

    $u = $this->user();
    $branch_id = (int)($u['branch_id'] ?? 0);
    if ($branch_id <= 0) show_error('Akun cabang belum terhubung ke branch_id.', 500);

    $zis_code = strtoupper($type);
    $rate = $this->Rate_model->get_current($zis_code);

    $b = $this->db->get_where('mst_branches', array('id' => $branch_id), 1)->row();
    $branch_name = $b ? (string)$b->branch_name : ('Cabang #'.$branch_id);

    $data = array(
      'title' => 'Input Pengajuan ' . $this->label($zis_code),
      'role'  => 'CABANG',
      'user'  => (object) array(
        'full_name' => $u['full_name'] ?? 'Cabang',
        'username'  => $u['username'] ?? 'cabang'
      ),

      'type'     => $type,
      'zis_code' => $zis_code,
      'rate'     => $rate,
      'methods'  => $this->Rate_model->get_payment_methods(),
      'branches' => array(),
      'error'    => null,

      // kunci cabang
      'fixed_branch_id'   => $branch_id,
      'fixed_branch_name' => $branch_name,
      'fixed_branch_note' => 'Dikunci otomatis ke cabang Anda (input oleh petugas cabang).',

      // action form diarahkan ke endpoint cabang
      'form_action' => site_url('branch/submissions/store'),
      'menu' => menu_branch_sidebar(),
    );

    $this->load->view('layouts/app', array(
      'content' => $this->load->view('public/submission/form', $data, TRUE),
      'title'   => $data['title'],
      'menu'    => $data['menu'],
      'user'    => $data['user'],
      'role'    => $data['role']
    ));
  }

  /**
   * Simpan pengajuan dari cabang (branch_id otomatis dari session user cabang)
   * POST: /branch/submissions/store
   */
  public function store()
  {
    if ($this->input->method(TRUE) !== 'POST') show_404();

    $type = strtolower($this->input->post('type', TRUE));
    if (!in_array($type, $this->allowed, true)) show_404();

    $u = $this->user();
    $branch_id = (int)($u['branch_id'] ?? 0);
    if ($branch_id <= 0) show_error('Akun cabang belum terhubung ke branch_id.', 500);

    $zis_code = strtoupper($type);

    // rules umum
    $this->form_validation->set_rules('applicant_name','Nama Pengaju','required|min_length[3]|max_length[120]');
    $this->form_validation->set_rules('whatsapp','No WhatsApp','required|min_length[8]|max_length[30]');

    // rules per jenis
    if ($type === 'fitrah') {
      $this->form_validation->set_rules('jiwa_count','Jumlah Jiwa','required|integer|greater_than[0]');
      $this->form_validation->set_rules('pay_method_id','Metode Pembayaran','required|integer');
    } elseif ($type === 'fidyah') {
      $this->form_validation->set_rules('jiwa_count','Jumlah Jiwa','required|integer|greater_than[0]');
      $this->form_validation->set_rules('fidyah_days','Jumlah Hari','required|integer|greater_than[0]');
    } else {
      $this->form_validation->set_rules('amount_money','Nominal','required|numeric|greater_than[0]');
    }

    if (!$this->form_validation->run()) {
      return $this->create($type);
    }

    $applicant = $this->input->post('applicant_name', TRUE);
    $wa = $this->normalize_wa($this->input->post('whatsapp', TRUE));

    $rate = $this->Rate_model->get_current($zis_code);
    $snapshot = $rate ? json_encode($rate, JSON_UNESCAPED_UNICODE) : null;

    $submission_no = $this->Running_number_model->next('SUBMISSION_NO');
    if (!$submission_no) {
      show_error('Gagal membuat nomor pengajuan. Coba ulang.', 500);
      return;
    }

    $data = array(
      'submission_no' => $submission_no,
      'source' => 'BRANCH',
      'branch_id' => $branch_id,
      'zis_type_code' => $zis_code,
      'applicant_name' => $applicant,
      'whatsapp' => $wa,
      'rate_snapshot_json' => $snapshot,
      'status' => 'SUBMITTED',
      'submitted_at' => date('Y-m-d H:i:s'),
      'created_by' => (int)($u['id'] ?? 0)
    );

    $people = array();

    if ($type === 'fitrah') {
      $jiwa = (int)$this->input->post('jiwa_count', TRUE);
      $pay_method_id = (int)$this->input->post('pay_method_id', TRUE);

      $data['jiwa_count'] = $jiwa;
      $data['pay_method_id'] = $pay_method_id;

      $kg_per_jiwa = $rate && $rate->kg_per_jiwa ? (float)$rate->kg_per_jiwa : 2.5;
      $harga_per_jiwa = $rate && $rate->harga_per_jiwa ? (float)$rate->harga_per_jiwa : 0;

      $method = $this->db->get_where('mst_payment_methods', array('id'=>$pay_method_id), 1)->row();
      $method_code = $method ? $method->code : 'CASH';

      if ($method_code === 'RICE') {
        $data['fitrah_total_kg'] = $kg_per_jiwa * $jiwa;
        $data['fitrah_total_money'] = null;
      } else {
        $data['fitrah_total_money'] = $harga_per_jiwa * $jiwa;
        $data['fitrah_total_kg'] = null;
      }

      $people_text = (string)$this->input->post('people_text', TRUE);
      if ($people_text !== '') {
        $lines = preg_split("/\r\n|\n|\r/", $people_text);
        foreach ($lines as $ln) {
          $nm = trim($ln);
          if ($nm !== '') $people[] = $nm;
        }
      }
    } elseif ($type === 'fidyah') {
      $jiwa = (int)$this->input->post('jiwa_count', TRUE);
      if ($jiwa <= 0) $jiwa = 1;

      $days = (int)$this->input->post('fidyah_days', TRUE);
      $tarif = $rate && $rate->tarif_per_hari ? (float)$rate->tarif_per_hari : 0;

      $data['jiwa_count'] = $jiwa;
      $data['fidyah_days'] = $days;
      $data['tarif_per_hari_snapshot'] = $tarif;
      $data['amount_money'] = $tarif * $days * $jiwa;
    } else {
      $amt = (float)$this->input->post('amount_money', TRUE);
      $data['amount_money'] = $amt;
    }

    $id = $this->Submission_model->insert_submission($data, $people);
if (!$id) {
  show_error('Gagal menyimpan pengajuan. Coba ulang.', 500);
  return;
}

/**
 * AUTO-APPROVE untuk input yang dibuat oleh petugas cabang
 * (tanpa perlu approve manual di inbox)
 */
$receipt_no = $this->Running_number_model->next('RECEIPT_NO');
if (!$receipt_no) {
  // fallback: tetap tersimpan, tapi belum approve
  $this->session->set_flashdata('msg', 'Pengajuan tersimpan, tapi gagal membuat nomor kuitansi (belum ter-approve).');
  redirect('branch/submissions/'.$id);
  return;
}

$res = $this->Branch_submission_model->approve_generate_all($id, $branch_id, (int)($u['id'] ?? 0), $receipt_no);

if (!empty($res['ok'])) {
  // cari ID kuitansi untuk redirect ke halaman kuitansi cabang
  $q = $this->db->select('id')->get_where('trx_receipts', array('public_token' => $res['token']), 1)->row();

  $this->session->set_flashdata('msg', 'Pengajuan otomatis ter-approve. Kuitansi terbit.');

  if ($q && !empty($q->id)) {
    redirect('branch/receipts/'.$q->id);
    return;
  }

  // fallback kalau tidak ketemu id kuitansi
  redirect('public/receipt/'.rawurlencode($res['token']));
  return;
}

// kalau gagal approve, tetap redirect ke detail pengajuan supaya bisa di-approve manual
$this->session->set_flashdata('msg', 'Pengajuan tersimpan, tapi auto-approve gagal: '.$res['msg']);
redirect('branch/submissions/'.$id);

  }

  public function success($submission_no)
  {
    $u = $this->user();
    $data = array(
      'title' => 'Pengajuan Berhasil',
      'role'  => 'CABANG',
      'user'  => (object) array(
        'full_name' => $u['full_name'] ?? 'Cabang',
        'username'  => $u['username'] ?? 'cabang'
      ),
      'submission_no' => $submission_no,
      'menu' => menu_branch_sidebar(),
    );

    $this->load->view('layouts/app', array(
      'content' => $this->load->view('public/submission/success', $data, TRUE),
      'title'   => $data['title'],
      'menu'    => $data['menu'],
      'user'    => $data['user'],
      'role'    => $data['role']
    ));
  }

  private function normalize_wa($wa)
  {
    $wa = preg_replace('/[^0-9]/', '', (string)$wa);
    if (strpos($wa, '0') === 0) $wa = '62' . substr($wa, 1);
    return $wa;
  }

  private function label($zis_code)
  {
    switch ($zis_code) {
      case 'FITRAH': return 'Zakat Fitrah';
      case 'MAL': return 'Zakat Mal';
      case 'FIDYAH': return 'Fidyah';
      case 'INFAQ': return 'Infaq';
      default: return $zis_code;
    }
  }

  // supaya /branch/submissions tidak 404
  public function index()
  {
    return $this->inbox();
  }

  public function inbox()
  {
    $u = $this->user();
    $branch_id = (int)$u['branch_id'];

    $rows = $this->Branch_submission_model->inbox($branch_id);

    $data = array(
      'title' => 'Inbox Pengajuan',
      'role'  => 'CABANG',
      'user'  => (object) array(
        'full_name' => $u['full_name'] ?? 'Cabang',
        'username'  => $u['username'] ?? 'cabang'
      ),
      'rows'  => $rows,
      'menu'  => menu_branch_sidebar(),
    );

    $this->load->view('layouts/app', array(
      'content' => $this->load->view('branch/submissions/inbox', $data, TRUE),
      'title'   => $data['title'],
      'menu'    => $data['menu'],
      'user'    => $data['user'],
      'role'    => $data['role']
    ));
  }

  public function history()
  {
    $u = $this->user();
    $branch_id = (int)$u['branch_id'];

    $rows = $this->Branch_submission_model->history($branch_id);

    $data = array(
      'title' => 'Riwayat Pengajuan',
      'role'  => 'CABANG',
      'user'  => (object) array(
        'full_name' => $u['full_name'] ?? 'Cabang',
        'username'  => $u['username'] ?? 'cabang'
      ),
      'rows'  => $rows,
      'menu'  => menu_branch_sidebar(),
    );

    $this->load->view('layouts/app', array(
      'content' => $this->load->view('branch/submissions/history', $data, TRUE),
      'title'   => $data['title'],
      'menu'    => $data['menu'],
      'user'    => $data['user'],
      'role'    => $data['role']
    ));
  }

  public function expired()
  {
    $u = $this->user();
    $branch_id = (int)$u['branch_id'];

    $rows = $this->Branch_submission_model->list_expired_manage($branch_id);

    $data = array(
      'title' => 'Expired & Hapus Pengajuan Publik',
      'role'  => 'CABANG',
      'user'  => (object) array(
        'full_name' => $u['full_name'] ?? 'Cabang',
        'username'  => $u['username'] ?? 'cabang'
      ),
      'rows'  => $rows,
      'menu'  => menu_branch_sidebar(),
      'msg'   => $this->session->flashdata('msg'),
    );

    $this->load->view('layouts/app', array(
      'content' => $this->load->view('branch/submissions/expired', $data, TRUE),
      'title'   => $data['title'],
      'menu'    => $data['menu'],
      'user'    => $data['user'],
      'role'    => $data['role']
    ));
  }

  public function do_expire($id)
  {
    if ($this->input->method(TRUE) !== 'POST') show_404();

    $u = $this->user();
    $branch_id = (int)$u['branch_id'];
    $actor_id  = (int)($u['id'] ?? 0);

    $res = $this->Branch_submission_model->mark_expired((int)$id, $branch_id, $actor_id);
    $this->session->set_flashdata('msg', $res['ok'] ? $res['msg'] : ('Gagal: '.$res['msg']));
    redirect('branch/submissions/expired');
  }

  public function do_delete($id)
  {
    if ($this->input->method(TRUE) !== 'POST') show_404();

    $u = $this->user();
    $branch_id = (int)$u['branch_id'];
    $actor_id  = (int)($u['id'] ?? 0);

    $res = $this->Branch_submission_model->soft_delete_submission((int)$id, $branch_id, $actor_id);
    $this->session->set_flashdata('msg', $res['ok'] ? $res['msg'] : ('Gagal: '.$res['msg']));
    redirect('branch/submissions/expired');
  }


  public function show($id)
  {
    $u = $this->user();
    $branch_id = (int)$u['branch_id'];

    $detail = $this->Branch_submission_model->get_detail($id, $branch_id);
    if (!$detail) show_404();

    $data = array(
      'title'   => 'Detail Pengajuan',
      'role'    => 'CABANG',
      'user'    => (object) array(
        'full_name' => $u['full_name'] ?? 'Cabang',
        'username'  => $u['username'] ?? 'cabang'
      ),
      'sub'     => $detail['sub'],
      'people'  => $detail['people'],
      'receipt' => $detail['receipt'],
      'flash'   => $this->session->flashdata('msg'),
      'menu'    => menu_branch_sidebar(),
    );

    $this->load->view('layouts/app', array(
      'content' => $this->load->view('branch/submissions/show', $data, TRUE),
      'title'   => $data['title'],
      'menu'    => $data['menu'],
      'user'    => $data['user'],
      'role'    => $data['role']
    ));
  }

  public function approve($id)
  {
    if ($this->input->method(TRUE) !== 'POST') show_404();

    $u = $this->user();
    $branch_id = (int)$u['branch_id'];
    $actor_id  = (int)$u['id'];

    $receipt_no = $this->Running_number_model->next('RECEIPT_NO');
    if (!$receipt_no) show_error('Gagal membuat nomor kuitansi', 500);

    $res = $this->Branch_submission_model->approve_generate_all($id, $branch_id, $actor_id, $receipt_no);

    $this->session->set_flashdata('msg', $res['ok'] ? 'Approved! Kuitansi terbit.' : ('Gagal: '.$res['msg']));
    redirect('branch/submissions/'.$id); // route (:num) -> show($1)
  }

  public function reject($id)
  {
    if ($this->input->method(TRUE) !== 'POST') show_404();

    $note = $this->input->post('note', TRUE);
    $u = $this->user();

    $res = $this->Branch_submission_model->reject($id, (int)$u['branch_id'], (int)$u['id'], $note);

    $this->session->set_flashdata('msg', $res['ok'] ? 'Rejected.' : ('Gagal: '.$res['msg']));
    redirect('branch/submissions/'.$id);
  }

  public function needfix($id)
  {
    if ($this->input->method(TRUE) !== 'POST') show_404();

    $note = $this->input->post('note', TRUE);
    $u = $this->user();

    $res = $this->Branch_submission_model->needfix($id, (int)$u['branch_id'], (int)$u['id'], $note);

    $this->session->set_flashdata('msg', $res['ok'] ? 'Ditandai NEED_FIX.' : ('Gagal: '.$res['msg']));
    redirect('branch/submissions/'.$id);
  }
}
