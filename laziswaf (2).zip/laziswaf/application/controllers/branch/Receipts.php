<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Receipts extends MY_Controller
{
  public function __construct()
  {
    parent::__construct();
    $this->require_role('CABANG');

    $this->load->model('Receipt_model');

    // WAJIB: helper menu
    $this->load->helper('menu');
  }

  public function index()
  {
    $u = $this->user();
    $branch_id = (int)$u['branch_id'];

    $rows = $this->Receipt_model->list_by_branch($branch_id);

    $data = array(
      'title' => 'Daftar Kuitansi',
      'role'  => 'CABANG',
      'user'  => (object) array(
        'full_name' => $u['full_name'] ?? 'Cabang',
        'username'  => $u['username'] ?? 'cabang'
      ),
      'rows'  => $rows
    );

    // WAJIB: isi menu dari helper
    $data['menu'] = menu_branch_sidebar();

    $this->load->view('layouts/app', array(
      'content' => $this->load->view('branch/receipts/index', $data, TRUE),
      'title'   => $data['title'],
      'menu'    => $data['menu'],
      'user'    => $data['user'],
      'role'    => $data['role']
    ));
  }

  public function show($id)
{
  $rec = $this->Receipt_model->find_by_id($id);
  if (!$rec) show_404();

  // ambil detail lengkap lewat model publik (join submissions + branch + allocations + people)
  $this->load->model('Public_receipt_model');
  $pack = $this->Public_receipt_model->find_by_token($rec->public_token);
  if (!$pack) show_404();

  $u = $this->user();

  $r = $pack['row'];
  $people = $pack['people'];
  $public_link = site_url('public/receipt/'.$r->public_token);

  $data = array(
    'title'       => 'Detail Kuitansi',
    'role'        => 'CABANG',
    'user'        => (object) array(
      'full_name' => $u['full_name'] ?? 'Cabang',
      'username'  => $u['username'] ?? 'cabang'
    ),
    'r'           => $r,
    'people'      => $people,
    'public_link' => $public_link,
  );

  $data['menu'] = menu_branch_sidebar();

  $this->load->view('layouts/app', array(
    'content' => $this->load->view('branch/receipts/show', $data, TRUE),
    'title'   => $data['title'],
    'menu'    => $data['menu'],
    'user'    => $data['user'],
    'role'    => $data['role']
  ));
}

}
