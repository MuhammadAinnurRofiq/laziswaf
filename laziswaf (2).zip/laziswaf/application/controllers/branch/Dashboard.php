<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Dashboard extends MY_Controller
{
  public function __construct()
  {
    parent::__construct();
    $this->require_role('CABANG');

    $this->load->model('Branch_submission_model');

    // WAJIB: helper menu
    $this->load->helper('menu');
  }

  public function index()
{
  $u = $this->user();
  $branch_id = (int)$u['branch_id'];

  $inbox = $this->Branch_submission_model->inbox($branch_id);

  // filter periode (default: bulan ini)
  $range = (string)$this->input->get('range', TRUE); // 'month' | 'all'
  $year  = (int)($this->input->get('year', TRUE) ?: date('Y'));
  $month = (int)($this->input->get('month', TRUE) ?: date('n'));

  $summary = null;
  if ($range === 'all') {
    $summary = $this->Branch_submission_model->dashboard_summary($branch_id, null, null);
  } else {
    $summary = $this->Branch_submission_model->dashboard_summary($branch_id, $year, $month);
  }

  $data = array(
    'title' => 'Dashboard Cabang',
    'role'  => 'CABANG',
    'user'  => (object) array(
      'full_name' => $u['full_name'] ?? 'Cabang',
      'username'  => $u['username'] ?? 'cabang'
    ),
    'inbox_count' => count($inbox),
    'summary'     => $summary,
    'range'       => $range ?: 'month',
    'year'        => $year,
    'month'       => $month,
  );

  $data['menu'] = menu_branch_sidebar();

  $this->load->view('layouts/app', array(
    'content' => $this->load->view('branch/dashboard', $data, TRUE),
    'title'   => $data['title'],
    'menu'    => $data['menu'],
    'user'    => $data['user'],
    'role'    => $data['role']
  ));
}

}
