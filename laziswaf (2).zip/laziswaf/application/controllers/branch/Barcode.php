<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Barcode extends MY_Controller
{
  public function __construct()
  {
    parent::__construct();
    $this->require_role('CABANG');
    $this->load->helper(array('url','menu'));
  }

  public function index()
  {
    $u = $this->user();
    $branch_id = (int)($u['branch_id'] ?? 0);
    if ($branch_id <= 0) show_error('Akun cabang belum terhubung ke branch_id.', 500);

    $b = $this->db->get_where('mst_branches', array('id'=>$branch_id), 1)->row();
    if (!$b) show_error('Data cabang tidak ditemukan.', 404);

    $scan_url = site_url('public/scan/'.$b->public_token);

    $data = array(
      'title'    => 'Cetak QR Cabang',
      'role'     => 'CABANG',
      'user'     => (object) array(
        'full_name' => $u['full_name'] ?? 'Cabang',
        'username'  => $u['username'] ?? 'cabang'
      ),
      'branch'   => $b,
      'scan_url' => $scan_url,
      'menu'     => menu_branch_sidebar(),
    );

    $this->load->view('layouts/app', array(
      'content' => $this->load->view('branch/barcode/index', $data, TRUE),
      'title'   => $data['title'],
      'menu'    => $data['menu'],
      'user'    => $data['user'],
      'role'    => $data['role'],
    ));
  }
}
