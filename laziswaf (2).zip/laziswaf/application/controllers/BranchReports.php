<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class BranchReports extends MY_Controller
{
  public function __construct()
  {
    parent::__construct();
    $this->require_login();

    $role = (string)$this->session->userdata('auth_role');
    if ($role !== 'CABANG') show_error('Akses ditolak', 403);

    $this->load->model('Branch_report_model');
    $this->load->helper(array('url','form'));

    // WAJIB: helper menu
    $this->load->helper('menu');

    // WAJIB: Pdf lib
    $this->load->library('Pdf_lib');
  }

  public function index()
  {
    // pastikan model ter-load (sesuai perintah)
    $this->load->model('Branch_report_model');

    $u = $this->session->userdata('auth_user');
    $branch_id = (int)($u['branch_id'] ?? 0);

    $data = array(
      'title' => 'Laporan Cabang',
      'role'  => 'CABANG',
      'user'  => (object) array(
        'full_name' => $u['full_name'] ?? 'User',
        'username'  => $u['username'] ?? 'user'
      ),
      'rows'  => $this->Branch_report_model->list_by_branch($branch_id),
      'ok'    => $this->session->flashdata('ok'),
      'err'   => $this->session->flashdata('err'),
    );

    // === SESUAI PERINTAH ===
    $data['periods'] = $this->Branch_report_model->periods_list(24);
    $data['selected_period_id'] = (int)$this->input->get('period_id', TRUE);
    // =======================

    $data['menu'] = menu_branch_sidebar();

    $this->load->view('layouts/app', array(
      'content' => $this->load->view('branch/reports/index', $data, TRUE),
      'title'   => $data['title'],
      'menu'    => $data['menu'],
      'user'    => $data['user'],
      'role'    => $data['role']
    ));
  }

  public function create()
  {
    $u = $this->session->userdata('auth_user');
    $branch_id = (int)($u['branch_id'] ?? 0);
    $user_id   = (int)($u['id'] ?? 0);

    if ($this->input->method(TRUE) === 'POST') {
      $period_id = (int)$this->input->post('period_id', TRUE);
      $res = $this->Branch_report_model->create_report_from_period($branch_id, $period_id, $user_id);

      if (!$res['ok']) {
        $this->session->set_flashdata('err', $res['msg']);
        redirect('branch/reports');
        return;
      }

      $this->session->set_flashdata('ok', 'Laporan berhasil dibuat (DRAFT).');
      redirect('branch/reports/'.$res['id']);
      return;
    }

    show_404();
  }

  public function show($id)
  {
    $u = $this->session->userdata('auth_user');
    $branch_id = (int)($u['branch_id'] ?? 0);

    $dataReport = $this->Branch_report_model->find_report((int)$id, $branch_id);
    if (!$dataReport) show_404();

    $data = array(
      'title' => 'Detail Laporan Cabang',
      'role'  => 'CABANG',
      'user'  => (object) array(
        'full_name' => $u['full_name'] ?? 'User',
        'username'  => $u['username'] ?? 'user'
      ),
      'hdr'     => $dataReport['hdr'],
      'lines'   => $dataReport['lines'],
      'periods' => $this->Branch_report_model->periods(),
      'ok'      => $this->session->flashdata('ok'),
      'err'     => $this->session->flashdata('err'),
    );

    $data['menu'] = menu_branch_sidebar();

    $this->load->view('layouts/app', array(
      'content' => $this->load->view('branch/reports/show', $data, TRUE),
      'title'   => $data['title'],
      'menu'    => $data['menu'],
      'user'    => $data['user'],
      'role'    => $data['role']
    ));
  }

  public function send($id)
  {
    if ($this->input->method(TRUE) !== 'POST') show_404();

    $u = $this->session->userdata('auth_user');
    $branch_id = (int)($u['branch_id'] ?? 0);

    // kirim laporan (status berubah jadi SENT di model)
    $res = $this->Branch_report_model->send_report((int)$id, $branch_id);

    // jika sukses, buat notifikasi ke ADMIN & BENDAHARA
    if (isset($res['ok']) && $res['ok']) {
      $report = $this->Branch_report_model->find_report((int)$id, $branch_id);
      if ($report && isset($report['hdr'])) {
        $hdr = $report['hdr'];

        $this->load->model('Notification_model');

        $title = 'Laporan Cabang Terkirim';
        $body  = 'Cabang mengirim laporan: '.$hdr->report_no.' ('.$hdr->year.'-'.str_pad((string)$hdr->month, 2, '0', STR_PAD_LEFT).')';
        $link  = site_url('dashboard/reports');

        $this->Notification_model->notify_roles(array('ADMIN','BENDAHARA'), $title, $body, $link);
      }
    }

    $this->session->set_flashdata(
      ($res['ok'] ?? false) ? 'ok' : 'err',
      ($res['ok'] ?? false) ? 'Laporan dikirim ke pusat.' : ($res['msg'] ?? 'Gagal mengirim laporan.')
    );
    redirect('branch/reports/'.$id);
  }

  public function export_pdf($id)
  {
    $u = $this->session->userdata('auth_user');
    $branch_id = (int)($u['branch_id'] ?? 0);

    $report = $this->Branch_report_model->find_report((int)$id, $branch_id);
    if (!$report) show_404();

    $html = $this->load->view('branch/reports/pdf', array(
      'hdr'   => $report['hdr'],
      'lines' => $report['lines'],
    ), TRUE);

    $filename = 'LaporanCabang_'.$report['hdr']->report_no.'.pdf';
    $this->pdf_lib->render($html, $filename, 'A4', 'landscape', true, array(
      'title' => 'Laporan Cabang',
      'year'  => (string)($report['hdr']->year ?? date('Y')),
    ));

  }

  public function refresh($id)
{
  // boleh GET atau POST (biar klik tombol/link sama-sama jalan)
  $u = $this->session->userdata('auth_user');
  $branch_id = (int)($u['branch_id'] ?? 0);
  $user_id   = (int)($u['id'] ?? 0);

  $res = $this->Branch_report_model->refresh_report((int)$id, $branch_id, $user_id);

  if (!($res['ok'] ?? false)) {
    $this->session->set_flashdata('err', $res['msg'] ?? 'Gagal memperbaharui laporan.');
  } else {
    $this->session->set_flashdata('ok', 'Laporan berhasil diperbaharui. Jika sebelumnya SENT/APPROVED maka status kembali DRAFT.');
  }

  redirect('branch/reports/'.$id);
}


}
