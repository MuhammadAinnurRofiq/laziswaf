<?php
defined('BASEPATH') OR exit('No direct script access allowed');

/**
 * Public endpoint untuk mengambil asset (logo) yang disimpan di database.
 * Dipakai untuk: header/sidebar/footer + favicon.
 */
class AppAssets extends CI_Controller
{
  public function __construct()
  {
    parent::__construct();
    $this->load->model('Setting_model');
  }

  public function logo()
  {
    $row = $this->Setting_model->get_asset('app_logo');
    if (!$row || empty($row['data']) || empty($row['mime_type'])) {
      // fallback: tidak ada logo tersimpan
      show_404();
      return;
    }

    $mime = (string)$row['mime_type'];
    if ($mime === '') $mime = 'image/png';

    // cache ringan (favicon biasanya dicache keras di browser)
    header('Content-Type: ' . $mime);
    header('Cache-Control: public, max-age=86400');
    echo $row['data'];
  }
}
