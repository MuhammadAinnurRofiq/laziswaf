<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class CenterBranches extends MY_Controller
{
  public function __construct()
  {
    parent::__construct();
    $this->require_login();

    $role = (string)$this->session->userdata('auth_role');
    if (!in_array($role, array('ADMIN','BENDAHARA'), true)) show_error('Akses ditolak', 403);

    $this->load->model('Center_branch_model');
    $this->load->helper(array('url','form','menu'));
  }

  public function index()
  {
    $q = trim((string)$this->input->get('q', TRUE));
    $rows = $this->Center_branch_model->branches_with_user($q);

    $u = $this->session->userdata('auth_user');
    $role = (string)$this->session->userdata('auth_role');

    $data = array(
      'title' => 'Cabang & Akun Cabang',
      'rows' => $rows,
      'q' => $q,
      'role' => $role,
      'user' => (object)$u,
      'menu' => menu_center_sidebar($role),
      'flash' => $this->session->flashdata('msg')
    );

    $this->load->view('layouts/app', array(
      'content' => $this->load->view('center/branches/index', $data, TRUE),
      'title'   => $data['title'],
      'menu'    => $data['menu'],
      'user'    => $data['user'],
      'role'    => $data['role'],
    ));
  }

  public function create()
  {
    $u = $this->session->userdata('auth_user');
    $role = (string)$this->session->userdata('auth_role');

    if ($this->input->method(TRUE) === 'POST') {
      $branch_code = trim((string)$this->input->post('branch_code', TRUE));
      $branch_name = trim((string)$this->input->post('branch_name', TRUE));
      $contact_wa  = trim((string)$this->input->post('contact_wa', TRUE));
      $username    = trim((string)$this->input->post('username', TRUE));
      $password    = (string)$this->input->post('password', TRUE);

      if ($branch_code === '' || $branch_name === '' || $username === '' || strlen($password) < 6) {
        $this->session->set_flashdata('msg', 'Gagal: pastikan kode/nama/username terisi dan password minimal 6.');
        redirect('dashboard/branches/create');
        return;
      }

      if ($this->Center_branch_model->branch_code_exists($branch_code)) {
        $this->session->set_flashdata('msg', 'Gagal: branch_code sudah ada.');
        redirect('dashboard/branches/create');
        return;
      }
      if ($this->Center_branch_model->username_exists($username)) {
        $this->session->set_flashdata('msg', 'Gagal: username sudah dipakai.');
        redirect('dashboard/branches/create');
        return;
      }

      $branch = array(
        'branch_code' => $branch_code,
        'branch_name' => $branch_name,
        'address'     => $this->input->post('address', TRUE),
        'contact_wa'  => $contact_wa,
        'is_active'   => 1,
        'created_at'  => date('Y-m-d H:i:s'),
        'updated_at'  => date('Y-m-d H:i:s'),
      );

      $user = array(
        'username'      => $username,
        'password_hash' => password_hash($password, PASSWORD_BCRYPT),
        'full_name'     => $branch_name,
        'phone'         => $contact_wa,
        'email'         => $this->input->post('email', TRUE),
        'is_active'     => 1,
        'created_at'    => date('Y-m-d H:i:s'),
        'updated_at'    => date('Y-m-d H:i:s'),
      );

      $res = $this->Center_branch_model->create_branch_and_user($branch, $user, 'CABANG');
      $this->session->set_flashdata('msg', $res['ok'] ? 'Berhasil buat cabang & akun.' : 'Gagal simpan data.');
      redirect('dashboard/branches');
      return;
    }

    $data = array(
      'title' => 'Tambah Cabang',
      'role' => $role,
      'user' => (object)$u,
      'menu' => menu_center_sidebar($role),
      'row'  => null,
      'userrow' => null
    );

    $this->load->view('layouts/app', array(
      'content' => $this->load->view('center/branches/form', $data, TRUE),
      'title'   => $data['title'],
      'menu'    => $data['menu'],
      'user'    => $data['user'],
      'role'    => $data['role'],
    ));
  }

  public function edit($branch_id)
  {
    $branch = $this->Center_branch_model->get_branch($branch_id);
    if (!$branch) show_404();

    $userrow = $this->Center_branch_model->get_branch_user($branch_id);
    if (!$userrow) show_error('User cabang tidak ditemukan (branch_id='.$branch_id.')', 500);

    $u = $this->session->userdata('auth_user');
    $role = (string)$this->session->userdata('auth_role');

    if ($this->input->method(TRUE) === 'POST') {
      $branch_code = trim((string)$this->input->post('branch_code', TRUE));
      $branch_name = trim((string)$this->input->post('branch_name', TRUE));
      $contact_wa  = trim((string)$this->input->post('contact_wa', TRUE));
      $username    = trim((string)$this->input->post('username', TRUE));
      $newpass     = (string)$this->input->post('password', TRUE);

      if ($branch_code === '' || $branch_name === '' || $username === '') {
        $this->session->set_flashdata('msg', 'Gagal: kode/nama/username wajib terisi.');
        redirect('dashboard/branches/edit/'.$branch_id);
        return;
      }

      if ($this->Center_branch_model->branch_code_exists($branch_code, $branch_id)) {
        $this->session->set_flashdata('msg', 'Gagal: branch_code sudah dipakai.');
        redirect('dashboard/branches/edit/'.$branch_id);
        return;
      }
      if ($this->Center_branch_model->username_exists($username, (int)$userrow['id'])) {
        $this->session->set_flashdata('msg', 'Gagal: username sudah dipakai.');
        redirect('dashboard/branches/edit/'.$branch_id);
        return;
      }

      $branch_upd = array(
        'branch_code' => $branch_code,
        'branch_name' => $branch_name,
        'address'     => $this->input->post('address', TRUE),
        'contact_wa'  => $contact_wa,
        'is_active'   => (int)$this->input->post('is_active', TRUE) ? 1 : 0,
        'updated_at'  => date('Y-m-d H:i:s'),
      );

      $user_upd = array(
        'username'   => $username,
        'full_name'  => $branch_name,
        'phone'      => $contact_wa,
        'email'      => $this->input->post('email', TRUE),
        'is_active'  => (int)$this->input->post('is_active', TRUE) ? 1 : 0,
        'updated_at' => date('Y-m-d H:i:s'),
      );

      $res = $this->Center_branch_model->update_branch_and_user($branch_id, $branch_upd, (int)$userrow['id'], $user_upd, $newpass);
      $this->session->set_flashdata('msg', $res['ok'] ? 'Berhasil update.' : 'Gagal update.');
      redirect('dashboard/branches');
      return;
    }

    $data = array(
      'title' => 'Edit Cabang',
      'role' => $role,
      'user' => (object)$u,
      'menu' => menu_center_sidebar($role),
      'row'  => $branch,
      'userrow' => $userrow
    );

    $this->load->view('layouts/app', array(
      'content' => $this->load->view('center/branches/form', $data, TRUE),
      'title'   => $data['title'],
      'menu'    => $data['menu'],
      'user'    => $data['user'],
      'role'    => $data['role'],
    ));
  }



  /* =========================
   * MULTI USER CABANG (ADMIN/BENDAHARA)
   * ========================= */

  public function users($branch_id)
  {
    $branch = $this->Center_branch_model->get_branch($branch_id);
    if (!$branch) show_404();

    $q = trim((string)$this->input->get('q', TRUE));
    $rows = $this->Center_branch_model->list_branch_users($branch_id, $q);

    $u = $this->session->userdata('auth_user');
    $role = (string)$this->session->userdata('auth_role');

    $data = array(
      'title'  => 'User Cabang - '.$branch['branch_name'],
      'branch' => $branch,
      'rows'   => $rows,
      'q'      => $q,
      'role'   => $role,
      'user'   => (object)$u,
      'menu'   => menu_center_sidebar($role),
      'flash'  => $this->session->flashdata('msg')
    );

    $this->load->view('layouts/app', array(
      'content' => $this->load->view('center/branches/users_index', $data, TRUE),
      'title'   => $data['title'],
      'menu'    => $data['menu'],
      'user'    => $data['user'],
      'role'    => $data['role'],
    ));
  }

  public function user_create($branch_id)
  {
    $branch = $this->Center_branch_model->get_branch($branch_id);
    if (!$branch) show_404();

    $u = $this->session->userdata('auth_user');
    $role = (string)$this->session->userdata('auth_role');

    if ($this->input->method(TRUE) === 'POST') {
      $username  = trim((string)$this->input->post('username', TRUE));
      $full_name = trim((string)$this->input->post('full_name', TRUE));
      $phone     = trim((string)$this->input->post('phone', TRUE));
      $email     = trim((string)$this->input->post('email', TRUE));
      $password  = (string)$this->input->post('password', TRUE);
      $is_active = (int)$this->input->post('is_active', TRUE) ? 1 : 0;

      if ($username === '' || $full_name === '' || strlen($password) < 6) {
        $this->session->set_flashdata('msg', 'Gagal: username & nama wajib, password minimal 6.');
        redirect('dashboard/branches/users/'.$branch_id.'/create');
        return;
      }

      if ($this->Center_branch_model->username_exists($username)) {
        $this->session->set_flashdata('msg', 'Gagal: username sudah dipakai.');
        redirect('dashboard/branches/users/'.$branch_id.'/create');
        return;
      }

      $user = array(
        'username'      => $username,
        'password_hash' => password_hash($password, PASSWORD_BCRYPT),
        'full_name'     => $full_name,
        'phone'         => $phone,
        'email'         => $email,
        'is_active'     => $is_active,
        'created_at'    => date('Y-m-d H:i:s'),
        'updated_at'    => date('Y-m-d H:i:s'),
      );

      $res = $this->Center_branch_model->create_branch_user($branch_id, $user, 'CABANG');
      $this->session->set_flashdata('msg', $res['ok'] ? 'Berhasil buat user cabang.' : 'Gagal simpan user cabang.');
      redirect('dashboard/branches/users/'.$branch_id);
      return;
    }

    $data = array(
      'title'  => 'Tambah User Cabang - '.$branch['branch_name'],
      'branch' => $branch,
      'row'    => null,
      'role'   => $role,
      'user'   => (object)$u,
      'menu'   => menu_center_sidebar($role),
      'flash'  => $this->session->flashdata('msg')
    );

    $this->load->view('layouts/app', array(
      'content' => $this->load->view('center/branches/user_form', $data, TRUE),
      'title'   => $data['title'],
      'menu'    => $data['menu'],
      'user'    => $data['user'],
      'role'    => $data['role'],
    ));
  }

  public function user_edit($branch_id, $user_id)
  {
    $branch = $this->Center_branch_model->get_branch($branch_id);
    if (!$branch) show_404();

    $row = $this->Center_branch_model->get_branch_user_by_id($branch_id, $user_id);
    if (!$row) show_404();

    $u = $this->session->userdata('auth_user');
    $role = (string)$this->session->userdata('auth_role');

    if ($this->input->method(TRUE) === 'POST') {
      $username  = trim((string)$this->input->post('username', TRUE));
      $full_name = trim((string)$this->input->post('full_name', TRUE));
      $phone     = trim((string)$this->input->post('phone', TRUE));
      $email     = trim((string)$this->input->post('email', TRUE));
      $newpass   = (string)$this->input->post('password', TRUE);
      $is_active = (int)$this->input->post('is_active', TRUE) ? 1 : 0;

      if ($username === '' || $full_name === '') {
        $this->session->set_flashdata('msg', 'Gagal: username & nama wajib.');
        redirect('dashboard/branches/users/'.$branch_id.'/edit/'.$user_id);
        return;
      }

      if ($this->Center_branch_model->username_exists($username, (int)$user_id)) {
        $this->session->set_flashdata('msg', 'Gagal: username sudah dipakai.');
        redirect('dashboard/branches/users/'.$branch_id.'/edit/'.$user_id);
        return;
      }

      // safety: jangan matikan user aktif terakhir di cabang
      if ($is_active === 0 && (int)$row['is_active'] === 1) {
        $active_count = $this->Center_branch_model->count_active_branch_users($branch_id);
        if ($active_count <= 1) {
          $this->session->set_flashdata('msg', 'Gagal: minimal harus ada 1 user cabang yang aktif.');
          redirect('dashboard/branches/users/'.$branch_id.'/edit/'.$user_id);
          return;
        }
      }

      $upd = array(
        'username'   => $username,
        'full_name'  => $full_name,
        'phone'      => $phone,
        'email'      => $email,
        'is_active'  => $is_active,
        'updated_at' => date('Y-m-d H:i:s'),
      );

      $res = $this->Center_branch_model->update_branch_user($branch_id, $user_id, $upd, $newpass);
      $this->session->set_flashdata('msg', $res['ok'] ? 'Berhasil update user cabang.' : 'Gagal update user cabang.');
      redirect('dashboard/branches/users/'.$branch_id);
      return;
    }

    $data = array(
      'title'  => 'Edit User Cabang - '.$branch['branch_name'],
      'branch' => $branch,
      'row'    => $row,
      'role'   => $role,
      'user'   => (object)$u,
      'menu'   => menu_center_sidebar($role),
      'flash'  => $this->session->flashdata('msg')
    );

    $this->load->view('layouts/app', array(
      'content' => $this->load->view('center/branches/user_form', $data, TRUE),
      'title'   => $data['title'],
      'menu'    => $data['menu'],
      'user'    => $data['user'],
      'role'    => $data['role'],
    ));
  }

  public function user_toggle($branch_id, $user_id)
  {
    if ($this->input->method(TRUE) !== 'POST') show_404();

    $branch = $this->Center_branch_model->get_branch($branch_id);
    if (!$branch) show_404();

    $row = $this->Center_branch_model->get_branch_user_by_id($branch_id, $user_id);
    if (!$row) show_404();

    $new_active = ((int)$row['is_active'] === 1) ? 0 : 1;

    // safety: jangan matikan user aktif terakhir di cabang
    if ($new_active === 0) {
      $active_count = $this->Center_branch_model->count_active_branch_users($branch_id);
      if ($active_count <= 1) {
        $this->session->set_flashdata('msg', 'Gagal: minimal harus ada 1 user cabang yang aktif.');
        redirect('dashboard/branches/users/'.$branch_id);
        return;
      }
    }

    $res = $this->Center_branch_model->set_branch_user_active($branch_id, $user_id, $new_active);
    $this->session->set_flashdata('msg', $res['ok'] ? 'Berhasil ubah status user.' : 'Gagal ubah status user.');
    redirect('dashboard/branches/users/'.$branch_id);
  }

  public function delete($branch_id)
  {
    if ($this->input->method(TRUE) !== 'POST') show_404();

    $res = $this->Center_branch_model->deactivate_branch($branch_id);
    $this->session->set_flashdata('msg', $res['ok'] ? 'Cabang dinonaktifkan (soft delete).' : 'Gagal hapus.');
    redirect('dashboard/branches');
  }

  public function card($branch_id)
  {
    $branch = $this->Center_branch_model->get_branch($branch_id);
    if (!$branch) show_404();

    $userrow = $this->Center_branch_model->get_branch_user($branch_id);

    $u = $this->session->userdata('auth_user');
    $role = (string)$this->session->userdata('auth_role');

    $scan_url = site_url('public/scan/'.$branch['public_token']);

    $data = array(
      'title' => 'Kartu Cabang',
      'role' => $role,
      'user' => (object)$u,
      'menu' => menu_center_sidebar($role),
      'branch' => $branch,
      'userrow' => $userrow,
      'scan_url' => $scan_url
    );

    $this->load->view('layouts/app', array(
      'content' => $this->load->view('center/branches/card', $data, TRUE),
      'title'   => $data['title'],
      'menu'    => $data['menu'],
      'user'    => $data['user'],
      'role'    => $data['role'],
    ));
  }
}
