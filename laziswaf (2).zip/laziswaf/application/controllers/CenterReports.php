<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class CenterReports extends MY_Controller
{
  public function __construct()
  {
    parent::__construct();
    $this->require_login();

    $role = (string)$this->session->userdata('auth_role');
    if (!in_array($role, array('ADMIN','BENDAHARA'), true)) show_error('Akses ditolak', 403);

    $this->load->model('Center_report_model');
    $this->load->helper(array('url','form'));

    // WAJIB: helper menu
    $this->load->helper('menu');

    // WAJIB: Pdf lib
    $this->load->library('Pdf_lib');
  }

  public function index()
  {
    $u = $this->session->userdata('auth_user');

    $filters = array(
      'branch_id' => $this->input->get('branch_id', TRUE),
      'status'    => $this->input->get('status', TRUE),
      'year'      => $this->input->get('year', TRUE),
      'month'     => $this->input->get('month', TRUE),
    );

    $per_page = 20;
    $page = (int)$this->input->get('page', TRUE);
    if ($page < 1) $page = 1;
    $offset = ($page - 1) * $per_page;

    $res = $this->Center_report_model->search($filters, $per_page, $offset);

    $data = array(
      'title' => 'Review Laporan Cabang',
      'role'  => (string)$this->session->userdata('auth_role'),
      'user'  => (object) array(
        'full_name' => $u['full_name'] ?? 'User',
        'username'  => $u['username'] ?? 'user'
      ),

      'rows'  => $res['rows'],
      'total' => $res['total'],
      'page'  => $page,
      'per_page' => $per_page,

      'filters'  => $filters,
      'branches' => $this->Center_report_model->branches_active(),
      'statuses' => array(
        '' => 'Semua',
        'DRAFT' => 'DRAFT',
        'SENT' => 'SENT',
        'APPROVED' => 'APPROVED',
        'REJECTED' => 'REJECTED',
      ),
      'ok'  => $this->session->flashdata('ok'),
      'err' => $this->session->flashdata('err'),
    );

    // WAJIB: isi menu dari helper (ADMIN mendapat Setting + User Bendahara)
    $data['menu'] = menu_center_sidebar($data['role']);

    $this->load->view('layouts/app', array(
      'content' => $this->load->view('center/reports/index', $data, TRUE),
      'title'   => $data['title'],
      'menu'    => $data['menu'],
      'user'    => $data['user'],
      'role'    => $data['role']
    ));
  }

  public function branches()
{
  $period_id = $this->input->get('period_id', TRUE);
  $year  = $this->input->get('year', TRUE);
  $month = $this->input->get('month', TRUE);

  $p = $this->Center_report_model->get_period($period_id, $year, $month);
  if (!$p) show_error('Periode tidak ditemukan.', 404);

  $pack = $this->Center_report_model->branch_reporting_overview($p->id);
  if (!$pack) show_error('Gagal mengambil data.', 500);

  $u = (array)$this->session->userdata('auth_user');
  $role = (string)$this->session->userdata('auth_role');

  $data = array(
    'title'   => 'Status Laporan Cabang',
    'role'    => $role,
    'user'    => (object) array(
      'full_name' => $u['full_name'] ?? 'Pusat',
      'username'  => $u['username'] ?? 'pusat',
    ),
    // tampilkan menu sesuai role (ADMIN mendapat Setting + User Bendahara)
    'menu'    => menu_center_sidebar($role),
    'periods' => $this->Center_report_model->periods_list(36),
    'period'  => $pack['period'],
    'unreported' => $pack['unreported'],
    'pending'    => $pack['pending'],
    'approved'   => $pack['approved'],
  );

  $this->load->view('layouts/app', array(
    'content' => $this->load->view('center/reports/branches', $data, TRUE),
    'title'   => $data['title'],
    'menu'    => $data['menu'],
    'user'    => $data['user'],
    'role'    => $data['role'],
  ));
}

public function branches_pdf()
{
  $period_id = $this->input->get('period_id', TRUE);
  $year  = $this->input->get('year', TRUE);
  $month = $this->input->get('month', TRUE);

  $p = $this->Center_report_model->get_period($period_id, $year, $month);
  if (!$p) show_error('Periode tidak ditemukan.', 404);

  $pack = $this->Center_report_model->branch_reporting_overview($p->id);
  if (!$pack) show_error('Gagal mengambil data.', 500);

  $html = $this->load->view('center/reports/branches_pdf', array(
    'period'     => $pack['period'],
    'unreported' => $pack['unreported'],
    'pending'    => $pack['pending'],
    'approved'   => $pack['approved'],
  ), TRUE);

  $filename = 'Status_Laporan_Cabang_'.$pack['period']->year.'-'.str_pad((string)$pack['period']->month,2,'0',STR_PAD_LEFT).'.pdf';
  $this->pdf_lib->render($html, $filename, 'A4', 'portrait', true, array(
    'title' => 'Status Laporan Cabang',
    'year'  => (string)($pack['period']->year ?? date('Y')),
  ));
}


  public function show($id)
  {
    $u = $this->session->userdata('auth_user');

    $detail = $this->Center_report_model->find((int)$id);
    if (!$detail) show_404();

    $data = array(
      'title' => 'Detail Review Laporan',
      'role'  => (string)$this->session->userdata('auth_role'),
      'user'  => (object) array(
        'full_name' => $u['full_name'] ?? 'User',
        'username'  => $u['username'] ?? 'user'
      ),

      'hdr'   => $detail['hdr'],
      'lines' => $detail['lines'],
      'ok'  => $this->session->flashdata('ok'),
      'err' => $this->session->flashdata('err'),
    );

    // WAJIB: isi menu dari helper (ADMIN mendapat Setting + User Bendahara)
    $data['menu'] = menu_center_sidebar($data['role']);

    $this->load->view('layouts/app', array(
      'content' => $this->load->view('center/reports/show', $data, TRUE),
      'title'   => $data['title'],
      'menu'    => $data['menu'],
      'user'    => $data['user'],
      'role'    => $data['role']
    ));
  }

  public function approve($id)
  {
    if ($this->input->method(TRUE) !== 'POST') show_404();

    $u = $this->session->userdata('auth_user');
    $note = (string)$this->input->post('note', TRUE);

    $res = $this->Center_report_model->approve((int)$id, (int)$u['id'], $note);

    // NOTIFIKASI ke CABANG (jika sukses)
    if (isset($res['ok']) && $res['ok']) {
      $new_status = 'APPROVED';
      $detail = $this->Center_report_model->find((int)$id);
      if ($detail && isset($detail['hdr'])) {
        $hdr = $detail['hdr'];

        $this->load->model('Notification_model');

        $title = ($new_status === 'APPROVED') ? 'Laporan Disetujui' : 'Laporan Ditolak';
        $body  = 'Laporan '.$hdr->report_no.' '.$new_status.'.'.(!empty($note) ? ' Catatan: '.$note : '');
        $link  = site_url('branch/reports'); // atau link detail laporan cabang

        $this->Notification_model->notify_roles(
          array('CABANG'),
          $title,
          $body,
          $link,
          (int)$hdr->branch_id
        );
      }
    }

    $this->session->set_flashdata(
      ($res['ok'] ?? false) ? 'ok' : 'err',
      ($res['ok'] ?? false) ? 'Laporan di-approve.' : ($res['msg'] ?? 'Gagal approve laporan.')
    );
    redirect('dashboard/reports/'.$id);
  }

  public function reject($id)
  {
    if ($this->input->method(TRUE) !== 'POST') show_404();

    $u = $this->session->userdata('auth_user');
    $note = (string)$this->input->post('note', TRUE);

    $res = $this->Center_report_model->reject((int)$id, (int)$u['id'], $note);

    // NOTIFIKASI ke CABANG (jika sukses)
    if (isset($res['ok']) && $res['ok']) {
      $new_status = 'REJECTED';
      $detail = $this->Center_report_model->find((int)$id);
      if ($detail && isset($detail['hdr'])) {
        $hdr = $detail['hdr'];

        $this->load->model('Notification_model');

        $title = ($new_status === 'APPROVED') ? 'Laporan Disetujui' : 'Laporan Ditolak';
        $body  = 'Laporan '.$hdr->report_no.' '.$new_status.'.'.(!empty($note) ? ' Catatan: '.$note : '');
        $link  = site_url('branch/reports'); // atau link detail laporan cabang

        $this->Notification_model->notify_roles(
          array('CABANG'),
          $title,
          $body,
          $link,
          (int)$hdr->branch_id
        );
      }
    }

    $this->session->set_flashdata(
      ($res['ok'] ?? false) ? 'ok' : 'err',
      ($res['ok'] ?? false) ? 'Laporan di-reject.' : ($res['msg'] ?? 'Gagal reject laporan.')
    );
    redirect('dashboard/reports/'.$id);
  }

  public function export_pdf($id)
{
  $detail = $this->Center_report_model->find((int)$id);
  if (!$detail) show_404();

  $hdr   = $detail['hdr'];
  $lines = $detail['lines'];

  $html = $this->load->view('center/reports/pdf_show', array(
    'hdr'   => $hdr,
    'lines' => $lines,
  ), TRUE);

  $filename = 'Laporan_'.$hdr->report_no.'.pdf';
  // landscape karena kolom split banyak
  $this->pdf_lib->render($html, $filename, 'A4', 'landscape', true, array(
    'title' => 'Laporan Cabang',
    'year'  => (string)($hdr->year ?? date('Y')),
  ));
}


  public function consolidation()
  {
    $u = $this->session->userdata('auth_user');

    $year  = (int)$this->input->get('year', TRUE);
    $month = (int)$this->input->get('month', TRUE);

    if ($year < 2000) $year = (int)date('Y');
    if ($month < 1 || $month > 12) $month = (int)date('m');

    $cons = $this->Center_report_model->consolidation($year, $month);

    $data = array(
      'title' => 'Konsolidasi Laporan Pusat',
      'role'  => (string)$this->session->userdata('auth_role'),
      'user'  => (object) array(
        'full_name' => $u['full_name'] ?? 'User',
        'username'  => $u['username'] ?? 'user'
      ),

      'year'  => $year,
      'month' => $month,
      'rows'  => $cons['rows'],
      'grand_money' => $cons['grand_money'],
      'grand_rice'  => $cons['grand_rice'],
    );

    // WAJIB: isi menu dari helper (ADMIN mendapat Setting + User Bendahara)
    $data['menu'] = menu_center_sidebar($data['role']);

    $this->load->view('layouts/app', array(
      'content' => $this->load->view('center/reports/consolidation', $data, TRUE),
      'title'   => $data['title'],
      'menu'    => $data['menu'],
      'user'    => $data['user'],
      'role'    => $data['role']
    ));
  }

  // EXPORT PDF - KONSOLIDASI
  public function consolidation_pdf()
  {
    $year  = (int)$this->input->get('year', TRUE);
    $month = (int)$this->input->get('month', TRUE);

    if ($year < 2000) $year = (int)date('Y');
    if ($month < 1 || $month > 12) $month = (int)date('m');

    $cons = $this->Center_report_model->consolidation($year, $month);

    $html = $this->load->view('center/reports/pdf_consolidation', array(
      'year' => $year,
      'month'=> $month,
      'rows' => $cons['rows'],
      'grand_money' => $cons['grand_money'],
      'grand_rice'  => $cons['grand_rice'],
    ), TRUE);

    $filename = 'Konsolidasi_'.$year.'_'.str_pad((string)$month, 2, '0', STR_PAD_LEFT).'.pdf';
    $this->pdf_lib->render($html, $filename, 'A4', 'portrait', true, array(
      'title' => 'Konsolidasi Laporan Pusat',
      'year'  => (string)$year,
    ));
  }
}
