<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class PublicSubmission extends CI_Controller
{
  private $allowed = array('fitrah','mal','fidyah','infaq');

  public function __construct()
  {
    parent::__construct();

    $this->load->library(array('form_validation','session'));
    $this->load->helper(array('url','form','menu'));

    $this->load->model('Rate_model');
    $this->load->model('Running_number_model');
    $this->load->model('Submission_model');
  }

  public function index()
  {
    redirect('public');
  }

  public function create($type = 'fitrah')
  {
    $type = strtolower($type);
    if (!in_array($type, $this->allowed, true)) show_404();

    $zis_code = strtoupper($type);
    $rate = $this->Rate_model->get_current($zis_code);

    $data = array(
      'title' => 'Ajukan ' . $this->label($zis_code),
      'role'  => 'PUBLIC',
      'user'  => (object) array('full_name'=>'Pengunjung','username'=>'public'),

      'type'     => $type,
      'zis_code' => $zis_code,
      'rate'     => $rate,
      'branches' => $this->Rate_model->get_branches_public(),
      'methods'  => $this->Rate_model->get_payment_methods(),
      'error'    => null
    );

    // ✅ SESUAI PERINTAH: fixed cabang dari QR (session)
    $fixed_branch_id = (int)$this->session->userdata('public_branch_id');
    $data['fixed_branch_id']   = $fixed_branch_id;
    $data['fixed_branch_name'] = (string)$this->session->userdata('public_branch_name');

    $data['menu'] = menu_public_sidebar();

    $this->load->view('layouts/app', array(
      'content' => $this->load->view('public/submission/form', $data, TRUE),
      'title'   => $data['title'],
      'menu'    => $data['menu'],
      'user'    => $data['user'],
      'role'    => $data['role']
    ));
  }

  public function store()
  {
    if ($this->input->method(TRUE) !== 'POST') show_404();

    $type = strtolower($this->input->post('type', TRUE));
    if (!in_array($type, $this->allowed, true)) show_404();

    $zis_code = strtoupper($type);

    // ✅ SESUAI PERINTAH: kalau session ada, override input branch_id sebelum validation
    $fixed_branch_id = (int)$this->session->userdata('public_branch_id');
    if ($fixed_branch_id > 0) {
      $_POST['branch_id'] = $fixed_branch_id;
    }

    // rules umum
    $this->form_validation->set_rules('branch_id','Cabang Tujuan','required|integer');
    $this->form_validation->set_rules('applicant_name','Nama Pengaju','required|min_length[3]|max_length[120]');
    $this->form_validation->set_rules('whatsapp','No WhatsApp','required|min_length[8]|max_length[30]');

    // rules per jenis
    if ($type === 'fitrah') {
      $this->form_validation->set_rules('jiwa_count','Jumlah Jiwa','required|integer|greater_than[0]');
      $this->form_validation->set_rules('pay_method_id','Metode Pembayaran','required|integer');
    } elseif ($type === 'fidyah') {
      $this->form_validation->set_rules('jiwa_count','Jumlah Jiwa','required|integer|greater_than[0]');
      $this->form_validation->set_rules('fidyah_days','Jumlah Hari','required|integer|greater_than[0]');
    } else {
      $this->form_validation->set_rules('amount_money','Nominal','required|numeric|greater_than[0]');
    }

    if (!$this->form_validation->run()) {
      return $this->create($type);
    }

    // ✅ SESUAI PERINTAH: ambil branch_id dari session, kalau kosong ambil dari POST
    $branch_id = (int)$this->session->userdata('public_branch_id');
    if ($branch_id <= 0) $branch_id = (int)$this->input->post('branch_id', TRUE);

    $applicant = $this->input->post('applicant_name', TRUE);
    $wa = $this->normalize_wa($this->input->post('whatsapp', TRUE));

    $rate = $this->Rate_model->get_current($zis_code);
    $snapshot = $rate ? json_encode($rate, JSON_UNESCAPED_UNICODE) : null;

    $submission_no = $this->Running_number_model->next('SUBMISSION_NO');
    if (!$submission_no) {
      show_error('Gagal membuat nomor pengajuan. Coba ulang.', 500);
      return;
    }

    $data = array(
      'submission_no' => $submission_no,
      'source' => 'PUBLIC',
      'branch_id' => $branch_id,
      'zis_type_code' => $zis_code,
      'applicant_name' => $applicant,
      'whatsapp' => $wa,
      'rate_snapshot_json' => $snapshot,
      'status' => 'SUBMITTED',
      'submitted_at' => date('Y-m-d H:i:s'),
      'created_by' => null
    );

    $people = array();

    if ($type === 'fitrah') {
      $jiwa = (int)$this->input->post('jiwa_count', TRUE);
      $pay_method_id = (int)$this->input->post('pay_method_id', TRUE);

      $data['jiwa_count'] = $jiwa;
      $data['pay_method_id'] = $pay_method_id;

      $kg_per_jiwa = $rate && $rate->kg_per_jiwa ? (float)$rate->kg_per_jiwa : 2.5;
      $harga_per_jiwa = $rate && $rate->harga_per_jiwa ? (float)$rate->harga_per_jiwa : 0;

      $method = $this->db->get_where('mst_payment_methods', array('id'=>$pay_method_id), 1)->row();
      $method_code = $method ? $method->code : 'CASH';

      if ($method_code === 'RICE') {
        $data['fitrah_total_kg'] = $kg_per_jiwa * $jiwa;
        $data['fitrah_total_money'] = null;
      } else {
        $data['fitrah_total_money'] = $harga_per_jiwa * $jiwa;
        $data['fitrah_total_kg'] = null;
      }

      $people_text = (string)$this->input->post('people_text', TRUE);
      if ($people_text !== '') {
        $lines = preg_split("/\r\n|\n|\r/", $people_text);
        foreach ($lines as $ln) {
          $nm = trim($ln);
          if ($nm !== '') $people[] = $nm;
        }
      }

    } elseif ($type === 'fidyah') {
      $jiwa = (int)$this->input->post('jiwa_count', TRUE);
      if ($jiwa <= 0) $jiwa = 1;

      $days = (int)$this->input->post('fidyah_days', TRUE);
      $tarif = $rate && $rate->tarif_per_hari ? (float)$rate->tarif_per_hari : 0;

      $data['jiwa_count'] = $jiwa;
      $data['fidyah_days'] = $days;
      $data['tarif_per_hari_snapshot'] = $tarif;
      $data['amount_money'] = $tarif * $days * $jiwa;

    } else {
      $amt = (float)$this->input->post('amount_money', TRUE);
      $data['amount_money'] = $amt;
    }

    $id = $this->Submission_model->insert_submission($data, $people);
    if (!$id) {
      show_error('Gagal menyimpan pengajuan. Coba ulang.', 500);
      return;
    }

    redirect('public/submission/success/' . rawurlencode($submission_no));
  }

  public function success($submission_no)
  {
    $data = array(
      'title' => 'Pengajuan Berhasil',
      'role'  => 'PUBLIC',
      'user'  => (object) array('full_name'=>'Pengunjung','username'=>'public'),
      'submission_no' => $submission_no
    );

    $data['menu'] = menu_public_sidebar();

    $this->load->view('layouts/app', array(
      'content' => $this->load->view('public/submission/success', $data, TRUE),
      'title'   => $data['title'],
      'menu'    => $data['menu'],
      'user'    => $data['user'],
      'role'    => $data['role']
    ));
  }

  private function normalize_wa($wa)
  {
    $wa = preg_replace('/[^0-9]/', '', (string)$wa);
    if (strpos($wa, '0') === 0) $wa = '62' . substr($wa, 1);
    return $wa;
  }

  private function label($zis_code)
  {
    switch ($zis_code) {
      case 'FITRAH': return 'Zakat Fitrah';
      case 'MAL': return 'Zakat Mal';
      case 'FIDYAH': return 'Fidyah';
      case 'INFAQ': return 'Infaq';
      default: return $zis_code;
    }
  }
}
