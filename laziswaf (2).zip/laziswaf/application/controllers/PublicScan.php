<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class PublicScan extends CI_Controller
{
  public function __construct()
  {
    parent::__construct();
    $this->load->model('Center_branch_model'); // reuse model untuk lookup token
    $this->load->helper(array('url'));
    $this->load->library('session');
  }

  public function index($token)
  {
    $branch = $this->Center_branch_model->find_by_public_token($token);
    if (!$branch) show_404();

    // simpan pilihan cabang ke session publik
    $this->session->set_userdata('public_branch_id', (int)$branch['id']);
    $this->session->set_userdata('public_branch_name', (string)$branch['branch_name']);

    // arahkan ke dashboard publik (atau Anda bisa arahkan ke halaman pilih jenis)
    redirect('public');
  }
}
