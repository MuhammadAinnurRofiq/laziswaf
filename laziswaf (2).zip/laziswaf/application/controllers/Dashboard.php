<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Dashboard extends MY_Controller
{
  public function __construct()
  {
    parent::__construct();

    // minimal: harus login
    $this->require_login();

    // kalau masih butuh auth_lib untuk helper, load di sini
    $this->load->library('Auth_lib');

    // WAJIB: helper menu
    $this->load->helper('menu');
  }

  public function index()
{
  $role = (string)$this->session->userdata('auth_role');
  if (empty($role) && $this->auth_lib) $role = $this->auth_lib->primary_role();

  if ($role === 'CABANG') { redirect('branch'); return; }

  $u = (array)$this->session->userdata('auth_user');

  $data = array(
    'title' => 'Dashboard',
    'role'  => $role ?: 'ADMIN',
    'user'  => (object) array(
      'full_name' => $u['full_name'] ?? 'User',
      'username'  => $u['username'] ?? 'user',
    ),
  );

  // menu pusat
  $data['menu'] = menu_center_sidebar($data['role']); // kalau fungsi Anda menerima role
  // kalau menu_center_sidebar() tidak pakai parameter, ganti jadi: $data['menu'] = menu_center_sidebar();

  // metrik bendahara/admin
  if (in_array($data['role'], array('BENDAHARA','ADMIN'), true)) {
    $this->load->model('Center_report_model');

    // filter range (default: bulan ini)
    $range = (string)$this->input->get('range', TRUE); // 'month' | 'all'
    $year  = (int)($this->input->get('year', TRUE) ?: date('Y'));
    $month = (int)($this->input->get('month', TRUE) ?: date('n'));

    if ($range === 'all') {
      $data['metrics'] = $this->Center_report_model->bendahara_dashboard_metrics_all_time();
    } else {
      $p = $this->Center_report_model->get_period(null, $year, $month);
      if (!$p) $p = $this->Center_report_model->get_period();
      $data['metrics'] = $this->Center_report_model->bendahara_dashboard_metrics($p ? $p->id : null);

      // pastikan view pakai nilai yang valid
      $data['year']  = (int)($p->year ?? $year);
      $data['month'] = (int)($p->month ?? $month);
    }

    $data['range'] = $range ?: 'month';
    $data['year']  = $data['year'] ?? $year;
    $data['month'] = $data['month'] ?? $month;
  }

  $this->load->view('layouts/app', array(
    'content' => $this->load->view('dashboard/index', $data, TRUE), // ✅ INI YANG BENAR
    'title'   => $data['title'],
    'menu'    => $data['menu'],
    'user'    => $data['user'],
    'role'    => $data['role']
  ));
}


}
