<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Landing extends CI_Controller
{
  private function default_home($tagline)
  {
    return array(
      'badge'      => 'ZISWAF • Transparan • Terstruktur',
      'hero_title' => 'Kelola ZISWAF Modern & Mudah Dilacak',
      'hero_desc'  => $tagline,
      'cta_text'   => 'Masuk Dashboard',
      'cta_url'    => site_url('public'),
      'features'   => array(
        array('icon'=>'bi-search', 'title'=>'Tracking Pengajuan', 'desc'=>'Cek status tanpa login.'),
        array('icon'=>'bi-receipt', 'title'=>'Kuitansi Publik', 'desc'=>'Token publik + PDF + share WA.'),
        array('icon'=>'bi-file-earmark-text', 'title'=>'Laporan Cabang', 'desc'=>'Rekap bulanan rapi & terstruktur.'),
        array('icon'=>'bi-sliders', 'title'=>'Tarif & Kalkulator', 'desc'=>'Fitrah, Fidyah, Mal, Infaq.'),
        array('icon'=>'bi-shield-check', 'title'=>'Multi Role', 'desc'=>'Umum, Cabang, Bendahara, Admin.'),
        array('icon'=>'bi-diagram-3', 'title'=>'Alokasi Tercatat', 'desc'=>'Pembagian otomatis tercatat rapi.'),
      ),
      'videos' => array()
    );
  }

  public function index()
  {
    $this->load->helper(array('url','app_setting'));

    $app_name = app_setting('app_name', 'LAZISWAF');
    $tagline  = app_setting('landing_tagline', '');

    $home = app_setting_json('landing_home', array());
    $def  = $this->default_home($tagline);
    if (!is_array($home)) $home = array();
    $home = array_merge($def, $home);

    $data = array(
      'app_name' => $app_name,
      'tagline'  => $tagline,
      'logo_url' => app_logo_url(),
      'home'     => $home
    );

    $this->load->view('landing/index', $data);
  }
}
