<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class PublicReceipt extends CI_Controller
{
  public function __construct()
  {
    parent::__construct();
    $this->load->library(array('form_validation','session'));
    $this->load->helper(array('url','form','menu'));
    $this->load->model('Public_receipt_model');
  }

  public function index()
  {
    $token = trim((string)$this->input->get('token', TRUE));
    $wa_in = trim((string)$this->input->get('whatsapp', TRUE));

    $data = array(
      'title'    => 'Cek Kuitansi',
      'error'    => null,
      'token'    => $token,
      'whatsapp' => $wa_in,
      'receipts' => array(),
      'user'     => $this->session->userdata('auth_user'),
      'role'     => (string)$this->session->userdata('auth_role'),
    );

    // 1) Jika token diisi -> langsung buka
    if ($token !== '') {
      redirect('public/receipt/' . rawurlencode($token));
      return;
    }

    // 2) Jika WA diisi -> cari kwitansi by WA
    if ($wa_in !== '') {
      $wa = $this->normalize_wa($wa_in);

      $list = $this->Public_receipt_model->list_by_whatsapp($wa, 20);

      if (!$list) {
        $data['error'] = 'Kuitansi untuk nomor WhatsApp tersebut tidak ditemukan.';
      } else if (count($list) === 1) {
        redirect('public/receipt/' . rawurlencode($list[0]->public_token));
        return;
      } else {
        $data['receipts'] = $list; // tampilkan list untuk dipilih
      }
    }

    // menu publik
    $data['menu'] = menu_public_sidebar();

    $this->load->view('layouts/app', array(
      'content' => $this->load->view('public/receipt/index', $data, TRUE),
      'title'   => $data['title'],
      'menu'    => $data['menu'],
      'user'    => $data['user'],
      'role'    => $data['role']
    ));
  }

  public function view($token)
  {
    $token = trim((string)$token);
    if ($token === '') show_404();

    $pack = $this->Public_receipt_model->find_by_token($token);
    if (!$pack) show_404();

    $r = $pack['row'];
    $people = $pack['people'];

    $public_link = site_url('public/receipt/'.$r->public_token);

    $data = array(
      'title'       => 'Kuitansi Publik',
      'r'           => $r,
      'people'      => $people,
      'public_link' => $public_link,
      'user'        => $this->session->userdata('auth_user'),
      'role'        => (string)$this->session->userdata('auth_role'),
    );

    $data['menu'] = menu_public_sidebar();

    $this->load->view('layouts/app', array(
      'content' => $this->load->view('public/receipt/view', $data, TRUE),
      'title'   => $data['title'],
      'menu'    => $data['menu'],
      'user'    => $data['user'],
      'role'    => $data['role']
    ));
  }

  private function normalize_wa($wa)
  {
    $wa = preg_replace('/[^0-9]/', '', (string)$wa);
    if (strpos($wa, '0') === 0) $wa = '62' . substr($wa, 1);
    return $wa;
  }
}
