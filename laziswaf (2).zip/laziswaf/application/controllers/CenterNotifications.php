<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class CenterNotifications extends MY_Controller
{
  public function __construct()
  {
    parent::__construct();
    $this->require_login();

    $role = (string)$this->session->userdata('auth_role');
    if (!in_array($role, array('ADMIN','BENDAHARA'), true)) show_error('Akses ditolak', 403);

    $this->load->model('Notification_model');
    $this->load->helper('menu');
  }

  public function index()
  {
    $role = (string)$this->session->userdata('auth_role');
    $u = (array)$this->session->userdata('auth_user');
    $user_id = (int)($u['id'] ?? 0);

    $only_unread = $this->input->get('unread', TRUE) === '1';

    $per_page = 20;
    $page = (int)$this->input->get('page', TRUE);
    if ($page < 1) $page = 1;
    $offset = ($page - 1) * $per_page;

    $res = $this->Notification_model->list_for_user($user_id, $per_page, $offset, $only_unread);

    $data = array(
      'title' => 'Notifikasi',
      'role'  => $role,
      'user'  => (object) array(
        'full_name' => $u['full_name'] ?? 'User',
        'username'  => $u['username'] ?? 'user',
      ),
      // tampilkan menu sesuai role (ADMIN mendapat Setting + User Bendahara)
      'menu' => menu_center_sidebar($role),
      'notif_unread' => $this->Notification_model->unread_count($user_id),

      'rows' => $res['rows'],
      'total' => $res['total'],
      'page' => $page,
      'per_page' => $per_page,
      'only_unread' => $only_unread,
    );

    $this->load->view('layouts/app', array(
      'content' => $this->load->view('center/notifications/index', $data, TRUE),
      'title'   => $data['title'],
      'menu'    => $data['menu'],
      'user'    => $data['user'],
      'role'    => $data['role'],
      'notif_unread' => $data['notif_unread'],
    ));
  }

  public function read($id)
  {
    $u = (array)$this->session->userdata('auth_user');
    $user_id = (int)($u['id'] ?? 0);

    $this->Notification_model->mark_read((int)$id, $user_id);

    $back = $this->input->get('back', TRUE);
    redirect($back ? $back : 'dashboard/notifications');
  }

  public function read_all()
  {
    $u = (array)$this->session->userdata('auth_user');
    $user_id = (int)($u['id'] ?? 0);

    $this->Notification_model->mark_all_read($user_id);
    redirect('dashboard/notifications');
  }
}
