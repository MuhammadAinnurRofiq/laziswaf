<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class CenterUsers extends MY_Controller
{
  public function __construct()
  {
    parent::__construct();
    $this->require_login();

    $role = (string)$this->session->userdata('auth_role');
    if ($role !== 'ADMIN') show_error('Akses ditolak', 403);

    $this->load->model('User_model');
    $this->load->library('form_validation');
    $this->load->helper(array('url','form','menu'));
  }


  // ============================
  // ADMIN: Manajemen semua user
  // ============================
  public function index()
  {
    $u = (array)$this->session->userdata('auth_user');
    $role = (string)$this->session->userdata('auth_role');

    $filters = array(
      'q'    => $this->input->get('q', TRUE),
      'role' => $this->input->get('role', TRUE),
    );

    $data = array(
      'title'   => 'Manajemen User',
      'role'    => $role,
      'user'    => (object) array(
        'full_name' => $u['full_name'] ?? 'Admin',
        'username'  => $u['username'] ?? 'admin',
      ),
      'menu'    => menu_center_sidebar($role),
      'rows'    => $this->User_model->list_all_users($filters),
      'roles'   => $this->User_model->roles_list(),
      'branches'=> $this->User_model->branches_active(),
      'filters' => $filters,
      'ok'      => $this->session->flashdata('ok'),
      'err'     => $this->session->flashdata('err'),
    );

    $this->load->view('layouts/app', array(
      'content' => $this->load->view('center/users/all_index', $data, TRUE),
      'title'   => $data['title'],
      'menu'    => $data['menu'],
      'user'    => $data['user'],
      'role'    => $data['role'],
    ));
  }

  public function create()
  {
    $u = (array)$this->session->userdata('auth_user');
    $role = (string)$this->session->userdata('auth_role');

    $roles = $this->User_model->roles_list();
    $branches = $this->User_model->branches_active();

    if ($this->input->method(TRUE) === 'POST') {
      $this->form_validation->set_rules('username','Username','required|min_length[3]|max_length[50]');
      $this->form_validation->set_rules('full_name','Nama Lengkap','required|min_length[3]|max_length[120]');
      $this->form_validation->set_rules('password','Password','required|min_length[6]');
      $this->form_validation->set_rules('phone','No HP','max_length[30]');
      $this->form_validation->set_rules('email','Email','max_length[120]');
      $this->form_validation->set_rules('role_code','Role','required');
      $this->form_validation->set_rules('branch_id','Cabang','integer');

      if ($this->form_validation->run()) {
        $username = trim((string)$this->input->post('username', TRUE));
        if ($this->User_model->username_exists($username)) {
          $this->session->set_flashdata('err', 'Username sudah dipakai.');
          redirect('dashboard/users/create');
          return;
        }

        $role_code = strtoupper(trim((string)$this->input->post('role_code', TRUE)));
        if (!isset($roles[$role_code])) $role_code = 'CABANG';

        $branch_id = (int)$this->input->post('branch_id', TRUE);
        if ($role_code === 'CABANG' && $branch_id <= 0) {
          $this->session->set_flashdata('err', 'Untuk role CABANG, cabang wajib dipilih.');
          redirect('dashboard/users/create');
          return;
        }
        if ($role_code !== 'CABANG') $branch_id = 0;

        $dataIns = array(
          'username'      => $username,
          'full_name'     => trim((string)$this->input->post('full_name', TRUE)),
          'password_hash' => password_hash((string)$this->input->post('password', TRUE), PASSWORD_BCRYPT),
          'phone'         => trim((string)$this->input->post('phone', TRUE)),
          'email'         => trim((string)$this->input->post('email', TRUE)),
          'branch_id'     => $branch_id,
          'is_active'     => 1,
          'created_at'    => date('Y-m-d H:i:s'),
          'updated_at'    => date('Y-m-d H:i:s'),
        );

        $this->User_model->admin_create_user($dataIns, $role_code);
        $this->session->set_flashdata('ok', 'User berhasil ditambahkan.');
        redirect('dashboard/users');
        return;
      }
    }

    $data = array(
      'title' => 'Tambah User',
      'role'  => $role,
      'user'  => (object) array(
        'full_name' => $u['full_name'] ?? 'Admin',
        'username'  => $u['username'] ?? 'admin',
      ),
      'menu'    => menu_center_sidebar($role),
      'roles'   => $roles,
      'branches'=> $branches,
      'row'     => null,
      'is_edit' => false,
      'ok'      => $this->session->flashdata('ok'),
      'err'     => $this->session->flashdata('err'),
    );

    $this->load->view('layouts/app', array(
      'content' => $this->load->view('center/users/all_form', $data, TRUE),
      'title'   => $data['title'],
      'menu'    => $data['menu'],
      'user'    => $data['user'],
      'role'    => $data['role'],
    ));
  }

  public function edit($id)
  {
    $u = (array)$this->session->userdata('auth_user');
    $role = (string)$this->session->userdata('auth_role');

    $id = (int)$id;
    $row = $this->User_model->find_user($id);
    if (!$row) show_404();

    $roles = $this->User_model->roles_list();
    $branches = $this->User_model->branches_active();

    if ($this->input->method(TRUE) === 'POST') {
      $this->form_validation->set_rules('username','Username','required|min_length[3]|max_length[50]');
      $this->form_validation->set_rules('full_name','Nama Lengkap','required|min_length[3]|max_length[120]');
      $this->form_validation->set_rules('password','Password','min_length[6]');
      $this->form_validation->set_rules('phone','No HP','max_length[30]');
      $this->form_validation->set_rules('email','Email','max_length[120]');
      $this->form_validation->set_rules('role_code','Role','required');
      $this->form_validation->set_rules('branch_id','Cabang','integer');
      $this->form_validation->set_rules('is_active','Aktif','integer');

      if ($this->form_validation->run()) {
        $username = trim((string)$this->input->post('username', TRUE));
        if ($this->User_model->username_exists_other($username, $id)) {
          $this->session->set_flashdata('err', 'Username sudah dipakai user lain.');
          redirect('dashboard/users/edit/'.$id);
          return;
        }

        $role_code = strtoupper(trim((string)$this->input->post('role_code', TRUE)));
        if (!isset($roles[$role_code])) $role_code = 'CABANG';

        $branch_id = (int)$this->input->post('branch_id', TRUE);
        if ($role_code === 'CABANG' && $branch_id <= 0) {
          $this->session->set_flashdata('err', 'Untuk role CABANG, cabang wajib dipilih.');
          redirect('dashboard/users/edit/'.$id);
          return;
        }
        if ($role_code !== 'CABANG') $branch_id = 0;

        $dataUpd = array(
          'username'   => $username,
          'full_name'  => trim((string)$this->input->post('full_name', TRUE)),
          'phone'      => trim((string)$this->input->post('phone', TRUE)),
          'email'      => trim((string)$this->input->post('email', TRUE)),
          'branch_id'  => $branch_id,
          'is_active'  => (int)$this->input->post('is_active', TRUE) ? 1 : 0,
          'updated_at' => date('Y-m-d H:i:s'),
        );

        $pwd = (string)$this->input->post('password', TRUE);
        if (trim($pwd) !== '') {
          $dataUpd['password_hash'] = password_hash($pwd, PASSWORD_BCRYPT);
        }

        $this->User_model->admin_update_user($id, $dataUpd, $role_code);
        $this->session->set_flashdata('ok', 'User berhasil diupdate.');
        redirect('dashboard/users');
        return;
      }
    }

    $data = array(
      'title' => 'Edit User',
      'role'  => $role,
      'user'  => (object) array(
        'full_name' => $u['full_name'] ?? 'Admin',
        'username'  => $u['username'] ?? 'admin',
      ),
      'menu'     => menu_center_sidebar($role),
      'roles'    => $roles,
      'branches' => $branches,
      'row'      => $row,
      'is_edit'  => true,
      'ok'       => $this->session->flashdata('ok'),
      'err'      => $this->session->flashdata('err'),
    );

    $this->load->view('layouts/app', array(
      'content' => $this->load->view('center/users/all_form', $data, TRUE),
      'title'   => $data['title'],
      'menu'    => $data['menu'],
      'user'    => $data['user'],
      'role'    => $data['role'],
    ));
  }

  public function delete($id)
  {
    $id = (int)$id;

    $me = (array)$this->session->userdata('auth_user');
    $myId = (int)($me['id'] ?? 0);
    if ($myId > 0 && $myId === $id) {
      $this->session->set_flashdata('err', 'Tidak bisa menghapus akun yang sedang login.');
      redirect('dashboard/users');
      return;
    }

    $ok = $this->User_model->admin_delete_user($id);
    if ($ok) $this->session->set_flashdata('ok', 'User berhasil dihapus.');
    else $this->session->set_flashdata('err', 'Gagal menghapus user (terkunci relasi data).');

    redirect('dashboard/users');
  }


  public function bendahara_index()
  {
    $u = (array)$this->session->userdata('auth_user');
    $role = (string)$this->session->userdata('auth_role');

    $data = array(
      'title' => 'User Bendahara',
      'rows'  => $this->User_model->list_users_by_role('BENDAHARA'),
      'role'  => $role,
      'user'  => (object) array(
        'full_name' => $u['full_name'] ?? 'Admin',
        'username'  => $u['username'] ?? 'admin',
      ),
      'menu'  => menu_center_sidebar($role),
      'ok'    => $this->session->flashdata('ok'),
      'err'   => $this->session->flashdata('err'),
    );

    $this->load->view('layouts/app', array(
      'content' => $this->load->view('center/users/bendahara_index', $data, TRUE),
      'title'   => $data['title'],
      'menu'    => $data['menu'],
      'user'    => $data['user'],
      'role'    => $data['role'],
    ));
  }

  public function bendahara_create()
  {
    $u = (array)$this->session->userdata('auth_user');
    $role = (string)$this->session->userdata('auth_role');

    if ($this->input->method(TRUE) === 'POST') {
      $this->form_validation->set_rules('username','Username','required|min_length[3]|max_length[50]');
      $this->form_validation->set_rules('full_name','Nama Lengkap','required|min_length[3]|max_length[120]');
      $this->form_validation->set_rules('password','Password','required|min_length[6]');
      $this->form_validation->set_rules('phone','No HP','max_length[30]');
      $this->form_validation->set_rules('email','Email','max_length[120]');

      if ($this->form_validation->run()) {
        $username = trim((string)$this->input->post('username', TRUE));

        if ($this->User_model->username_exists($username)) {
          $this->session->set_flashdata('err', 'Username sudah dipakai.');
          redirect('dashboard/users/bendahara/create');
          return;
        }

        $data = array(
          'username'      => $username,
          'password_hash' => password_hash((string)$this->input->post('password', TRUE), PASSWORD_BCRYPT),
          'full_name'     => trim((string)$this->input->post('full_name', TRUE)),
          'phone'         => trim((string)$this->input->post('phone', TRUE)) ?: null,
          'email'         => trim((string)$this->input->post('email', TRUE)) ?: null,
          'branch_id'     => null,
          'is_active'     => (int)($this->input->post('is_active', TRUE) ? 1 : 0),
        );

        $this->User_model->create_user($data, 'BENDAHARA');

        $this->session->set_flashdata('ok', 'Berhasil menambah user bendahara.');
        redirect('dashboard/users/bendahara');
        return;
      }
    }

    $data = array(
      'title' => 'Tambah User Bendahara',
      'row'   => null,
      'role'  => $role,
      'user'  => (object) array(
        'full_name' => $u['full_name'] ?? 'Admin',
        'username'  => $u['username'] ?? 'admin',
      ),
      'menu'  => menu_center_sidebar($role),
      'err'   => validation_errors(),
    );

    $this->load->view('layouts/app', array(
      'content' => $this->load->view('center/users/bendahara_form', $data, TRUE),
      'title'   => $data['title'],
      'menu'    => $data['menu'],
      'user'    => $data['user'],
      'role'    => $data['role'],
    ));
  }

  public function bendahara_edit($id)
  {
    $row = $this->User_model->find_user_in_role((int)$id, 'BENDAHARA');
    if (!$row) show_404();

    $u = (array)$this->session->userdata('auth_user');
    $role = (string)$this->session->userdata('auth_role');

    if ($this->input->method(TRUE) === 'POST') {
      $this->form_validation->set_rules('username','Username','required|min_length[3]|max_length[50]');
      $this->form_validation->set_rules('full_name','Nama Lengkap','required|min_length[3]|max_length[120]');
      $this->form_validation->set_rules('password','Password','min_length[6]'); // optional
      $this->form_validation->set_rules('phone','No HP','max_length[30]');
      $this->form_validation->set_rules('email','Email','max_length[120]');

      if ($this->form_validation->run()) {
        $username = trim((string)$this->input->post('username', TRUE));

        if ($this->User_model->username_exists_other($username, (int)$id)) {
          $this->session->set_flashdata('err', 'Username sudah dipakai user lain.');
          redirect('dashboard/users/bendahara/edit/'.$id);
          return;
        }

        $upd = array(
          'username'  => $username,
          'full_name' => trim((string)$this->input->post('full_name', TRUE)),
          'phone'     => trim((string)$this->input->post('phone', TRUE)) ?: null,
          'email'     => trim((string)$this->input->post('email', TRUE)) ?: null,
          'is_active' => (int)($this->input->post('is_active', TRUE) ? 1 : 0),
        );

        $pass = trim((string)$this->input->post('password', TRUE));
        if ($pass !== '') {
          $upd['password_hash'] = password_hash($pass, PASSWORD_BCRYPT);
        }

        $this->User_model->update_user((int)$id, $upd);

        $this->session->set_flashdata('ok', 'Berhasil update user bendahara.');
        redirect('dashboard/users/bendahara');
        return;
      }
    }

    $data = array(
      'title' => 'Edit User Bendahara',
      'row'   => $row,
      'role'  => $role,
      'user'  => (object) array(
        'full_name' => $u['full_name'] ?? 'Admin',
        'username'  => $u['username'] ?? 'admin',
      ),
      'menu'  => menu_center_sidebar($role),
      'err'   => validation_errors(),
    );

    $this->load->view('layouts/app', array(
      'content' => $this->load->view('center/users/bendahara_form', $data, TRUE),
      'title'   => $data['title'],
      'menu'    => $data['menu'],
      'user'    => $data['user'],
      'role'    => $data['role'],
    ));
  }

  public function bendahara_delete($id)
  {
    $id = (int)$id;

    // keamanan: jangan hapus diri sendiri
    $me = (array)$this->session->userdata('auth_user');
    if ((int)($me['id'] ?? 0) === $id) {
      $this->session->set_flashdata('err', 'Tidak boleh menghapus akun yang sedang login.');
      redirect('dashboard/users/bendahara');
      return;
    }

    $row = $this->User_model->find_user_in_role($id, 'BENDAHARA');
    if (!$row) show_404();

    // Hapus via POST (lebih aman)
    if ($this->input->method(TRUE) !== 'POST') {
      $this->session->set_flashdata('err', 'Aksi hapus harus melalui tombol (POST).');
      redirect('dashboard/users/bendahara');
      return;
    }

    $this->User_model->delete_user($id);

    $this->session->set_flashdata('ok', 'User bendahara berhasil dihapus.');
    redirect('dashboard/users/bendahara');
  }
}
