<?php
defined('BASEPATH') OR exit('No direct script access allowed');

/**
 * Format menu:
 * [
 *   ['label'=>'...', 'icon'=>'bi-...', 'url'=>'...', 'children'=>[...optional...]],
 * ]
 */

if (!function_exists('menu_public_sidebar')) {
  function menu_public_sidebar()
  {
    return array(
      array('label'=>'Beranda', 'icon'=>'bi-house', 'url'=>site_url('public')),

      array(
        'label'=>'Ajukan Pembayaran',
        'icon'=>'bi-pencil-square',
        'url'=>'#',
        'children'=>array(
          array('label'=>'Zakat Fitrah', 'icon'=>'bi-dot', 'url'=>site_url('public/submission/fitrah')),
          array('label'=>'Zakat Mal',   'icon'=>'bi-dot', 'url'=>site_url('public/submission/mal')),
          array('label'=>'Fidyah',      'icon'=>'bi-dot', 'url'=>site_url('public/submission/fidyah')),
          array('label'=>'Infaq',       'icon'=>'bi-dot', 'url'=>site_url('public/submission/infaq')),
        )
      ),

      array(
        'label'=>'Kalkulator Zakat',
        'icon'=>'bi-calculator',
        'url'=>'#',
        'children'=>array(
          array('label'=>'Kalkulator Fitrah', 'icon'=>'bi-dot', 'url'=>site_url('public/calculator/fitrah')),
          array('label'=>'Kalkulator Mal',    'icon'=>'bi-dot', 'url'=>site_url('public/calculator/mal')),
          array('label'=>'Kalkulator Fidyah', 'icon'=>'bi-dot', 'url'=>site_url('public/calculator/fidyah')),
        )
      ),

      array('label'=>'Cek Status Pengajuan', 'icon'=>'bi-search',  'url'=>site_url('public/track')),
    );
  }
}

if (!function_exists('menu_branch_sidebar')) {
  function menu_branch_sidebar()
  {
    return array(
      array('label'=>'Dashboard', 'icon'=>'bi-speedometer2', 'url'=>site_url('branch')),

      array(
        'label'=>'Pengajuan',
        'icon'=>'bi-inbox',
        'url'=>'#',
        'children'=>array(
          array('label'=>'Input Pengajuan Fitrah', 'icon'=>'bi-dot', 'url'=>site_url('branch/submissions/create/fitrah')),
          array('label'=>'Input Pengajuan Fidyah', 'icon'=>'bi-dot', 'url'=>site_url('branch/submissions/create/fidyah')),
          array('label'=>'Input Pengajuan Mal',    'icon'=>'bi-dot', 'url'=>site_url('branch/submissions/create/mal')),
          array('label'=>'Input Pengajuan Infaq',  'icon'=>'bi-dot', 'url'=>site_url('branch/submissions/create/infaq')),
          array('label'=>'Inbox Pengajuan',        'icon'=>'bi-dot', 'url'=>site_url('branch/submissions')),
          array('label'=>'Riwayat Pengajuan',      'icon'=>'bi-dot', 'url'=>site_url('branch/submissions/history')),
          array('label'=>'Expired & Hapus',        'icon'=>'bi-dot', 'url'=>site_url('branch/submissions/expired')),
        )
      ),

      // ✅ MENU BARU: Cetak QR Cabang
      array(
        'label' => 'Cetak QR Cabang',
        'icon'  => 'bi-qr-code-scan',
        'url'   => site_url('branch/barcode')
      ),

      array('label'=>'Kuitansi',       'icon'=>'bi-receipt',           'url'=>site_url('branch/receipts')),
      array('label'=>'Laporan Cabang', 'icon'=>'bi-file-earmark-text', 'url'=>site_url('branch/reports')),

      array('label'=>'Logout', 'icon'=>'bi-box-arrow-right', 'url'=>site_url('logout')),
    );
  }
}

if (!function_exists('menu_center_sidebar')) {
  function menu_center_sidebar($role = null)
  {
    $role = strtoupper((string)$role);

    $menu = array(
      array('label'=>'Dashboard Pusat', 'icon'=>'bi-speedometer2', 'url'=>site_url('dashboard')),
      array('label' => 'Cabang & Akun', 'icon' => 'bi-people',  'url' => site_url('dashboard/branches')),
      array('label' => 'Tarif & Kalkulator', 'icon' => 'bi-sliders', 'url' => site_url('dashboard/rates')),

      array(
        'label'=>'Pengajuan',
        'icon'=>'bi-inbox',
        'url'=>'#',
        'children'=>array(
          array('label'=>'Monitor Pengajuan', 'icon'=>'bi-dot', 'url'=>site_url('dashboard/submissions')),
        )
      ),

      array('label'=>'Kuitansi', 'icon'=>'bi-receipt', 'url'=>site_url('dashboard/receipts')),

      // ✅ GANTI: Review Laporan jadi parent + children (menu lama ditimpa)
      array(
        'label'=>'Review Laporan',
        'icon'=>'bi-file-earmark-text',
        'url'=>'#',
        'children'=>array(
          array('label'=>'Daftar Laporan', 'icon'=>'bi-dot', 'url'=>site_url('dashboard/reports')),
          array('label'=>'Status Cabang',  'icon'=>'bi-dot', 'url'=>site_url('dashboard/reports/branches')),
        )
      ),

      array('label'=>'Konsolidasi',    'icon'=>'bi-diagram-3',         'url'=>site_url('dashboard/reports/consolidation')),
      array('label'=>'Logout', 'icon'=>'bi-box-arrow-right', 'url'=>site_url('logout')),
    );

    // ✅ ADMIN-ONLY MENU
    if ($role === 'ADMIN') {
      // insert setelah item ke-2 (Cabang & Akun, Tarif & Kalkulator)
      array_splice($menu, 2, 0, array(
        array('label'=>'Manajemen User', 'icon'=>'bi-person-gear', 'url'=>site_url('dashboard/users'))
      ));

      // insert sebelum Logout (item terakhir)
      $settingMenu = array(
        'label' => 'Setting',
        'icon'  => 'bi-gear',
        'url'   => '#',
        'children' => array(
          array('label'=>'Halaman Utama',   'icon'=>'bi-dot', 'url'=>site_url('dashboard/settings/landing')),
          array('label'=>'Profil Aplikasi', 'icon'=>'bi-dot', 'url'=>site_url('dashboard/settings/profile')),
          array('label'=>'Download Database','icon'=>'bi-dot','url'=>site_url('dashboard/settings/download-db')),
        )
      );

      // cari index logout
      $logoutIndex = count($menu) - 1;
      array_splice($menu, $logoutIndex, 0, array($settingMenu));
    }
return $menu;
  }
}

if (!function_exists('app_sidebar_menu')) {
  function app_sidebar_menu($role)
  {
    $role = strtoupper((string)$role);

    if ($role === 'CABANG') return menu_branch_sidebar();
    if ($role === 'ADMIN' || $role === 'BENDAHARA') return menu_center_sidebar($role);

    // default untuk PUBLIC/umum
    return menu_public_sidebar();
  }
}
