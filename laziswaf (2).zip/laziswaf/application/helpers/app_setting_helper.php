<?php
defined('BASEPATH') OR exit('No direct script access allowed');

/**
 * Helper untuk membaca sys_settings secara aman.
 * Dipakai untuk: app_name, app_logo_path, konten landing (JSON), dll.
 */

if (!function_exists('app_setting')) {
  function app_setting($key, $default = null)
  {
    $CI =& get_instance();
    static $cache = array();

    $key = (string)$key;
    if ($key === '') return $default;

    if (array_key_exists($key, $cache)) return $cache[$key];

    try {
      if (!isset($CI->db)) $CI->load->database();
      $row = $CI->db->get_where('sys_settings', array('setting_key'=>$key), 1)->row_array();
      $val = $row ? ($row['value_text'] ?? null) : null;
    } catch (Exception $e) {
      $val = null;
    }

    $cache[$key] = ($val !== null && $val !== '') ? $val : $default;
    return $cache[$key];
  }
}

if (!function_exists('app_setting_json')) {
  function app_setting_json($key, $default = array())
  {
    $CI =& get_instance();
    static $cache = array();

    $key = (string)$key;
    if ($key === '') return $default;

    if (array_key_exists($key, $cache)) return $cache[$key];

    $val = null;
    try {
      if (!isset($CI->db)) $CI->load->database();
      $row = $CI->db->get_where('sys_settings', array('setting_key'=>$key), 1)->row_array();
      $val = $row ? ($row['value_json'] ?? null) : null;
    } catch (Exception $e) {
      $val = null;
    }

    if (!$val) {
      $cache[$key] = $default;
      return $cache[$key];
    }

    $decoded = json_decode($val, true);
    if (!is_array($decoded)) $decoded = $default;

    $cache[$key] = $decoded;
    return $cache[$key];
  }
}

if (!function_exists('app_logo_url')) {
  function app_logo_url()
  {
    $ver = (string)app_setting('app_logo_ver','');
    if ($ver === '') return '';
    return site_url('assets/app-logo?v=' . rawurlencode($ver));
  }
}
