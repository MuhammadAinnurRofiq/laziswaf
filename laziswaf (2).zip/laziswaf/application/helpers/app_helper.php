<?php
defined('BASEPATH') OR exit('No direct script access allowed');

/**
 * DEPRECATED
 * Helper ini tidak dipakai oleh aplikasi saat ini.
 * Sidebar/menu utama menggunakan: application/helpers/menu_helper.php
 * File ini dibiarkan hanya untuk referensi historis.
 */

function menu_tree($role)
{
  // icon pakai bootstrap-icons (bi bi-...)
  if ($role === 'CABANG') {
    return array(
      array('label'=>'Dashboard','icon'=>'bi-speedometer2','url'=>site_url('dashboard')),
      array('label'=>'Pengajuan','icon'=>'bi-inbox','children'=>array(
        array('label'=>'Inbox Pengajuan','url'=>site_url('branch/submissions/inbox')),
        array('label'=>'Buat Pengajuan','url'=>site_url('branch/submissions/create')),
        array('label'=>'Riwayat Pengajuan','url'=>site_url('branch/submissions/history')),
      )),
      array('label'=>'Kuitansi','icon'=>'bi-receipt','children'=>array(
        array('label'=>'Daftar Kuitansi','url'=>site_url('branch/receipts')),
      )),
      array('label'=>'Laporan Cabang','icon'=>'bi-file-earmark-bar-graph','children'=>array(
        array('label'=>'Generate Laporan','url'=>site_url('branch/reports/generate')),
        array('label'=>'Riwayat Laporan','url'=>site_url('branch/reports')),
      )),
      array('label'=>'Notifikasi','icon'=>'bi-bell','url'=>site_url('branch/notifications')),
      array('label'=>'Profil','icon'=>'bi-person','url'=>site_url('branch/profile')),
    );
  }

  if ($role === 'BENDAHARA') {
    return array(
      array('label'=>'Dashboard Pusat','icon'=>'bi-speedometer2','url'=>site_url('dashboard')),
      array('label'=>'Pengajuan','icon'=>'bi-kanban','children'=>array(
        array('label'=>'Input Pengajuan Pusat','url'=>site_url('center/submissions/create')),
        array('label'=>'Monitor Pengajuan Cabang','url'=>site_url('center/submissions/monitor')),
        array('label'=>'Riwayat','url'=>site_url('center/submissions/history')),
      )),
      array('label'=>'Kuitansi','icon'=>'bi-receipt','children'=>array(
        array('label'=>'Daftar Kuitansi','url'=>site_url('center/receipts')),
      )),
      array('label'=>'Laporan','icon'=>'bi-file-earmark-text','children'=>array(
        array('label'=>'Review Laporan Cabang','url'=>site_url('center/reports/incoming')),
        array('label'=>'Laporan Pusat (Konsolidasi)','url'=>site_url('center/reports/center_report')),
      )),
      array('label'=>'Master Data','icon'=>'bi-database','children'=>array(
        array('label'=>'Data Cabang','url'=>site_url('center/masterbranches')),
        array('label'=>'Tarif & Ketentuan','url'=>site_url('center/masterrates')),
        array('label'=>'Metode Pembayaran','url'=>site_url('center/masterpaymentmethods')),
        array('label'=>'Rekening (Opsional)','url'=>site_url('center/bankaccounts')),
      )),
      array('label'=>'Manajemen User','icon'=>'bi-people','children'=>array(
        array('label'=>'Akun Cabang','url'=>site_url('center/users')),
      )),
      array('label'=>'Notifikasi','icon'=>'bi-bell','url'=>site_url('center/notifications')),
      array('label'=>'Profil','icon'=>'bi-person','url'=>site_url('center/profile')),
    );
  }

  // ADMIN
  return array(
    array('label'=>'Dashboard Admin','icon'=>'bi-speedometer2','url'=>site_url('dashboard')),
    array('label'=>'Pengajuan','icon'=>'bi-kanban','url'=>site_url('center/submissions/monitor')),
    array('label'=>'Kuitansi','icon'=>'bi-receipt','url'=>site_url('center/receipts')),
    array('label'=>'Laporan','icon'=>'bi-file-earmark-text','url'=>site_url('center/reports/incoming')),
    array('label'=>'Master Data','icon'=>'bi-database','url'=>site_url('center/masterbranches')),
    array('label'=>'Manajemen User','icon'=>'bi-people','url'=>site_url('center/users')),
    array('label'=>'Pengaturan','icon'=>'bi-gear','children'=>array(
      array('label'=>'Branding & Tema','url'=>site_url('admin/settings/branding')),
      array('label'=>'Landing Page (CMS)','url'=>site_url('admin/cmspages')),
      array('label'=>'Template Kuitansi','url'=>site_url('admin/receipttemplates')),
      array('label'=>'Running Number','url'=>site_url('admin/settings/running_numbers')),
    )),
    array('label'=>'Audit Log','icon'=>'bi-shield-check','url'=>site_url('admin/auditlogs')),
    array('label'=>'Notifikasi','icon'=>'bi-bell','url'=>site_url('center/notifications')),
    array('label'=>'Profil','icon'=>'bi-person','url'=>site_url('center/profile')),
  );
}
