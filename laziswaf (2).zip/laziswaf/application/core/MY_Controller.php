<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class MY_Controller extends CI_Controller
{
  protected $auth_user;
  protected $auth_role;

  public function __construct()
  {
    parent::__construct();
    $this->auth_user = $this->session->userdata('auth_user');
    $this->auth_role = $this->session->userdata('auth_role'); // 'CABANG' / 'BENDAHARA' / 'ADMIN'
  }

  protected function require_login()
  {
    if (empty($this->auth_user) || empty($this->auth_user['id'])) {
      redirect('login');
      exit;
    }
  }

  protected function require_role($role_code)
  {
    $this->require_login();

    // auth_role bisa string atau array
    $role = $this->auth_role;

    if (is_array($role)) {
      if (!in_array($role_code, $role, true)) show_error('Akses ditolak', 403);
    } else {
      if ((string)$role !== (string)$role_code) show_error('Akses ditolak', 403);
    }
  }

  protected function user()
  {
    return $this->auth_user ?: array();
  }

  protected function role()
  {
    return $this->auth_role ?: 'PUBLIC';
  }
}
